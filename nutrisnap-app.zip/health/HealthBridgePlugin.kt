package com.nutrisnap.app

import android.content.Intent
import android.net.Uri
import androidx.activity.result.ActivityResult
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.MealType
import androidx.health.connect.client.records.NutritionRecord
import androidx.health.connect.client.records.metadata.Metadata
import androidx.health.connect.client.units.Energy
import androidx.health.connect.client.units.Mass
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.ActivityCallback
import com.getcapacitor.annotation.CapacitorPlugin
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.time.Instant
import java.time.ZoneId

/**
 * Schreibt jede Mahlzeit als sauberen NutritionRecord (Name, Mahlzeitentyp, Energie,
 * Makro- und Mikronährstoffe) in Health Connect. Jede Mahlzeit hat eine feste
 * clientRecordId, dadurch werden Änderungen aktualisiert statt doppelt angelegt.
 */
@CapacitorPlugin(name = "HealthBridge")
class HealthBridgePlugin : Plugin() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val writePermission = HealthPermission.getWritePermission(NutritionRecord::class)

    private fun client(): HealthConnectClient = HealthConnectClient.getOrCreate(context)

    private suspend fun isGranted(): Boolean =
        client().permissionController.getGrantedPermissions().contains(writePermission)

    @PluginMethod
    fun status(call: PluginCall) {
        scope.launch {
            try {
                val sdk = HealthConnectClient.getSdkStatus(context)
                val available = sdk == HealthConnectClient.SDK_AVAILABLE
                val o = JSObject()
                o.put("sdk", sdk)
                o.put("available", available)
                o.put("granted", if (available) isGranted() else false)
                call.resolve(o)
            } catch (e: Exception) {
                call.reject(e.message ?: e.toString())
            }
        }
    }

    @PluginMethod
    fun requestPermissions(call: PluginCall) {
        try {
            val contract = PermissionController.createRequestPermissionResultContract()
            val intent = contract.createIntent(context, setOf(writePermission))
            startActivityForResult(call, intent, "permissionResult")
        } catch (e: Exception) {
            call.reject(e.message ?: e.toString())
        }
    }

    @ActivityCallback
    fun permissionResult(call: PluginCall?, result: ActivityResult?) {
        if (call == null) return
        scope.launch {
            try {
                val o = JSObject()
                o.put("granted", isGranted())
                call.resolve(o)
            } catch (e: Exception) {
                call.reject(e.message ?: e.toString())
            }
        }
    }

    @PluginMethod
    fun writeMeals(call: PluginCall) {
        scope.launch {
            try {
                if (HealthConnectClient.getSdkStatus(context) != HealthConnectClient.SDK_AVAILABLE) {
                    call.reject("UNAVAILABLE")
                    return@launch
                }
                if (!isGranted()) {
                    call.reject("NOT_GRANTED")
                    return@launch
                }
                val arr = call.getArray("meals")
                val records = ArrayList<NutritionRecord>()
                if (arr != null) {
                    for (i in 0 until arr.length()) records.add(toRecord(arr.getJSONObject(i)))
                }
                val c = client()
                var written = 0
                for (chunk in records.chunked(200)) {
                    c.insertRecords(chunk)
                    written += chunk.size
                }
                val o = JSObject()
                o.put("written", written)
                call.resolve(o)
            } catch (e: Exception) {
                call.reject(e.message ?: e.toString())
            }
        }
    }

    @PluginMethod
    fun deleteMeals(call: PluginCall) {
        scope.launch {
            try {
                if (HealthConnectClient.getSdkStatus(context) != HealthConnectClient.SDK_AVAILABLE || !isGranted()) {
                    call.reject("NOT_GRANTED")
                    return@launch
                }
                val arr = call.getArray("ids")
                val ids = ArrayList<String>()
                if (arr != null) {
                    for (i in 0 until arr.length()) ids.add(arr.getString(i))
                }
                if (ids.isNotEmpty()) {
                    client().deleteRecords(NutritionRecord::class, emptyList(), ids)
                }
                call.resolve()
            } catch (e: Exception) {
                call.reject(e.message ?: e.toString())
            }
        }
    }

    @PluginMethod
    fun openSettings(call: PluginCall) {
        val actions = listOf(
            "android.health.connect.action.HEALTH_HOME_SETTINGS",
            "androidx.health.ACTION_HEALTH_CONNECT_SETTINGS"
        )
        for (a in actions) {
            try {
                val i = Intent(a)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i)
                call.resolve()
                return
            } catch (e: Exception) {
                // nächste Variante probieren
            }
        }
        call.reject("NO_SETTINGS")
    }

    @PluginMethod
    fun openStore(call: PluginCall) {
        try {
            val uri = Uri.parse("market://details?id=com.google.android.apps.healthdata&url=healthconnect%3A%2F%2Fonboarding")
            val i = Intent(Intent.ACTION_VIEW, uri)
            i.setPackage("com.android.vending")
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(i)
            call.resolve()
        } catch (e: Exception) {
            try {
                val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.apps.healthdata"))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i)
                call.resolve()
            } catch (e2: Exception) {
                call.reject(e2.message ?: e2.toString())
            }
        }
    }

    private fun toRecord(j: JSONObject): NutritionRecord {
        val end = Instant.ofEpochMilli(j.optLong("end", System.currentTimeMillis()))
        val start = end.minusSeconds(900)
        val offset = ZoneId.systemDefault().rules.getOffset(end)

        fun g(k: String): Mass? {
            val v = j.optDouble(k, 0.0)
            return if (v > 0.0) Mass.grams(v) else null
        }
        fun mg(k: String): Mass? {
            val v = j.optDouble(k, 0.0)
            return if (v > 0.0) Mass.milligrams(v) else null
        }
        fun ug(k: String): Mass? {
            val v = j.optDouble(k, 0.0)
            return if (v > 0.0) Mass.micrograms(v) else null
        }

        val mealType = when (j.optString("meal")) {
            "breakfast" -> MealType.MEAL_TYPE_BREAKFAST
            "lunch" -> MealType.MEAL_TYPE_LUNCH
            "dinner" -> MealType.MEAL_TYPE_DINNER
            "snack" -> MealType.MEAL_TYPE_SNACK
            else -> MealType.MEAL_TYPE_UNKNOWN
        }

        return NutritionRecord(
            startTime = start,
            startZoneOffset = offset,
            endTime = end,
            endZoneOffset = offset,
            name = j.optString("name").take(100),
            mealType = mealType,
            energy = Energy.kilocalories(j.optDouble("kcal", 0.0)),
            protein = g("protein"),
            totalCarbohydrate = g("carbs"),
            totalFat = g("fat"),
            dietaryFiber = g("fiber"),
            sugar = g("sugar"),
            saturatedFat = g("sat_fat"),
            sodium = mg("sodium"),
            potassium = mg("potassium"),
            calcium = mg("calcium"),
            iron = mg("iron"),
            magnesium = mg("magnesium"),
            zinc = mg("zinc"),
            vitaminA = ug("vit_a"),
            vitaminC = mg("vit_c"),
            vitaminD = ug("vit_d"),
            vitaminB12 = ug("vit_b12"),
            metadata = Metadata(
                clientRecordId = j.optString("id"),
                clientRecordVersion = System.currentTimeMillis()
            )
        )
    }
}
