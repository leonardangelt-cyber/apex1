#!/usr/bin/env python3
"""Passt das von Capacitor erzeugte Android-Projekt an.
Aufruf: patch_android.py <android-ordner> <health 0|1> <run-nummer>"""
import pathlib
import re
import sys

android = pathlib.Path(sys.argv[1])
health = sys.argv[2] == "1"
run = sys.argv[3]
root = android.parent


def insert_before(text, marker, snippet):
    i = text.index(marker)
    return text[:i] + snippet + text[i:]


# ---------- Manifest ----------
mf = android / "app/src/main/AndroidManifest.xml"
s = mf.read_text()
perms = [
    ('android.permission.CAMERA', '<uses-permission android:name="android.permission.CAMERA" />'),
    ('android.hardware.camera', '<uses-feature android:name="android.hardware.camera" android:required="false" />'),
]
if health:
    perms.append(('android.permission.health.WRITE_NUTRITION',
                  '<uses-permission android:name="android.permission.health.WRITE_NUTRITION" />'))
add = "".join("    " + tag + "\n" for key, tag in perms if key not in s)
s = insert_before(s, "</manifest>", add)

if health:
    if "com.google.android.apps.healthdata" not in s:
        s = insert_before(s, "<application",
                          '    <queries>\n        <package android:name="com.google.android.apps.healthdata" />\n    </queries>\n\n    ')
    # Datenschutz-/Berechtigungs-Hinweis (Android 13 und älter)
    s = insert_before(s, "</activity>",
                      '    <intent-filter>\n'
                      '                <action android:name="androidx.health.ACTION_SHOW_PERMISSIONS_RATIONALE" />\n'
                      '            </intent-filter>\n        ')
    # Berechtigungs-Nutzung (Android 14+)
    s = insert_before(s, "</application>",
                      '    <activity-alias\n'
                      '            android:name="ViewPermissionUsageActivity"\n'
                      '            android:exported="true"\n'
                      '            android:targetActivity=".MainActivity"\n'
                      '            android:permission="android.permission.START_VIEW_PERMISSION_USAGE">\n'
                      '            <intent-filter>\n'
                      '                <action android:name="android.intent.action.VIEW_PERMISSION_USAGE" />\n'
                      '                <category android:name="android.intent.category.HEALTH_PERMISSIONS" />\n'
                      '            </intent-filter>\n'
                      '        </activity-alias>\n    ')
mf.write_text(s)

# ---------- app/build.gradle ----------
gp = android / "app/build.gradle"
g = gp.read_text()
g = re.sub(r"versionCode \d+", "versionCode " + run, g, count=1)
g = re.sub(r'versionName "[^"]*"', 'versionName "1.' + run + '"', g, count=1)
if health:
    g = g.replace("apply plugin: 'com.android.application'",
                  "apply plugin: 'com.android.application'\napply plugin: 'kotlin-android'", 1)
ks = root / "signing/debug.keystore"
if ks.exists():
    (android / "app/nutrisnap.keystore").write_bytes(ks.read_bytes())
    g += """

android {
  signingConfigs {
    debug {
      storeFile file('nutrisnap.keystore')
      storePassword 'android'
      keyAlias 'androiddebugkey'
      keyPassword 'android'
    }
  }
}
"""
if health:
    g += """

android {
  kotlinOptions {
    jvmTarget = '17'
  }
}

dependencies {
  implementation "androidx.health.connect:connect-client:1.1.0-alpha07"
  implementation "org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3"
}
"""
gp.write_text(g)

if health:
    # ---------- Kotlin-Plugin im Root-Gradle ----------
    rp = android / "build.gradle"
    r = rp.read_text()
    pat = r"(classpath\s+['\"]com\.android\.tools\.build:gradle:[^'\"]+['\"])"
    if not re.search(pat, r):
        sys.exit("Android-Gradle-Plugin-Zeile nicht gefunden")
    r = re.sub(pat, lambda m: m.group(1) + "\n        classpath 'org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.22'", r, count=1)
    rp.write_text(r)

    # ---------- Health Connect braucht mindestens Android 8 ----------
    vp = android / "variables.gradle"
    v = vp.read_text()
    v = re.sub(r"minSdkVersion\s*=\s*\d+", "minSdkVersion = 26", v)
    vp.write_text(v)

print("Android-Projekt angepasst (health=%s, run=%s)" % (health, run))
