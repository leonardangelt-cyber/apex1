#!/usr/bin/env bash
# Baut die APK. Aufruf: bash tools/build.sh <run-nummer>
# Versucht zuerst mit Health Connect. Klappt das nicht, wird automatisch ohne gebaut.
set -uo pipefail
RUN="${1:-1}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
PKG=com/nutrisnap/app
LOG="$ROOT/gradle.log"

# Maven-Spiegel gegen 429-Fehler
mkdir -p ~/.gradle/init.d
M='maven { url "https://maven-central.storage-download.googleapis.com/maven2/" }'
{
  echo "allprojects {"
  echo "  buildscript { repositories { $M } }"
  echo "  repositories { $M }"
  echo "}"
} > ~/.gradle/init.d/mirror.gradle

npm install --no-audit --no-fund || exit 1

prepare() {
  local health="$1"
  rm -rf android
  npx cap add android || return 1
  local D="android/app/src/main/java/$PKG"
  mkdir -p "$D"
  cp android-overlay/DynamicColorPlugin.java "$D/"
  if [ "$health" = "1" ]; then
    sed 's#//HEALTH_REGISTER#registerPlugin(HealthBridgePlugin.class);#' android-overlay/MainActivity.java > "$D/MainActivity.java"
    cp health/HealthBridgePlugin.kt "$D/"
  else
    cp android-overlay/MainActivity.java "$D/MainActivity.java"
  fi
  python3 tools/patch_android.py android "$health" "$RUN" || return 1
  npx cap sync android || return 1
}

gradle_build() {
  ( cd android && chmod +x gradlew && ./gradlew assembleDebug --no-daemon ) 2>&1 | tee "$LOG"
  return "${PIPESTATUS[0]}"
}

# bis zu $1 Versuche, aber nur bei Netzwerkproblemen wiederholen
attempt() {
  local n="$1" i
  for ((i = 1; i <= n; i++)); do
    gradle_build && return 0
    if grep -qiE 'status code 429|too many requests|could not (resolve|get|head)|timed out|connection reset|status code 50[0-9]' "$LOG"; then
      echo "Netzwerkproblem – Versuch $i von $n"
      sleep $((i * 40))
    else
      return 1
    fi
  done
  return 1
}

HEALTH=1
if prepare 1 && attempt 3; then
  echo "Build MIT Health Connect erfolgreich."
else
  echo "::warning::Build mit Health Connect fehlgeschlagen – baue ohne Health Connect."
  HEALTH=0
  prepare 0 && attempt 3 || exit 1
fi

cp android/app/build/outputs/apk/debug/app-debug.apk "$ROOT/NutriSnap-$RUN.apk" || exit 1
[ -n "${GITHUB_OUTPUT:-}" ] && echo "health=$HEALTH" >> "$GITHUB_OUTPUT"
exit 0
