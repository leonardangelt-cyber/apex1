(() => {
'use strict';

/* ================= Konstanten ================= */
const KEY = 'nutrisnap.v1';
const THEME_KEY = 'nutrisnap.theme';
const DEFAULT_MODEL = 'gemini-2.5-flash';
const API = 'https://generativelanguage.googleapis.com/v1beta/';
const MEALS = [['breakfast', 'Frühstück', 'Frühstück', 'cup'], ['lunch', 'Mittagessen', 'Mittag', 'food'], ['snack', 'Snack', 'Snack', 'cookie'], ['dinner', 'Abendessen', 'Abend', 'moon']];
const MEAL_TIME = { breakfast: [8, 0], lunch: [12, 30], snack: [15, 30], dinner: [19, 0] };
const NUTS = [
  ['kcal', 'Kalorien', 'kcal'], ['protein', 'Eiweiß', 'g'], ['carbs', 'Kohlenhydrate', 'g'], ['fat', 'Fett', 'g'],
  ['fiber', 'Ballaststoffe', 'g'], ['sugar', 'Zucker', 'g'], ['sat_fat', 'Gesättigte Fettsäuren', 'g'],
  ['sodium', 'Natrium', 'mg'], ['potassium', 'Kalium', 'mg'], ['calcium', 'Calcium', 'mg'], ['iron', 'Eisen', 'mg'],
  ['magnesium', 'Magnesium', 'mg'], ['zinc', 'Zink', 'mg'], ['vit_a', 'Vitamin A', 'µg'], ['vit_c', 'Vitamin C', 'mg'],
  ['vit_d', 'Vitamin D', 'µg'], ['vit_b12', 'Vitamin B12', 'µg']
];
const MICROS = NUTS.slice(4);
const WD = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'];
const WDL = ['Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag', 'Sonntag'];
const MONL = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];

/* ================= Icons ================= */
const ICONS = {
  add: 'M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z',
  settings: 'M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58a.49.49 0 00.12-.61l-1.92-3.32a.488.488 0 00-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.484.484 0 00-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58a.49.49 0 00-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z',
  close: 'M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z',
  back: 'M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z',
  arrow: 'M12 4l-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z',
  camera: 'M12 15.2a3.2 3.2 0 100-6.4 3.2 3.2 0 000 6.4zM9 2L7.17 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2h-3.17L15 2H9zm3 15c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z',
  image: 'M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z',
  edit: 'M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a.996.996 0 000-1.41l-2.34-2.34a.996.996 0 00-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z',
  book: 'M21 5c-1.11-.35-2.33-.5-3.5-.5-1.95 0-4.05.4-5.5 1.5-1.45-1.1-3.55-1.5-5.5-1.5S2.45 4.9 1 6v14.65c0 .25.25.5.5.5.1 0 .15-.05.25-.05C3.1 20.45 5.05 20 6.5 20c1.95 0 4.05.4 5.5 1.5 1.35-.85 3.8-1.5 5.5-1.5 1.65 0 3.35.3 4.75 1.05.1.05.15.05.25.05.25 0 .5-.25.5-.5V6c-.6-.45-1.25-.75-2-1zm0 13.5c-1.1-.35-2.3-.5-3.5-.5-1.7 0-4.15.65-5.5 1.5V8c1.35-.85 3.8-1.5 5.5-1.5 1.2 0 2.4.15 3.5.5v11.5z',
  delete: 'M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z',
  check: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z',
  tick: 'M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z',
  error: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z',
  left: 'M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z',
  right: 'M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z',
  chev: 'M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6z',
  cup: 'M20 3H4v10c0 2.21 1.79 4 4 4h6c2.21 0 4-1.79 4-4v-3h2c1.11 0 2-.9 2-2V5c0-1.11-.89-2-2-2zm0 5h-2V5h2v3zM4 19h16v2H4z',
  food: 'M11 9H9V2H7v7H5V2H3v7c0 2.12 1.66 3.84 3.75 3.97V22h2.5v-9.03C11.34 12.84 13 11.12 13 9V2h-2v7zm5-3v8h2.5v8H21V2c-2.76 0-5 2.24-5 4z',
  cookie: 'M12 2a10 10 0 1010 10c0-.6-.06-1.2-.17-1.76A4 4 0 0116.5 6.2 4 4 0 0113.76 2.17 10 10 0 0012 2zM8.5 9a1.5 1.5 0 110 3 1.5 1.5 0 010-3zm3 6.5a1.5 1.5 0 110 3 1.5 1.5 0 010-3zm4.5-2a1 1 0 110 2 1 1 0 010-2z',
  moon: 'M12 3a9 9 0 109 9c0-.46-.04-.92-.1-1.36a5.389 5.389 0 01-4.4 2.26 5.403 5.403 0 01-3.14-9.8c-.44-.06-.9-.1-1.36-.1z',
  fire: 'M13.5.67s.74 2.65.74 4.8c0 2.06-1.35 3.73-3.41 3.73-2.07 0-3.63-1.67-3.63-3.73l.03-.36C5.21 7.51 4 10.62 4 14c0 4.42 3.58 8 8 8s8-3.58 8-8C20 8.61 17.41 3.8 13.5.67zM11.71 19c-1.78 0-3.22-1.4-3.22-3.14 0-1.62 1.05-2.76 2.81-3.12 1.77-.36 3.6-1.21 4.62-2.58.39 1.29.59 2.65.59 4.04 0 2.65-2.15 4.8-4.8 4.8z',
  eye: 'M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z',
  sparkle: 'M19 9l1.25-2.75L23 5l-2.75-1.25L19 1l-1.25 2.75L15 5l2.75 1.25L19 9zm-7.5.5L9 4 6.5 9.5 1 12l5.5 2.5L9 20l2.5-5.5L17 12l-5.5-2.5zM19 15l-1.25 2.75L15 19l2.75 1.25L19 23l1.25-2.75L23 19l-2.75-1.25L19 15z',
  heart: 'M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z',
  sync: 'M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6 0 1.01-.25 1.97-.7 2.8l1.46 1.46C19.54 15.03 20 13.57 20 12c0-4.42-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6 0-1.01.25-1.97.7-2.8L5.24 7.74C4.46 8.97 4 10.43 4 12c0 4.42 3.58 8 8 8v3l4-4-4-4v3z'
};
const ic = n => `<svg class="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="${ICONS[n]}"/></svg>`;

/* ================= Helfer ================= */
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const num = v => { const n = parseFloat(String(v).replace(',', '.')); return Number.isFinite(n) ? n : 0; };
const r0 = v => Math.round(v);
const r1 = v => Math.round(v * 10) / 10;
const de = v => String(r1(v)).replace('.', ',');
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const clone = o => JSON.parse(JSON.stringify(o));
const pad = n => String(n).padStart(2, '0');
const dkey = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
const parseKey = k => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const fmt = (v, u) => (u === 'kcal' || v >= 100 ? r0(v) : r1(v)) + ' ' + u;
const wdIndex = d => (d.getDay() + 6) % 7;
const sleep = ms => new Promise(r => setTimeout(r, ms));
const reduced = () => window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const mealLabel = id => (MEALS.find(m => m[0] === id) || [0, id])[1];

let toastTimer;
function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 3400);
}
function countUp(el, to, ms = 900) {
  if (!el) return;
  to = r0(to);
  if (reduced() || !to) { el.textContent = to; return; }
  const t0 = performance.now();
  const f = t => {
    const p = Math.min(1, (t - t0) / ms), e = 1 - Math.pow(1 - p, 3);
    el.textContent = p < 1 ? r0(to * e) : to;
    if (p < 1 && el.isConnected) requestAnimationFrame(f);
  };
  requestAnimationFrame(f);
}

/* ================= Speicher ================= */
const DEFAULT_SETTINGS = { apiKey: '', model: DEFAULT_MODEL, goal: 2000, keyOk: false, onboarded: false, name: '', profile: null, plan: null, hcAuto: true };
function loadState() {
  let s = {};
  try { s = JSON.parse(localStorage.getItem(KEY) || '{}'); } catch (e) { s = {}; }
  return {
    settings: Object.assign({}, DEFAULT_SETTINGS, s.settings || {}),
    library: Array.isArray(s.library) ? s.library : [],
    diary: Array.isArray(s.diary) ? s.diary : []
  };
}
let state = loadState();
function save() {
  try { localStorage.setItem(KEY, JSON.stringify(state)); }
  catch (e) { toast('Speichern fehlgeschlagen (Speicher voll?)'); }
}
const ui = { date: dkey(new Date()), meal: null, models: [], key: { s: 'idle' }, showKey: false, open: {}, hc: { s: 'unknown' }, dynamic: false };
let draft = null;
let ob = null;

/* ================= Dynamische Farben (Material You) ================= */
const T_IDX = { 0: 0, 10: 1, 50: 2, 100: 3, 200: 4, 300: 5, 400: 6, 500: 7, 600: 8, 700: 9, 800: 10, 900: 11, 1000: 12 };
const hex2rgb = h => { h = h.replace('#', ''); return [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)); };
const mix = (a, b, t) => { const A = hex2rgb(a), B = hex2rgb(b); return '#' + A.map((v, i) => pad(Math.round(v + (B[i] - v) * t).toString(16))).join(''); };
const tone = (arr, t) => Array.isArray(arr) ? arr[T_IDX[t]] : (arr && arr[t]);
const PAL_KEYS = ['primary', 'on-primary', 'primary-container', 'on-primary-container', 'secondary', 'on-secondary', 'secondary-container', 'on-secondary-container', 'tertiary', 'on-tertiary', 'tertiary-container', 'on-tertiary-container', 'surface', 'on-surface', 'on-surface-variant', 'outline', 'outline-variant', 'sc-lowest', 'sc-low', 'sc', 'sc-high', 'sc-highest', 'error', 'error-container', 'on-error-container', 'inverse', 'on-inverse'];
function applyPalette(t) {
  const root = document.documentElement.style;
  const dark = t && typeof t.dark === 'boolean' ? t.dark : window.matchMedia('(prefers-color-scheme: dark)').matches;
  root.colorScheme = dark ? 'dark' : 'light';
  let surface;
  if (t && t.accent1 && t.neutral1 && tone(t.accent1, 600)) {
    const a = t.accent1, b = t.accent2, c = t.accent3, n = t.neutral1, v = t.neutral2;
    const P = dark ? {
      'primary': tone(a, 200), 'on-primary': tone(a, 800), 'primary-container': tone(a, 700), 'on-primary-container': tone(a, 100),
      'secondary': tone(b, 200), 'on-secondary': tone(b, 800), 'secondary-container': tone(b, 700), 'on-secondary-container': tone(b, 100),
      'tertiary': tone(c, 200), 'on-tertiary': tone(c, 800), 'tertiary-container': tone(c, 700), 'on-tertiary-container': tone(c, 100),
      'surface': mix(tone(n, 900), tone(n, 1000), .35), 'on-surface': tone(n, 100), 'on-surface-variant': tone(v, 200),
      'outline': tone(v, 500), 'outline-variant': tone(v, 700),
      'sc-lowest': tone(n, 1000), 'sc-low': tone(n, 900), 'sc': mix(tone(n, 900), tone(n, 800), .5), 'sc-high': tone(n, 800), 'sc-highest': tone(n, 700),
      'error': '#ffb4ab', 'error-container': '#93000a', 'on-error-container': '#ffdad6', 'inverse': tone(n, 100), 'on-inverse': tone(n, 800)
    } : {
      'primary': tone(a, 600), 'on-primary': tone(a, 0), 'primary-container': tone(a, 100), 'on-primary-container': tone(a, 900),
      'secondary': tone(b, 600), 'on-secondary': tone(b, 0), 'secondary-container': tone(b, 100), 'on-secondary-container': tone(b, 900),
      'tertiary': tone(c, 600), 'on-tertiary': tone(c, 0), 'tertiary-container': tone(c, 100), 'on-tertiary-container': tone(c, 900),
      'surface': tone(n, 10), 'on-surface': tone(n, 900), 'on-surface-variant': tone(v, 700),
      'outline': tone(v, 500), 'outline-variant': tone(v, 200),
      'sc-lowest': tone(n, 0), 'sc-low': tone(n, 50), 'sc': mix(tone(n, 50), tone(n, 100), .5), 'sc-high': tone(n, 100), 'sc-highest': tone(n, 200),
      'error': '#ba1a1a', 'error-container': '#ffdad6', 'on-error-container': '#410002', 'inverse': tone(n, 800), 'on-inverse': tone(n, 50)
    };
    for (const k in P) root.setProperty('--' + k, P[k]);
    surface = P.surface; ui.dynamic = true;
  } else {
    PAL_KEYS.forEach(k => root.removeProperty('--' + k));
    surface = getComputedStyle(document.documentElement).getPropertyValue('--surface').trim() || (dark ? '#0f1512' : '#f6fbf5');
    ui.dynamic = false;
  }
  const meta = document.querySelector('meta[name=theme-color]');
  if (meta) meta.setAttribute('content', surface);
  const dc = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.DynamicColor;
  if (dc && dc.setBars && /^#[0-9a-f]{6}$/i.test(surface)) { try { dc.setBars({ color: surface, darkIcons: !dark }); } catch (e) { /* ignorieren */ } }
}
async function refreshTheme() {
  const dc = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.DynamicColor;
  let t = null;
  if (dc && dc.get) { try { t = await dc.get(); if (t && t.supported) localStorage.setItem(THEME_KEY, JSON.stringify(t)); } catch (e) { t = null; } }
  if (!t) { try { t = JSON.parse(localStorage.getItem(THEME_KEY) || 'null'); } catch (e) { t = null; } }
  applyPalette(t);
}
try { applyPalette(JSON.parse(localStorage.getItem(THEME_KEY) || 'null')); } catch (e) { applyPalette(null); }
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', refreshTheme);

/* ================= Nährwert-Rechnung ================= */
const zero = () => Object.fromEntries(NUTS.map(n => [n[0], 0]));
function itemVals(it) {
  const f = num(it.grams) / 100, o = {};
  for (const [k] of NUTS) o[k] = (it.p100 && it.p100[k] || 0) * f;
  return o;
}
function sum(items) {
  const t = zero();
  for (const it of items) { const v = itemVals(it); for (const k in t) t[k] += v[k]; }
  return t;
}
const dayEntries = k => state.diary.filter(e => e.date === k);
const dayTotals = k => sum(dayEntries(k).flatMap(e => e.items));
function itemFromAI(r) {
  const g = num(r.grams) > 0 ? num(r.grams) : 100, p = {};
  for (const [k] of NUTS) p[k] = Math.max(0, num(r[k])) * 100 / g;
  return { id: uid(), name: String(r.name || 'Unbekannt').slice(0, 80), grams: Math.round(g), p100: p };
}
function goals() {
  const p = state.settings.plan;
  if (p) return { kcal: p.kcal, max: p.kcal_max || r0(p.kcal * 1.1), protein: p.protein, carbs: p.carbs, fat: p.fat };
  const g = num(state.settings.goal) || 2000;
  return { kcal: g, max: r0(g * 1.1), protein: g * 0.25 / 4, carbs: g * 0.5 / 4, fat: g * 0.25 / 9 };
}

/* ================= Bibliothek ================= */
function upsertFood(it) {
  const n = it.name.trim().toLowerCase();
  const ex = state.library.find(l => l.type === 'food' && l.name.toLowerCase() === n);
  if (ex) { ex.items = [Object.assign(clone(it), { id: ex.items[0].id })]; ex.used = (ex.used || 0) + 1; ex.ts = Date.now(); }
  else state.library.push({ id: uid(), type: 'food', name: it.name.trim(), items: [clone(it)], used: 1, ts: Date.now() });
}
function upsertMeal(name, items) {
  const n = name.trim().toLowerCase();
  const ex = state.library.find(l => l.type === 'meal' && l.name.toLowerCase() === n);
  if (ex) { ex.items = clone(items); ex.used = (ex.used || 0) + 1; ex.ts = Date.now(); }
  else state.library.push({ id: uid(), type: 'meal', name: name.trim(), items: clone(items), used: 1, ts: Date.now() });
}
function searchLibrary(q) {
  q = (q || '').trim().toLowerCase();
  return state.library.filter(l => !q || l.name.toLowerCase().includes(q))
    .sort((a, b) => (b.used || 0) - (a.used || 0) || a.name.localeCompare(b.name));
}
function libSub(l) {
  const t = sum(l.items), g = l.items.reduce((a, i) => a + num(i.grams), 0);
  return `${l.type === 'meal' ? l.items.length + ' Zutaten' : r0(g) + ' g'} · ${r0(t.kcal)} kcal · E ${r0(t.protein)} · K ${r0(t.carbs)} · F ${r0(t.fat)}`;
}
function libList(q, mode) {
  const l = searchLibrary(q);
  if (!l.length) return `<div class="seg empty">${state.library.length ? 'Nichts gefunden.' : 'Noch nichts gespeichert – jede gespeicherte Mahlzeit füllt die Bibliothek automatisch.'}</div>`;
  return l.map(x => mode === 'manage'
    ? `<div class="libitem"><div class="t"><b>${esc(x.name)}</b><span>${libSub(x)}</span></div>${x.type === 'meal' ? '<span class="badge">Gericht</span>' : ''}<button class="iconbtn small press" data-a="libdel" data-id="${x.id}" aria-label="Löschen">${ic('delete')}</button></div>`
    : `<button class="libitem press" data-libadd="${x.id}"><div class="t"><b>${esc(x.name)}</b><span>${libSub(x)}</span></div>${x.type === 'meal' ? '<span class="badge">Gericht</span>' : ''}${ic('add')}</button>`).join('');
}

/* ================= Foto ================= */
const loadImage = src => new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; });
async function shrink(dataUrl, max, q) {
  const img = await loadImage(dataUrl);
  const s = Math.min(1, max / Math.max(img.width, img.height));
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(img.width * s)); c.height = Math.max(1, Math.round(img.height * s));
  c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
  return c.toDataURL('image/jpeg', q);
}
const fileToDataUrl = f => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(f); });
async function pickPhoto(source) {
  const cap = window.Capacitor, cam = cap && cap.Plugins && cap.Plugins.Camera;
  if (cam && cap.isNativePlatform && cap.isNativePlatform()) {
    try {
      const r = await cam.getPhoto({ quality: 85, resultType: 'dataUrl', source: source === 'camera' ? 'CAMERA' : 'PHOTOS', width: 1600, correctOrientation: true });
      return r.dataUrl;
    } catch (e) {
      if (/cancel/i.test(String(e && (e.message || e)))) return null;
      console.warn('Camera plugin failed, falling back', e);
    }
  }
  return new Promise(resolve => {
    const inp = document.createElement('input');
    inp.type = 'file'; inp.accept = 'image/*';
    if (source === 'camera') inp.setAttribute('capture', 'environment');
    inp.onchange = async () => resolve(inp.files[0] ? await fileToDataUrl(inp.files[0]) : null);
    inp.click();
  });
}

/* ================= Gemini ================= */
function buildPrompt(text, hasImage) {
  return `Du bist ein erfahrener Ernährungsberater. Analysiere ${hasImage ? 'das Foto der Mahlzeit' : 'die Beschreibung der Mahlzeit'}${hasImage && text ? ' und die Angabe des Nutzers' : ''}.
${text ? 'Angabe des Nutzers (hat Vorrang, v. a. bei Mengen und Zutaten): "' + text + '"\n' : ''}Zerlege die Mahlzeit in die wichtigsten Bestandteile (maximal 8) und schätze realistische Portionsgrößen in Gramm.
Gib die Nährwerte jeweils für die gesamte geschätzte Portion dieses Bestandteils an (NICHT pro 100 g).
Antworte ausschließlich mit JSON in genau diesem Format, Namen auf Deutsch:
{"items":[{"name":"","grams":0,"kcal":0,"protein":0,"carbs":0,"fat":0,"fiber":0,"sugar":0,"sat_fat":0,"sodium":0,"potassium":0,"calcium":0,"iron":0,"magnesium":0,"zinc":0,"vit_a":0,"vit_c":0,"vit_d":0,"vit_b12":0}]}
Einheiten: kcal; protein, carbs, fat, fiber, sugar, sat_fat in g; sodium, potassium, calcium, iron, magnesium, zinc, vit_c in mg; vit_a, vit_d, vit_b12 in µg.
Ist kein Essen erkennbar, antworte {"items":[]}.`;
}
function parseObj(txt) {
  let s = String(txt || '').trim().replace(/^```(?:json)?/i, '').replace(/```$/, '').trim();
  const a = s.indexOf('{'), b = s.lastIndexOf('}');
  if (a >= 0 && b > a) s = s.slice(a, b + 1);
  return JSON.parse(s);
}
function parseItems(txt) { const j = parseObj(txt); return Array.isArray(j) ? j : (j.items || []); }
async function gemPost(model, body) {
  let r, data = {};
  try {
    r = await fetch(`${API}models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(state.settings.apiKey)}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
    });
    data = await r.json().catch(() => ({}));
  } catch (e) { return { ok: false, status: 0, data, msg: 'Keine Internetverbindung' }; }
  return { ok: r.ok, status: r.status, data, msg: (data.error && data.error.message) || ('HTTP ' + r.status) };
}
const isQuota = r => r.status === 429 || /quota|RESOURCE_EXHAUSTED|rate.?limit/i.test(r.msg);
const isModelProblem = r => isQuota(r) || r.status === 404 || /not found|not supported|no longer available|deprecated/i.test(r.msg);
function friendly(msg) {
  if (/API key not valid|API_KEY_INVALID|key.*invalid/i.test(msg)) return 'Der API-Key ist ungültig.';
  if (/quota|RESOURCE_EXHAUSTED|rate.?limit/i.test(msg)) return 'Für dieses Modell ist kein freies Kontingent verfügbar.';
  return String(msg).slice(0, 160);
}
async function listModels() {
  let r, data;
  try {
    r = await fetch(`${API}models?pageSize=200&key=${encodeURIComponent(state.settings.apiKey)}`);
    data = await r.json().catch(() => ({}));
  } catch (e) { throw new Error('Keine Internetverbindung'); }
  if (!r.ok) throw new Error(friendly((data.error && data.error.message) || ('HTTP ' + r.status)));
  return (data.models || [])
    .filter(m => /gemini/i.test(m.name) && (m.supportedGenerationMethods || []).includes('generateContent'))
    .map(m => m.name.replace(/^models\//, ''));
}
function rank(n) {
  let s = /flash-lite/.test(n) ? 1 : /flash/.test(n) ? 0 : /pro/.test(n) ? 3 : 2;
  if (/preview|exp/.test(n)) s += .5;
  return s;
}
function candidates(all, first) {
  const bad = /image|tts|audio|live|embed|aqa|robotics|computer|gemma|learnlm|veo|imagen|vision/i;
  const list = all.filter(n => !bad.test(n)).sort((a, b) => rank(a) - rank(b) || b.localeCompare(a));
  if (first && all.includes(first)) {
    const i = list.indexOf(first);
    if (i >= 0) list.splice(i, 1);
    list.unshift(first);
  }
  return list.slice(0, 8);
}
const ping = model => gemPost(model, { contents: [{ parts: [{ text: 'Antworte nur mit: OK' }] }], generationConfig: { maxOutputTokens: 16 } });
async function findWorkingModel(first, skip) {
  const all = await listModels();
  ui.models = all.slice().sort();
  let lastQuota = false;
  for (const m of candidates(all, first)) {
    if (m === skip) continue;
    const r = await ping(m);
    if (r.ok) return { model: m };
    if (isQuota(r)) lastQuota = true;
  }
  return { model: null, quota: lastQuota };
}
/* Führt eine Gemini-Anfrage aus, wechselt bei Quota-/Modellproblemen automatisch das Modell */
async function runGemini(parts, gen) {
  if (!state.settings.apiKey) throw new Error('NOKEY');
  const body = { contents: [{ parts }], generationConfig: Object.assign({ temperature: 0.2, responseMimeType: 'application/json' }, gen || {}) };
  const model = state.settings.model || DEFAULT_MODEL;
  let r = await gemPost(model, body);
  if (!r.ok && isModelProblem(r)) {
    let found = null;
    try { found = await findWorkingModel(null, model); } catch (e) { /* Key-Problem: unten melden */ }
    if (found && found.model) {
      state.settings.model = found.model; state.settings.keyOk = true; save();
      toast('Modell gewechselt auf ' + found.model);
      r = await gemPost(found.model, body);
    }
  }
  if (!r.ok) throw new Error(friendly(r.msg));
  const cand = r.data.candidates && r.data.candidates[0];
  const txt = cand && cand.content && cand.content.parts ? cand.content.parts.map(p => p.text || '').join('') : '';
  if (!txt) throw new Error('Leere Antwort der KI');
  return txt;
}
async function callGemini(imageDataUrl, text) {
  const parts = [];
  if (imageDataUrl) parts.push({ inline_data: { mime_type: 'image/jpeg', data: imageDataUrl.split(',')[1] } });
  parts.push({ text: buildPrompt(text, !!imageDataUrl) });
  return parseItems(await runGemini(parts)).map(itemFromAI);
}
async function verifyKey() {
  if (!state.settings.apiKey) { ui.key = { s: 'bad', msg: 'Bitte zuerst einen API-Key eintragen.' }; return updateStatus(); }
  if (ui.key.s === 'checking') return;
  ui.key = { s: 'checking' }; updateStatus();
  try {
    const f = await findWorkingModel(state.settings.model);
    if (f.model) {
      state.settings.model = f.model; state.settings.keyOk = true; save();
      ui.key = { s: 'ok', model: f.model };
      toast('API-Key funktioniert ✓');
    } else {
      state.settings.keyOk = false; save();
      ui.key = { s: f.quota ? 'noquota' : 'bad', msg: 'Für keines der Modelle kam eine Antwort.' };
    }
  } catch (e) {
    state.settings.keyOk = false; save();
    ui.key = { s: 'bad', msg: e.message };
  }
  if (draft && draft.stage === 'settings') renderOverlay(); else updateStatus();
}
function statusInfo() {
  const k = ui.key;
  if (k.s === 'checking') return { cls: 'busy', html: '<div class="mini"></div><div>Prüfe Key und suche ein passendes Modell …<small>Das dauert nur einen Moment.</small></div>' };
  if (k.s === 'ok' || (k.s === 'idle' && state.settings.keyOk && state.settings.apiKey))
    return { cls: 'ok', html: `${ic('check')}<div>API-Key funktioniert ✓<small>Aktives Modell: ${esc(state.settings.model)}</small></div>` };
  if (k.s === 'noquota') return { cls: 'err', html: `${ic('error')}<div>Key ist gültig, aber ohne freies Kontingent<small>Für kein Gemini-Modell ist aktuell Quota frei. Aktiviere in Google AI Studio die Abrechnung oder versuche es später erneut.</small></div>` };
  if (k.s === 'bad') return { cls: 'err', html: `${ic('error')}<div>Das hat nicht geklappt<small>${esc(k.msg || 'Unbekannter Fehler')}</small></div>` };
  return null;
}
function updateStatus() {
  const el = $('#keystatus'); if (!el) return;
  const s = statusInfo();
  el.hidden = !s;
  if (s) { el.className = 'status ' + s.cls; el.innerHTML = s.html; }
}

/* ================= Shape-Morph + Lade-Animation ================= */
const SHAPES = [[0, 0], [9, .085], [6, .13], [4, .16], [12, .06], [7, .11]];
const NPT = 100;
const SHAPE_PTS = SHAPES.map(([n, a]) => Array.from({ length: NPT }, (_, k) => {
  const th = k / NPT * 2 * Math.PI, r = 44 * (1 + a * Math.cos(n * th));
  return [r * Math.cos(th), r * Math.sin(th)];
}));
function morphD(t) {
  const i = Math.floor(t) % SHAPES.length, j = (i + 1) % SHAPES.length, f = t - Math.floor(t);
  const m = f < .4 ? 0 : (1 - Math.cos(Math.PI * (f - .4) / .6)) / 2;
  let d = '';
  for (let k = 0; k < NPT; k++) {
    const x = SHAPE_PTS[i][k][0] + (SHAPE_PTS[j][k][0] - SHAPE_PTS[i][k][0]) * m;
    const y = SHAPE_PTS[i][k][1] + (SHAPE_PTS[j][k][1] - SHAPE_PTS[i][k][1]) * m;
    d += (k ? 'L' : 'M') + x.toFixed(1) + ' ' + y.toFixed(1);
  }
  return d + 'Z';
}
let morphRun = false;
function kickMorph() {
  if (morphRun) return;
  morphRun = true;
  const loop = t => {
    const els = document.querySelectorAll('path[data-morph]');
    if (!els.length) { morphRun = false; return; }
    const d = morphD(t / 1100);
    els.forEach(e => e.setAttribute('d', d));
    requestAnimationFrame(loop);
  };
  requestAnimationFrame(loop);
}
const shapeSvg = () => `<svg viewBox="-60 -60 120 120"><path data-morph d="${morphD(0)}"/></svg>`;
let msgTimer = null;
function startMsgs(msgs) {
  clearInterval(msgTimer);
  let i = 0;
  msgTimer = setInterval(() => {
    const el = $('#ldmsg');
    if (!el) { clearInterval(msgTimer); return; }
    el.classList.add('swap');
    setTimeout(() => { i = (i + 1) % msgs.length; el.textContent = msgs[i]; el.classList.remove('swap'); }, 260);
  }, 2000);
}
function loaderHtml({ title, msgs, photo, quote }) {
  const visual = photo
    ? `<div class="scanbox"><img src="${photo}" alt=""><div class="band"></div><i class="corner c1"></i><i class="corner c2"></i><i class="corner c3"></i><i class="corner c4"></i></div>`
    : `<div class="ldr-shape">${shapeSvg()}<span class="core">${ic('sparkle')}</span></div>`;
  return `<div class="ldr">${visual}<div class="ldr-title">${title}</div><div class="ldr-msg" id="ldmsg">${msgs[0]}</div><div class="wavy ind"><i></i></div>${quote ? `<div class="ldr-quote">„${esc(quote)}“</div>` : ''}</div>`;
}
const MSGS_PHOTO = ['Foto wird gescannt …', 'Zutaten erkennen …', 'Portionen schätzen …', 'Nährwerte berechnen …', 'Gleich fertig …'];
const MSGS_TEXT = ['Beschreibung wird gelesen …', 'Nährwerte recherchieren …', 'Portionen abschätzen …', 'Vitamine & Mineralstoffe zählen …', 'Gleich fertig …'];
const MSGS_PLAN = ['Grundumsatz berechnen …', 'Aktivität einbeziehen …', 'Ziele abwägen …', 'Makros verteilen …', 'Tipps zusammenstellen …'];

/* ================= Ernährungsplan ================= */
const CHANGE = ['lose', 'gain', 'muscle'];
function calcPlan(d) {
  const w = num(d.weight) || 70, h = num(d.height) || 170, age = num(d.age) || 30;
  const bmr = 10 * w + 6.25 * h - 5 * age + (d.sex === 'm' ? 5 : d.sex === 'f' ? -161 : -78);
  const act = { sedentary: 1.2, light: 1.375, active: 1.55, very: 1.725 }[d.activity] || 1.375;
  const workouts = num(d.workouts);
  const tdee = bmr * act + workouts * 300 / 7;
  const cond = d.conditions || [];
  const noDeficit = age < 18 || cond.some(c => ['pregnant', 'breastfeeding', 'eatingdisorder'].includes(c));
  const minK = d.sex === 'm' ? 1500 : d.sex === 'f' ? 1200 : 1350;
  const goal = d.goal || 'maintain';
  const pace = num(d.pace) || 0.5;
  let kcal = tdee, mode = 'maintain';
  if (goal === 'lose' && !noDeficit) { kcal = tdee - Math.min(pace * 7700 / 7, tdee * 0.25); mode = 'deficit'; }
  else if (goal === 'gain') { kcal = tdee + Math.min(pace * 7700 / 7, tdee * 0.2); mode = 'surplus'; }
  else if (goal === 'muscle') { kcal = tdee + Math.min(Math.max(pace * 7700 / 7, 200), tdee * 0.12); mode = 'surplus'; }
  if (cond.includes('breastfeeding')) kcal += 300;
  kcal = r0(Math.max(kcal, minK) / 10) * 10;
  const pk = { lose: 1.8, muscle: 2.0, gain: 1.6, maintain: 1.4, healthy: 1.3 }[goal] || 1.4;
  const protein = r0(Math.min(w * pk, kcal * 0.35 / 4));
  let fat = kcal * (d.diet === 'lowcarb' ? .38 : .28) / 9, carbs = (kcal - protein * 4 - fat * 9) / 4;
  if (d.diet === 'keto') { carbs = 30; fat = (kcal - protein * 4 - carbs * 4) / 9; }
  else if (carbs < 40) { carbs = 40; fat = (kcal - protein * 4 - 160) / 9; }
  const fiber = Math.max(25, r0(kcal / 1000 * 14));
  const water = r0((35 * w + (workouts >= 3 ? 500 : 0)) / 100) * 100;
  const weeks = CHANGE.includes(goal) && mode !== 'maintain' ? Math.ceil(Math.abs(num(d.target) - w) / pace) : 0;
  const meals = num(d.meals) || 3;
  const tips = [
    `Verteile etwa ${r0(protein)} g Eiweiß auf ${meals} Mahlzeiten, das sind rund ${r0(protein / meals)} g pro Mahlzeit.`,
    `Peile mindestens ${fiber} g Ballaststoffe an. Gemüse, Hülsenfrüchte und Vollkorn helfen dabei.`,
    `Trinke über den Tag verteilt etwa ${de(water / 1000)} Liter.`
  ];
  if (mode === 'deficit') tips.push('Entscheidend ist der Wochentrend, nicht der einzelne Tag. Ein bis zwei lockere Tage sind völlig in Ordnung.');
  if (mode === 'surplus') tips.push('Kalorien dichter wählen: Nüsse, Öle, Vollkorn, Milchprodukte oder Smoothies helfen beim Aufbau.');
  if (d.diet === 'vegan') tips.push('Achte bei veganer Ernährung auf Vitamin B12, Jod, Eisen, Calcium und Omega-3.');
  if (cond.includes('hypertension')) tips.push('Bei Bluthochdruck: Salz unter 5 g pro Tag halten (viel Gemüse und Kalium).');
  if (noDeficit && goal === 'lose') tips.push('Für dich ist kein Kaloriendefizit vorgesehen. Wir halten deshalb dein Gewicht und achten auf eine ausgewogene Ernährung.');
  const focus = [];
  if (d.diet === 'vegan' || d.diet === 'vegetarian') focus.push('Eisen', 'Vitamin B12');
  if ((d.allergies || []).includes('lactose') || (d.allergies || []).includes('dairy')) focus.push('Calcium');
  focus.push('Ballaststoffe');
  const summary = `Dein geschätzter Tagesbedarf liegt bei etwa ${r0(tdee / 10) * 10} kcal. ` + (mode === 'deficit' ? 'Mit einem moderaten Defizit erreichst du dein Ziel nachhaltig.' : mode === 'surplus' ? 'Mit einem leichten Überschuss baust du kontrolliert auf.' : 'Dein Ziel ist es, die Energie im Gleichgewicht zu halten.');
  return {
    kcal, kcal_max: r0(kcal * 1.08 / 10) * 10, protein, carbs: r0(carbs), fat: r0(fat), fiber, sugar_max: r0(kcal * .1 / 4), sodium_max: cond.includes('hypertension') ? 1500 : 2300,
    water_ml: water, summary, tips: tips.slice(0, 5), focus: focus.slice(0, 4), weeks, src: 'local', bmr: r0(bmr), tdee: r0(tdee), min_kcal: minK, noDeficit, mode
  };
}
function profileForAI(d) {
  const L = { lose: 'Abnehmen', maintain: 'Gewicht halten', gain: 'Zunehmen', muscle: 'Muskeln aufbauen', healthy: 'Gesünder essen' };
  return {
    name: d.name || undefined, ziel: L[d.goal] || d.goal, geschlecht: { f: 'weiblich', m: 'männlich', d: 'divers' }[d.sex] || d.sex, alter: d.age, groesse_cm: d.height, gewicht_kg: d.weight,
    zielgewicht_kg: CHANGE.includes(d.goal) ? d.target : undefined, tempo_kg_pro_woche: CHANGE.includes(d.goal) ? d.pace : undefined,
    alltag_aktivitaet: d.activity, trainingseinheiten_pro_woche: d.workouts, ernaehrungsform: d.diet, allergien_unvertraeglichkeiten: d.allergies, gesundheit: d.conditions,
    mahlzeiten_pro_tag: d.meals, intervallfasten: !!d.fasting, wuensche: d.wishes, notizen: d.notes || undefined
  };
}
function planPrompt(d, loc) {
  return `Du bist eine erfahrene Ernährungsberaterin (Diätassistentin). Erstelle einen persönlichen Tagesplan für Kalorien und Nährstoffe auf Deutsch.
Profil (JSON): ${JSON.stringify(profileForAI(d))}
Referenz (Mifflin-St-Jeor): Grundumsatz ${loc.bmr} kcal, Gesamtumsatz ${loc.tdee} kcal, sichere Untergrenze ${loc.min_kcal} kcal.${loc.noDeficit ? '\nWICHTIG: Kein Kaloriendefizit (minderjährig, Schwangerschaft/Stillzeit oder Essstörung). Plane auf Erhaltungsniveau oder darüber.' : ''}
Regeln: Defizit höchstens 25 % des Gesamtumsatzes, Überschuss höchstens 15 %. Berücksichtige Ernährungsform, Allergien, Wünsche und Gesundheitsangaben. Keine Heilversprechen, kein Ersatz für ärztliche Beratung.
"kcal" ist das Tagesziel, "kcal_max" die Obergrenze pro Tag (die nicht überschritten werden soll).
Antworte NUR mit JSON in diesem Format:
{"kcal":0,"kcal_max":0,"protein":0,"carbs":0,"fat":0,"fiber":0,"sugar_max":0,"sodium_max":0,"water_ml":0,"weeks":0,"summary":"2-3 Sätze, persönlich und motivierend","tips":["4 kurze, konkrete Tipps"],"focus":["bis zu 4 Nährstoffe, auf die besonders zu achten ist"]}
Einheiten: kcal; protein, carbs, fat, fiber, sugar_max in g; sodium_max in mg; water_ml in ml; weeks = geschätzte Wochen bis zum Zielgewicht (0 wenn nicht zutreffend).`;
}
function sanitizePlan(ai, loc, d) {
  const n = (v, def) => (Number.isFinite(+v) && +v > 0 ? +v : def);
  const w = num(d.weight) || 70;
  let kcal = r0(n(ai.kcal, loc.kcal) / 10) * 10;
  const hi = loc.noDeficit ? loc.tdee + 400 : loc.tdee + 600;
  kcal = clamp(kcal, loc.min_kcal, hi);
  if (d.goal === 'lose' && !loc.noDeficit) kcal = Math.min(kcal, r0((loc.tdee - 100) / 10) * 10);
  const protein = r0(clamp(n(ai.protein, loc.protein), 0.8 * w, Math.min(3 * w, kcal * .4 / 4)));
  const fat = r0(clamp(n(ai.fat, loc.fat), kcal * .2 / 9, kcal * .45 / 9));
  const carbs = Math.max(20, r0((kcal - protein * 4 - fat * 9) / 4));
  const kmax = r0(clamp(n(ai.kcal_max, loc.kcal_max), kcal + 50, kcal * 1.2) / 10) * 10;
  const arr = (v, def) => (Array.isArray(v) && v.length ? v.map(x => String(x).slice(0, 220)).slice(0, 5) : def);
  return {
    kcal, kcal_max: kmax, protein, carbs, fat, fiber: r0(clamp(n(ai.fiber, loc.fiber), 20, 60)), sugar_max: r0(clamp(n(ai.sugar_max, loc.sugar_max), 10, 120)),
    sodium_max: r0(clamp(n(ai.sodium_max, loc.sodium_max), 1000, 3000)), water_ml: r0(clamp(n(ai.water_ml, loc.water_ml), 1500, 5000) / 100) * 100,
    weeks: r0(clamp(n(ai.weeks, loc.weeks), 0, 200)), summary: String(ai.summary || loc.summary).slice(0, 420),
    tips: arr(ai.tips, loc.tips), focus: arr(ai.focus, loc.focus).slice(0, 4), src: 'ai', bmr: loc.bmr, tdee: loc.tdee, min_kcal: loc.min_kcal, noDeficit: loc.noDeficit, mode: loc.mode
  };
}
async function aiPlan(d, loc) {
  const txt = await runGemini([{ text: planPrompt(d, loc) }], { temperature: 0.3 });
  return sanitizePlan(parseObj(txt), loc, d);
}

/* ================= Health Connect ================= */
const HB = () => (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.HealthBridge) || null;
function entryTime(date, meal, prev) {
  if (prev && prev.time && prev.date === date && prev.meal === meal) return prev.time;
  if (date === dkey(new Date())) return Date.now();
  const [h, m] = MEAL_TIME[meal] || [12, 0];
  const d = parseKey(date); d.setHours(h, m, 0, 0);
  return d.getTime();
}
function hcPayload(e) {
  const t = sum(e.items), o = { id: e.id, name: e.name, meal: e.meal, end: e.time || e.ts || Date.now() };
  for (const [k] of NUTS) o[k] = Math.round(t[k] * 100) / 100;
  return o;
}
async function hcRefresh() {
  const hb = HB();
  if (!hb) ui.hc = { s: 'missing' };
  else {
    try { const r = await hb.status(); ui.hc = r.available ? (r.granted ? { s: 'ready' } : { s: 'needperm' }) : (r.sdk === 2 ? { s: 'update' } : { s: 'unavail' }); }
    catch (e) { ui.hc = { s: 'error', msg: e.message }; }
  }
  paintHc();
}
const hcOn = () => !!(HB() && state.settings.hcAuto && ui.hc.s === 'ready');
async function hcPush(entries) {
  const hb = HB();
  if (!hb) return 0;
  if (ui.hc.s === 'unknown') await hcRefresh();
  if (!hcOn()) return 0;
  const now = Date.now();
  const meals = entries.filter(e => e.items && e.items.length && (e.time || e.ts || 0) <= now).map(hcPayload);
  let n = 0;
  try {
    for (let i = 0; i < meals.length; i += 100) { const r = await hb.writeMeals({ meals: meals.slice(i, i + 100) }); n += (r && r.written) || 0; }
  } catch (e) {
    if (/NOT_GRANTED/.test(e.message || '')) { ui.hc = { s: 'needperm' }; toast('Health-Connect-Zugriff fehlt, bitte neu verbinden'); paintHc(); }
    else toast('Health Connect: ' + e.message);
  }
  return n;
}
async function hcRemove(ids) {
  const hb = HB();
  if (!hb || !ids.length) return;
  if (ui.hc.s === 'unknown') await hcRefresh();
  if (!hcOn()) return;
  try { await hb.deleteMeals({ ids }); } catch (e) { /* nicht kritisch */ }
}
function hcHtml() {
  const s = ui.hc.s, st = s === 'ready' ? 'ready' : '';
  let head, body = '';
  if (s === 'missing') { head = ['Nicht in dieser Version enthalten', 'Diese App wurde ohne Health Connect gebaut.']; }
  else if (s === 'unavail') { head = ['Health Connect nicht verfügbar', 'Dieses Gerät unterstützt Health Connect nicht.']; }
  else if (s === 'update') { head = ['Health Connect wird benötigt', 'Installiere oder aktualisiere die App im Play Store.']; body = `<button class="btn small" data-a="hcstore">Im Play Store öffnen</button>`; }
  else if (s === 'needperm') { head = ['Noch nicht verbunden', 'Mahlzeiten samt Nährwerten erscheinen dann auch in Google Health.']; body = `<button class="btn small" data-a="hcconnect">${ic('heart')}Mit Health Connect verbinden</button>`; }
  else if (s === 'ready') {
    head = ['Mit Health Connect verbunden', 'Jede Mahlzeit wird als Ernährungseintrag übertragen.'];
    body = `<label class="switch"><span>Neue Mahlzeiten automatisch senden</span><input type="checkbox" data-i="hcauto" ${state.settings.hcAuto ? 'checked' : ''}></label>
      <div class="row"><button class="btn tonal small" data-a="hcsync">${ic('sync')}Alles senden</button><button class="btn tonal small" data-a="hcopen">Health Connect öffnen</button></div>`;
  }
  else if (s === 'error') { head = ['Health Connect antwortet nicht', esc(ui.hc.msg || 'Unbekannter Fehler')]; body = `<button class="btn tonal small" data-a="hcrefresh">Erneut prüfen</button>`; }
  else { head = ['Prüfe Health Connect …', 'Einen Moment bitte.']; }
  return `<div class="hchead"><div class="hcico">${ic('heart')}</div><div><b>${head[0]}</b><small>${head[1]}</small></div></div>${body}`;
}
function paintHc() {
  const el = $('#hcbox'); if (!el) return;
  el.className = 'hcbox ' + (ui.hc.s === 'ready' ? 'ready' : '');
  el.innerHTML = hcHtml();
}

/* ================= Startbildschirm ================= */
function arc(cx, cy, r, a0, a1) {
  const p = a => [cx + r * Math.cos(a * Math.PI / 180), cy + r * Math.sin(a * Math.PI / 180)];
  const [x0, y0] = p(a0), [x1, y1] = p(a1);
  return `M${x0.toFixed(2)} ${y0.toFixed(2)}A${r} ${r} 0 ${a1 - a0 > 180 ? 1 : 0} 1 ${x1.toFixed(2)} ${y1.toFixed(2)}`;
}
function wavyArc(cx, cy, R, a0, a1, amp, waves) {
  const steps = Math.max(3, Math.ceil((a1 - a0) / 1.5));
  let d = '';
  for (let i = 0; i <= steps; i++) {
    const a = a0 + (a1 - a0) * i / steps, r = R + amp * Math.sin(2 * Math.PI * waves * (a - a0) / 360), rad = a * Math.PI / 180;
    d += (i ? 'L' : 'M') + (cx + r * Math.cos(rad)).toFixed(2) + ' ' + (cy + r * Math.sin(rad)).toFixed(2);
  }
  return d;
}
function ring(val, goal, max) {
  const pct = Math.min(val / goal, 1), over = val > max;
  const prog = pct > 0.004 ? `<path class="prog ${over ? 'over' : ''}" pathLength="1" d="${wavyArc(118, 118, 100, 135, 135 + 270 * pct, 3.2, 22)}"/>` : '';
  return `<div class="ring"><svg viewBox="0 0 236 236"><path class="track" d="${arc(118, 118, 100, 135, 405)}"/>${prog}</svg>
    <div class="ringtxt"><b data-count="${r0(val)}">${reduced() ? r0(val) : 0}</b><span>kcal gegessen</span></div></div>`;
}
function greeting() { const h = new Date().getHours(); return h < 5 ? 'Gute Nacht' : h < 11 ? 'Guten Morgen' : h < 18 ? 'Guten Tag' : 'Guten Abend'; }
function streak() {
  let s = 0;
  for (let d = new Date(), i = 0; i < 3650; d = addDays(d, -1), i++) {
    if (dayEntries(dkey(d)).length) s++; else if (s || i > 0) break;
  }
  return s;
}
function renderTop() {
  const s = streak(), nm = (state.settings.name || '').trim();
  $('#top').innerHTML = `<div class="hello"><small>${greeting()}${nm ? ', ' + esc(nm) : ''}</small><h1>NutriSnap</h1></div>
    <div class="topact">${s ? `<div class="chip">${ic('fire')}${s}</div>` : ''}<button class="iconbtn tonal press" data-a="settings" aria-label="Einstellungen">${ic('settings')}</button></div>`;
}
function planPage() {
  const p = state.settings.plan;
  if (!p) return `<div class="page"><div class="card fade"><h3>Dein Ernährungsplan</h3><p class="muted" style="margin:0 0 6px">Beantworte ein paar Fragen. Die KI berechnet dein Kalorienlimit und deine Nährstoffziele.</p><button class="btn small" data-a="replan">${ic('sparkle')}Plan erstellen</button></div></div>`;
  return `<div class="page"><div class="card fade"><h3>Mein Ernährungsplan</h3>
    <div class="planline"><span class="pill">Ziel ${p.kcal} kcal</span><span class="pill t">Max ${p.kcal_max} kcal</span><span class="pill">${de(p.water_ml / 1000)} l Wasser</span></div>
    <ul class="tips">${(p.tips || []).slice(0, 4).map(t => `<li>${esc(t)}</li>`).join('')}</ul></div></div>`;
}
function renderHome() {
  const k = ui.date, t = dayTotals(k), g = goals();
  const sel = parseKey(k), mon = addDays(sel, -wdIndex(sel)), today = dkey(new Date());
  const week = Array.from({ length: 7 }, (_, i) => {
    const d = addDays(mon, i), kk = dkey(d);
    return `<button class="day press ${kk === k ? 'sel' : ''} ${kk === today ? 'today' : ''} ${dayEntries(kk).length ? 'has' : ''}" data-a="date" data-date="${kk}"><small>${WD[i]}</small><b>${d.getDate()}</b><i></i></button>`;
  }).join('');
  const tile = (cls, label, v, goal) => `<div class="tile ${cls}"><small>${label}</small><b>${r0(v)} g</b><div class="bar"><i data-w="${Math.min(100, v / goal * 100)}"></i></div></div>`;
  const micro = MICROS.map(([id, l, u]) => `<div class="micro"><span>${l}</span><span>${fmt(t[id], u)}</span></div>`).join('');
  const perMeal = MEALS.map(([id, l]) => {
    const m = sum(dayEntries(k).filter(e => e.meal === id).flatMap(e => e.items));
    return `<div class="mealrow"><span>${l}</span><b>${r0(m.kcal)} kcal</b></div>`;
  }).join('');
  const left = g.kcal - t.kcal;
  const meals = MEALS.map(([id, l, , icn]) => {
    const es = dayEntries(k).filter(e => e.meal === id).sort((a, b) => a.ts - b.ts);
    const kc = es.reduce((a, e) => a + sum(e.items).kcal, 0);
    const open = !!ui.open[id];
    const rows = es.length ? es.map(e => {
      const s = sum(e.items);
      return `<button class="seg press" data-a="edit" data-id="${e.id}">${e.thumb ? `<img class="thumb" src="${e.thumb}" alt="">` : `<div class="thumb">${ic('food')}</div>`}<div class="t"><b>${esc(e.name)}</b><span>E ${r0(s.protein)} g · K ${r0(s.carbs)} g · F ${r0(s.fat)} g</span></div><div class="k">${r0(s.kcal)} <small>kcal</small></div></button>`;
    }).join('') : '<div class="seg empty">Noch nichts eingetragen</div>';
    return `<section class="meal m-${id} ${open ? 'open' : ''}"><button class="mhead press" data-a="togglemeal" data-meal="${id}" aria-expanded="${open}">
      <span class="mico">${ic(icn)}</span><span class="mt"><b>${l}</b><small>${es.length ? es.length + (es.length === 1 ? ' Eintrag' : ' Einträge') : 'Noch leer'}</small></span>${es.length ? `<span class="mk">${r0(kc)}<i>kcal</i></span>` : ''}<span class="chev">${ic('chev')}</span></button>
      <div class="mbody"><div class="mbody-in"><div class="seglist">${rows}</div><button class="addbtn press" data-a="add" data-meal="${id}">${ic('add')}Zu ${l} hinzufügen</button></div></div></section>`;
  }).join('');
  const title = k === today ? 'Heute' : WDL[wdIndex(sel)];
  return `${state.settings.apiKey ? '' : `<button class="banner press fade" data-a="settings">${ic('sparkle')}<span>Noch kein Gemini-API-Key hinterlegt. Hier tippen und einrichten.</span></button>`}
  <div class="weekhead fade"><b>${MONL[sel.getMonth()]} ${sel.getFullYear()}</b><div class="btns">
    <button class="iconbtn small press" data-a="shiftweek" data-n="-7" aria-label="Vorherige Woche">${ic('left')}</button>
    <button class="iconbtn small press" data-a="shiftweek" data-n="7" aria-label="Nächste Woche">${ic('right')}</button></div></div>
  <div class="week fade">${week}</div>
  <div class="pages" id="pages">
    <div class="page"><div class="hero fade2">${ring(t.kcal, g.kcal, g.max)}<div class="heroline">${left >= 0 ? 'noch ' + r0(left) + ' kcal bis zum Ziel' : r0(-left) + ' kcal über dem Ziel'}<small>Ziel ${r0(g.kcal)} · Maximal ${r0(g.max)} kcal</small></div></div>
      <div class="tiles fade2">${tile('t-p', 'Eiweiß', t.protein, g.protein)}${tile('t-c', 'Kohlenhydrate', t.carbs, g.carbs)}${tile('t-f', 'Fett', t.fat, g.fat)}</div></div>
    <div class="page"><div class="card fade"><h3>Mikronährstoffe</h3><div class="microgrid">${micro}</div></div></div>
    <div class="page"><div class="card fade"><h3>Kalorien pro Mahlzeit</h3>${perMeal}<div class="mealrow"><span>Tagesziel</span><b>${r0(g.kcal)} kcal</b></div></div></div>
    ${planPage()}
  </div>
  <div class="dots"><i class="on"></i><i></i><i></i><i></i></div>
  <div class="sechead fade"><div><h2>${title}</h2><small>${sel.getDate()}. ${MONL[sel.getMonth()]}</small></div></div><div class="meals fade">${meals}</div>`;
}
function buildFabMenu() {
  $('#fab').innerHTML = ic('add');
  $('#fabmenu').innerHTML = `<div class="menuhint" id="menuhint">Mahlzeit hinzufügen</div>
    <button class="fabitem press" data-a="lib">${ic('book')}Aus Bibliothek</button>
    <button class="fabitem press" data-a="desc">${ic('edit')}Beschreiben</button>
    <button class="fabitem press" data-a="gal">${ic('image')}Aus Galerie</button>
    <button class="fabitem press" data-a="cam">${ic('camera')}Foto aufnehmen</button>`;
}
function setFab(on) {
  if (on) { const h = $('#menuhint'); if (h) h.textContent = ui.meal ? 'Zu ' + mealLabel(ui.meal) + ' hinzufügen' : 'Mahlzeit hinzufügen'; }
  $('#fab').classList.toggle('open', on); $('#scrim').classList.toggle('on', on);
  $('#fabmenu').classList.toggle('on', on); $('#fabmenu').setAttribute('aria-hidden', String(!on));
  if (!on) ui.meal = null;
}
const fabOpen = () => $('#fab').classList.contains('open');
function render() {
  renderTop();
  $('#view').innerHTML = renderHome();
  document.querySelectorAll('[data-count]').forEach(el => countUp(el, +el.dataset.count));
  requestAnimationFrame(() => requestAnimationFrame(() => document.querySelectorAll('.bar i[data-w]').forEach(i => { i.style.width = i.dataset.w + '%'; })));
  const p = $('#pages');
  if (p) p.addEventListener('scroll', () => {
    const i = Math.round(p.scrollLeft / p.clientWidth);
    document.querySelectorAll('.dots i').forEach((d, n) => d.classList.toggle('on', n === i));
  });
}
window.addEventListener('scroll', () => document.body.classList.toggle('scrolled', window.scrollY > 36), { passive: true });

/* ================= Dialoge (Overlay) ================= */
function newDraft(meal) {
  return { stage: 'choose', meal: meal || ui.meal || guessMeal(), date: ui.date, items: [], photo: '', thumb: '', text: '', name: '', editId: null, append: false, saveMeal: false, mealName: '', libq: '', loadKind: 'text' };
}
function guessMeal() { const h = new Date().getHours(); return h < 10 ? 'breakfast' : h < 15 ? 'lunch' : h < 18 ? 'snack' : 'dinner'; }
function openOverlay() { setFab(false); $('#overlay').hidden = false; $('#overlay').scrollTop = 0; renderOverlay(); }
function closeOverlay() { clearInterval(msgTimer); $('#overlay').hidden = true; draft = null; render(); }
const bar = (title, icon = 'back') => `<div class="appbar"><button class="iconbtn tonal press" data-a="back" aria-label="Zurück">${ic(icon)}</button><h1>${title}</h1></div>`;
const mealGroup = () => `<div class="btngroup">${MEALS.map(([id, , s]) => `<button class="gbtn ${draft.meal === id ? 'on' : ''}" data-a="setmeal" data-meal="${id}">${s}</button>`).join('')}</div>`;
const tf = (label, inner) => `<label class="tf"><span>${label}</span>${inner}</label>`;

function renderOverlay() {
  const d = draft, o = $('#overlay');
  if (!d) return;
  if (d.stage !== 'loading') clearInterval(msgTimer);
  let h = '';
  if (d.stage === 'photo') {
    h = `${bar('Dein Foto', 'close')}<img class="photo" src="${d.photo}" alt="">
    ${tf('Was hast du gegessen? (optional)', `<textarea data-i="text" placeholder="z. B. Pizza Salami, dazu ein kleiner Salat …">${esc(d.text)}</textarea>`)}
    <div class="row"><button class="btn tonal" data-a="analyze" data-skip="1">Überspringen</button><button class="btn" data-a="analyze">${ic('sparkle')}Analysieren</button></div>`;
  } else if (d.stage === 'text') {
    h = `${bar(d.append ? 'Zutat hinzufügen' : 'Mahlzeit beschreiben')}
    ${tf('Beschreibung', `<textarea data-i="text" placeholder="z. B. 2 Spiegeleier, 1 Scheibe Toast mit Butter, ein Glas Orangensaft">${esc(d.text)}</textarea>`)}
    <button class="btn" data-a="analyze" data-textonly="1">${ic('sparkle')}Analysieren</button>`;
  } else if (d.stage === 'loading') {
    const isPhoto = d.loadKind === 'photo';
    const msgs = isPhoto ? MSGS_PHOTO : MSGS_TEXT;
    h = `${bar(isPhoto ? 'Foto wird analysiert' : 'Recherche läuft', 'close')}${loaderHtml({ title: isPhoto ? 'Ich sehe mir dein Essen an' : 'Ich recherchiere die Nährwerte', msgs, photo: isPhoto ? d.photo : '', quote: !isPhoto ? (d.lastText || '').slice(0, 90) : '' })}`;
    setTimeout(() => startMsgs(msgs), 0);
  } else if (d.stage === 'library') {
    h = `${bar('Bibliothek')}${tf('Suchen', `<input data-i="libq" value="${esc(d.libq)}" placeholder="Lebensmittel oder Gericht …">`)}
    <div class="seglist" id="liblist">${libList(d.libq, 'pick')}</div>
    <button class="btn" data-a="toreview" ${d.items.length ? '' : 'disabled'}>Fertig (${d.items.length} Zutaten)</button>`;
  } else if (d.stage === 'libmanage') {
    h = `${bar('Bibliothek')}${tf('Suchen', `<input data-i="libq" value="${esc(d.libq)}" placeholder="Suchen …">`)}<div class="seglist" id="liblist">${libList(d.libq, 'manage')}</div>`;
  } else if (d.stage === 'review') {
    const t = sum(d.items);
    h = `${bar(d.editId ? 'Eintrag bearbeiten' : 'Ergebnis', 'close')}
    ${d.photo ? `<img class="photo" style="max-height:220px" src="${d.photo}" alt="">` : ''}
    ${mealGroup()}
    ${tf('Name der Mahlzeit (optional)', `<input data-i="name" value="${esc(d.name)}">`)}
    <div id="items">${d.items.map((it, i) => itemHtml(it, i)).join('') || '<div class="seg empty">Noch keine Zutaten.</div>'}</div>
    <div class="row"><button class="btn tonal small" data-a="addtext">${ic('sparkle')}Zutat (KI)</button><button class="btn tert small" data-a="lib">${ic('book')}Bibliothek</button></div>
    <div class="total" id="total">${totalHtml(t)}</div>
    <details><summary>Alle Nährstoffe</summary><div class="microgrid" id="micros" style="margin-top:10px">${microHtml(t)}</div></details>
    ${d.items.length > 1 ? `<label class="switch"><span>Als Gericht in der Bibliothek speichern</span><input type="checkbox" data-i="savemeal" ${d.saveMeal ? 'checked' : ''}></label>
    ${d.saveMeal ? tf('Name des Gerichts', `<input data-i="mealname" value="${esc(d.mealName || d.name)}">`) : ''}` : ''}
    <button class="btn" data-a="save" ${d.items.length ? '' : 'disabled'}>Speichern</button>
    ${d.editId ? `<button class="btn danger" data-a="delentry">${ic('delete')}Eintrag löschen</button>` : ''}`;
  } else if (d.stage === 'settings') {
    const s = state.settings, p = s.plan;
    const opts = ui.models.length ? tf('Modell wählen', `<select data-i="model-select">${ui.models.map(m => `<option ${m === s.model ? 'selected' : ''}>${esc(m)}</option>`).join('')}</select>`) : '';
    h = `${bar('Einstellungen', 'close')}
    <div class="secttl" style="margin-top:8px">Ernährungsplan</div>
    ${p ? `<div class="card" style="border-radius:32px"><div class="planline"><span class="pill">Ziel ${p.kcal} kcal</span><span class="pill t">Max ${p.kcal_max} kcal</span><span class="pill">E ${p.protein} · K ${p.carbs} · F ${p.fat} g</span></div><p class="muted" style="margin:0;font-size:14px">${esc(p.summary || '')}</p></div>`
      : tf('Tagesziel Kalorien', `<input type="number" inputmode="numeric" data-i="set" data-f="goal" value="${esc(s.goal)}">`)}
    <button class="btn tonal small" data-a="replan">${ic('sparkle')}${p ? 'Plan neu erstellen' : 'Plan mit KI erstellen'}</button>
    <div class="secttl">Health Connect</div>
    <div class="hcbox" id="hcbox"></div>
    <div class="secttl">Google Gemini</div>
    <label class="tf"><span>API-Key</span><input id="keyinput" type="${ui.showKey ? 'text' : 'password'}" data-i="set" data-f="apiKey" value="${esc(s.apiKey)}" placeholder="AIza…" autocomplete="off" style="padding-right:44px"><button type="button" class="eye press" data-a="eye" aria-label="Key anzeigen">${ic('eye')}</button></label>
    <div class="hint">Kostenlos erstellen unter aistudio.google.com/apikey. Der Key bleibt nur auf diesem Handy.</div>
    <button class="btn" data-a="verify">${ic('check')}Key prüfen</button>
    <div id="keystatus" class="status" hidden></div>
    ${tf('Aktives Modell', `<input data-i="set" data-f="model" value="${esc(s.model)}">`)}${opts}
    <button class="btn tonal small" data-a="models">Verfügbare Modelle laden</button>
    <div class="secttl">Daten</div>
    <button class="libitem press" data-a="libmanage" style="border-radius:28px"><div class="t"><b>Bibliothek verwalten</b><span>${state.library.length} gespeicherte Lebensmittel &amp; Gerichte</span></div>${ic('right')}</button>
    <div class="row"><button class="btn tonal small" data-a="backup-copy">Backup kopieren</button><button class="btn tonal small" data-a="backup-paste">Wiederherstellen</button></div>
    <p class="muted center" style="font-size:13px;margin-top:26px">Farben: ${ui.dynamic ? 'dynamisch nach deinem Hintergrundbild (Material You)' : 'Standard-Palette (dynamische Farben ab Android 12)'}<br>NutriSnap 1.2 · KI-Werte sind Schätzungen</p>`;
  }
  o.innerHTML = `<div class="ov">${h}</div>`;
  updateStatus();
  if (d.stage === 'settings') paintHc();
  kickMorph();
}
function itemHtml(it, i) {
  return `<div class="item"><div class="top"><input data-i="iname" data-idx="${i}" value="${esc(it.name)}" aria-label="Name"><input class="g" type="number" inputmode="decimal" data-i="igrams" data-idx="${i}" value="${r0(it.grams)}" aria-label="Gramm"><span class="muted">g</span><button class="iconbtn small press" data-a="idel" data-idx="${i}" aria-label="Entfernen">${ic('close')}</button></div>
  <div class="nums" id="in${i}">${itemNums(itemVals(it))}</div></div>`;
}
const itemNums = v => `<div class="nchip n-k"><b>${r0(v.kcal)}</b>kcal</div><div class="nchip n-p"><b>${r0(v.protein)}</b>Eiweiß</div><div class="nchip n-c"><b>${r0(v.carbs)}</b>Kohlen.</div><div class="nchip n-f"><b>${r0(v.fat)}</b>Fett</div>`;
const totalHtml = t => `<div class="kc">${r0(t.kcal)} <small>kcal</small></div><div class="sub">Eiweiß ${r0(t.protein)} g · Kohlenhydrate ${r0(t.carbs)} g · Fett ${r0(t.fat)} g</div>`;
const microHtml = t => MICROS.map(([id, l, u]) => `<div class="micro"><span>${l}</span><span>${fmt(t[id], u)}</span></div>`).join('');
function refreshTotals() {
  const t = sum(draft.items);
  const a = $('#total'); if (a) a.innerHTML = totalHtml(t);
  const b = $('#micros'); if (b) b.innerHTML = microHtml(t);
  draft.items.forEach((it, i) => { const e = $('#in' + i); if (e) e.innerHTML = itemNums(itemVals(it)); });
}
async function analyze(skip, textOnly) {
  const d = draft, text = skip ? '' : (d.text || '').trim();
  const useImage = !textOnly && d.photo && !d.append;
  if (textOnly && !text) return toast('Bitte etwas eingeben');
  const prev = d.stage;
  d.loadKind = useImage ? 'photo' : 'text'; d.lastText = text;
  d.stage = 'loading'; renderOverlay();
  const t0 = Date.now();
  try {
    const items = await callGemini(useImage ? d.photo : null, text);
    const wait = 1400 - (Date.now() - t0); if (wait > 0) await sleep(wait);
    if (draft !== d) return;
    if (!items.length) { d.stage = prev; renderOverlay(); return toast('Kein Essen erkannt. Bitte beschreibe es kurz.'); }
    d.items = d.append ? d.items.concat(items) : items;
    d.append = false; d.text = ''; d.stage = 'review'; renderOverlay();
  } catch (e) {
    if (draft !== d) return;
    d.stage = prev; renderOverlay();
    if (e.message === 'NOKEY') { toast('Bitte zuerst den API-Key eintragen.'); d.stage = 'settings'; renderOverlay(); hcRefresh(); }
    else toast('Fehler: ' + e.message);
  }
}
function saveDraft() {
  const d = draft;
  if (!d.items.length) return;
  const name = (d.name || '').trim() || d.items.map(i => i.name).join(', ').slice(0, 60);
  const prevEntry = d.editId ? state.diary.find(e => e.id === d.editId) : null;
  const entry = { id: d.editId || uid(), date: d.date, meal: d.meal, name, thumb: d.thumb || '', items: clone(d.items), ts: d.ts || Date.now() };
  entry.time = entryTime(entry.date, entry.meal, prevEntry);
  const i = d.editId ? state.diary.findIndex(e => e.id === d.editId) : -1;
  if (i >= 0) state.diary[i] = entry; else state.diary.push(entry);
  d.items.forEach(upsertFood);
  if (d.saveMeal && d.items.length > 1) upsertMeal(d.mealName || name, d.items);
  ui.open[entry.meal] = true;
  save(); closeOverlay(); toast('Gespeichert');
  hcPush([entry]);
}
async function photoFlow(src) {
  const meal = ui.meal;
  setFab(false);
  const raw = await pickPhoto(src);
  if (!raw) return;
  try {
    draft = newDraft(meal);
    draft.photo = await shrink(raw, 1024, 0.8);
    draft.thumb = await shrink(raw, 140, 0.6);
    draft.stage = 'photo'; openOverlay();
  } catch (e) { draft = null; toast('Foto konnte nicht geladen werden'); }
}
function goBack() {
  if (!draft) return;
  const s = draft.stage;
  if (s === 'libmanage') { draft.stage = 'settings'; draft.libq = ''; return renderOverlay(); }
  if ((s === 'text' && draft.append) || (s === 'library' && (draft.items.length || draft.editId))) { draft.append = false; draft.stage = 'review'; return renderOverlay(); }
  if (s === 'loading') return;
  closeOverlay();
}

/* ================= Willkommens-Assistent ================= */
const OB_ALL = ['welcome', 'name', 'goal', 'sex', 'age', 'body', 'target', 'pace', 'activity', 'workouts', 'diet', 'allergies', 'conditions', 'meals', 'wishes', 'notes', 'key'];
const GOALS = [['lose', '⚖️', 'Abnehmen', 'Körperfett gesund reduzieren'], ['maintain', '🎯', 'Gewicht halten', 'Energie im Gleichgewicht'], ['gain', '🍚', 'Zunehmen', 'Mit Plan an Gewicht gewinnen'], ['muscle', '💪', 'Muskeln aufbauen', 'Mehr Eiweiß und leichter Überschuss'], ['healthy', '🥗', 'Gesünder essen', 'Ausgewogen und nährstoffreich']];
const SEXES = [['f', '👩', 'Weiblich', ''], ['m', '👨', 'Männlich', ''], ['d', '🧑', 'Divers / keine Angabe', 'Wir rechnen mit einem Mittelwert']];
const ACTS = [['sedentary', '🪑', 'Überwiegend sitzend', 'Büro, Studium, wenig Bewegung'], ['light', '🚶', 'Leicht aktiv', 'Viel Gehen oder Stehen im Alltag'], ['active', '🏃', 'Aktiv', 'Körperlich fordernder Alltag'], ['very', '🏗️', 'Sehr aktiv', 'Schwere körperliche Arbeit']];
const DIETS = [['all', '🍽️', 'Alles', 'Keine Einschränkung'], ['vegetarian', '🥕', 'Vegetarisch', ''], ['vegan', '🌱', 'Vegan', ''], ['pescetarian', '🐟', 'Pescetarisch', 'Fisch ja, Fleisch nein'], ['lowcarb', '🥑', 'Low Carb', 'Weniger Kohlenhydrate'], ['keto', '🥓', 'Keto', 'Sehr wenige Kohlenhydrate']];
const ALLERGIES = [['gluten', 'Gluten'], ['lactose', 'Laktose'], ['nuts', 'Nüsse'], ['peanuts', 'Erdnüsse'], ['eggs', 'Eier'], ['soy', 'Soja'], ['fish', 'Fisch'], ['shellfish', 'Schalentiere'], ['sesame', 'Sesam'], ['none', 'Keine']];
const CONDS = [['diabetes', 'Diabetes'], ['hypertension', 'Bluthochdruck'], ['thyroid', 'Schilddrüse'], ['pregnant', 'Schwangerschaft'], ['breastfeeding', 'Stillzeit'], ['eatingdisorder', 'Essstörung (aktuell oder früher)'], ['none', 'Keine davon']];
const WISHES = [['protein', 'Mehr Eiweiß'], ['sugar', 'Weniger Zucker'], ['fiber', 'Mehr Ballaststoffe'], ['salt', 'Weniger Salz'], ['energy', 'Mehr Energie'], ['cravings', 'Weniger Heißhunger'], ['veggies', 'Mehr Gemüse'], ['mealprep', 'Einfach vorkochen']];
const PACES = { lose: [[0.25, 'Sanft', '☁️'], [0.5, 'Moderat', '🚶'], [0.75, 'Zügig', '⚡']], gain: [[0.25, 'Sanft', '☁️'], [0.5, 'Moderat', '🚶'], [0.75, 'Zügig', '⚡']], muscle: [[0.15, 'Sanft', '☁️'], [0.25, 'Moderat', '🚶'], [0.35, 'Zügig', '⚡']] };

function obDefaults() {
  const p = state.settings.profile;
  return Object.assign({ name: state.settings.name || '', goal: '', sex: '', age: 30, height: 172, weight: 72, target: 68, targetSet: false, pace: 0.5, activity: 'light', workouts: 2, diet: 'all', allergies: [], conditions: [], meals: 3, fasting: false, wishes: [], notes: '' }, p || {});
}
function obStart(redo) {
  ob = { i: redo ? 1 : 0, dir: 1, phase: 'q', d: obDefaults(), plan: null, err: '', redo: !!redo };
  if (redo) { ob.i = 2; } /* beim Wiederholen direkt zum Ziel */
  document.body.classList.add('ob-on');
  $('#ob').hidden = false; $('#ob').classList.remove('leave');
  renderOb();
}
const obSteps = () => OB_ALL.filter(id => id === 'target' ? CHANGE.includes(ob.d.goal) : id === 'pace' ? (CHANGE.includes(ob.d.goal) && Math.abs(num(ob.d.target) - num(ob.d.weight)) >= 1) : true);
const bmiOf = (w, h) => w / Math.pow(h / 100, 2);
function bmiText(b) { return b < 18.5 ? 'Untergewicht' : b < 25 ? 'Normalbereich' : b < 30 ? 'leichtes Übergewicht' : 'Übergewicht'; }
const obOpt = (k, v, em, t, s, num_) => `<button class="opt press ${String(ob.d[k]) === String(v) ? 'on' : ''}" data-a="obpick" data-k="${k}" data-v="${v}" ${num_ ? 'data-num="1"' : ''}><span class="em">${em}</span><span class="tx"><b>${t}</b>${s ? `<small>${s}</small>` : ''}</span><span class="ck">${ic('tick')}</span></button>`;
const obChip = (k, v, label) => `<button class="cchip press ${(ob.d[k] || []).includes(v) ? 'on' : ''}" data-a="obmulti" data-k="${k}" data-v="${v}">${label}</button>`;
const slFill = (v, min, max) => ((v - min) / (max - min) * 100).toFixed(1) + '%';
function obSlider(k, min, max, step, unit, label, big) {
  const v = num(ob.d[k]);
  return `${big ? `<div class="numbox"><span class="bignum" id="obv-${k}">${k === 'weight' || k === 'target' ? de(v) : r0(v)}</span><span class="bigunit">${unit}</span></div>` : `<div class="lbl2"><span>${label}</span><b id="obv-${k}">${k === 'weight' || k === 'target' ? de(v) : r0(v)} ${unit}</b></div>`}
  <input class="sl" type="range" min="${min}" max="${max}" step="${step}" value="${v}" data-i="ob" data-k="${k}" style="--fill:${slFill(v, min, max)}" aria-label="${label}">`;
}
function obLive(id) {
  const d = ob.d, w = num(d.weight), h = num(d.height);
  if (id === 'age') return num(d.age) < 18 ? 'Unter 18 Jahren erstellen wir <b>keinen Diätplan</b>. Dein Plan hält dein Gewicht und unterstützt gesundes Wachstum.' : '';
  if (id === 'body') { const b = bmiOf(w, h); return `Dein BMI liegt bei <b>${de(b)}</b> (${bmiText(b)}).`; }
  if (id === 'target') {
    const diff = num(d.target) - w, b = bmiOf(num(d.target), h);
    return `Das sind <b>${diff > 0 ? '+' : ''}${de(diff)} kg</b>. Dein BMI läge dann bei ${de(b)}.${b < 18.5 && d.goal === 'lose' ? ' <b>Das ist sehr niedrig.</b> Bitte wähle ein gesundes Ziel.' : ''}`;
  }
  return '';
}
function obBody(id) {
  const d = ob.d;
  switch (id) {
    case 'welcome': return { html: `<div class="obwelcome"><div class="obhero"><i class="dec d1"></i><i class="dec d2"></i><i class="dec d3"></i><i class="dec d4"></i><div class="big">${shapeSvg()}<span class="emoji">🥗</span></div></div><h1>Willkommen bei NutriSnap</h1><p>Foto machen, Kalorien sehen. Zuerst stellen wir dir ein paar Fragen, damit die KI einen Ernährungsplan für dich berechnet.</p></div>` };
    case 'name': return { t: 'Wie dürfen wir dich nennen?', s: 'Optional. Wir sprechen dich damit in der App an.', html: `<label class="tf"><span>Dein Name</span><input data-i="ob" data-k="name" value="${esc(d.name)}" placeholder="z. B. Leo" autocomplete="off"></label>` };
    case 'goal': return { t: 'Was möchtest du erreichen?', s: 'Daran richten wir deinen Kalorienbedarf aus.', html: GOALS.map(g => obOpt('goal', ...g)).join('') };
    case 'sex': return { t: 'Wie ist dein biologisches Geschlecht?', s: 'Das beeinflusst den Grundumsatz. Es bleibt auf deinem Gerät.', html: SEXES.map(g => obOpt('sex', ...g)).join('') };
    case 'age': return { t: 'Wie alt bist du?', s: 'Der Energiebedarf ändert sich mit dem Alter.', html: obSlider('age', 14, 90, 1, 'Jahre', 'Alter', true) + `<div class="live" id="oblive">${obLive('age')}</div>` };
    case 'body': return { t: 'Größe und Gewicht', s: 'Damit berechnen wir deinen Grundumsatz.', html: obSlider('height', 130, 215, 1, 'cm', 'Größe') + obSlider('weight', 35, 200, 0.5, 'kg', 'Gewicht') + `<div class="live" id="oblive">${obLive('body')}</div>` };
    case 'target': return { t: 'Wie viel möchtest du wiegen?', s: 'Dein Zielgewicht.', html: obSlider('target', 35, 200, 0.5, 'kg', 'Zielgewicht', true) + `<div class="live" id="oblive">${obLive('target')}</div>` };
    case 'pace': {
      const list = PACES[d.goal] || PACES.lose, diff = Math.abs(num(d.target) - num(d.weight));
      return { t: 'Wie schnell?', s: 'Ein ruhiges Tempo lässt sich länger durchhalten.', html: list.map(([v, l, em]) => obOpt('pace', v, em, l, `${String(v).replace('.', ',')} kg pro Woche · ca. ${Math.ceil(diff / v)} Wochen`, true)).join('') };
    }
    case 'activity': return { t: 'Wie aktiv ist dein Alltag?', s: 'Ohne Sport gerechnet, nur Beruf und Alltag.', html: ACTS.map(g => obOpt('activity', ...g)).join('') };
    case 'workouts': return { t: 'Wie oft trainierst du pro Woche?', s: 'Krafttraining, Laufen, Radfahren oder andere Einheiten.', html: `<div class="cwrap">${[0, 1, 2, 3, 4, 5, 6, 7].map(n => `<button class="cchip press ${num(d.workouts) === n ? 'on' : ''}" data-a="obpick" data-k="workouts" data-v="${n}" data-num="1">${n}×</button>`).join('')}</div>` };
    case 'diet': return { t: 'Wie ernährst du dich?', s: 'Wähle, was am besten passt.', html: DIETS.map(g => obOpt('diet', ...g)).join('') };
    case 'allergies': return { t: 'Allergien oder Unverträglichkeiten?', s: 'Mehrfachauswahl möglich.', html: `<div class="cwrap">${ALLERGIES.map(([v, l]) => obChip('allergies', v, l)).join('')}</div>` };
    case 'conditions': return { t: 'Gibt es etwas, das wir wissen sollten?', s: 'Optional. Wir passen den Plan vorsichtig an. Das ersetzt keine ärztliche Beratung.', html: `<div class="cwrap">${CONDS.map(([v, l]) => obChip('conditions', v, l)).join('')}</div>` };
    case 'meals': return { t: 'Wie viele Mahlzeiten am Tag?', s: 'Inklusive Snacks.', html: `<div class="cwrap">${[2, 3, 4, 5, 6].map(n => `<button class="cchip press ${num(d.meals) === n ? 'on' : ''}" data-a="obpick" data-k="meals" data-v="${n}" data-num="1">${n}</button>`).join('')}</div>
      <label class="switch" style="margin-top:22px"><span>Ich faste zeitweise (z. B. 16:8)</span><input type="checkbox" data-i="obfast" ${d.fasting ? 'checked' : ''}></label>` };
    case 'wishes': return { t: 'Was ist dir wichtig?', s: 'Die KI berücksichtigt das bei Zielen und Tipps.', html: `<div class="cwrap">${WISHES.map(([v, l]) => obChip('wishes', v, l)).join('')}</div>` };
    case 'notes': return { t: 'Noch etwas?', s: 'Optional. Zum Beispiel Lieblingsessen, Schichtdienst oder Dinge, die du nicht magst.', html: `<label class="tf"><span>Deine Wünsche</span><textarea data-i="ob" data-k="notes" placeholder="Schreib einfach los …">${esc(d.notes)}</textarea></label>` };
    case 'key': return { t: 'Letzter Schritt: KI verbinden', s: 'Mit deinem kostenlosen Gemini-API-Key berechnet die KI deinen Plan und analysiert später deine Fotos.', html: `<label class="tf"><span>Gemini-API-Key</span><input id="keyinput" type="${ui.showKey ? 'text' : 'password'}" data-i="set" data-f="apiKey" value="${esc(state.settings.apiKey)}" placeholder="AIza…" autocomplete="off" style="padding-right:44px"><button type="button" class="eye press" data-a="eye" aria-label="Key anzeigen">${ic('eye')}</button></label>
      <div class="hint">Kostenlos unter aistudio.google.com/apikey. Der Key bleibt nur auf diesem Handy.</div><div id="keystatus" class="status" hidden></div>` };
  }
  return { html: '' };
}
function renderOb() {
  const stage = $('#obstage'), foot = $('#obfoot'), top = $('#obtop');
  clearInterval(msgTimer);
  $('#obback').innerHTML = ic('back'); $('#obskip').hidden = true;
  const dirCls = ob.dir > 0 ? 'fwd' : 'back';
  if (ob.phase === 'gen') {
    top.classList.add('hide');
    stage.innerHTML = `<div class="obstep fwd">${loaderHtml({ title: 'Dein Plan entsteht', msgs: MSGS_PLAN })}</div>`;
    foot.innerHTML = '';
    startMsgs(MSGS_PLAN); kickMorph(); return;
  }
  if (ob.phase === 'result') {
    top.classList.add('hide');
    const p = ob.plan, tile = (c, l, v) => `<div class="tile ${c}"><small>${l}</small><b>${r0(v)} g</b></div>`;
    stage.innerHTML = `<div class="obstep fwd obplan">
      <div class="plan-hero stag" style="--i:0"><small>${(ob.d.name ? esc(ob.d.name) + ', dein' : 'Dein')} Tagesziel</small><div class="num"><span data-count="${p.kcal}">0</span><i>kcal</i></div><span class="mx">Maximal ${p.kcal_max} kcal pro Tag</span></div>
      <div class="tiles stag" style="--i:1">${tile('t-p', 'Eiweiß', p.protein)}${tile('t-c', 'Kohlenhydrate', p.carbs)}${tile('t-f', 'Fett', p.fat)}</div>
      <div class="card stag" style="--i:2"><h3>Dein Plan</h3><p style="margin:0 0 10px">${esc(p.summary)}</p>
        <div class="planline"><span class="pill">${p.fiber} g Ballaststoffe</span><span class="pill">${de(p.water_ml / 1000)} l Wasser</span><span class="pill t">Zucker max. ${p.sugar_max} g</span><span class="pill t">Natrium max. ${p.sodium_max} mg</span>${p.weeks ? `<span class="pill">ca. ${p.weeks} Wochen bis zum Ziel</span>` : ''}</div></div>
      <div class="card stag" style="--i:3"><h3>Tipps für dich</h3><ul class="tips">${p.tips.map(t => `<li>${esc(t)}</li>`).join('')}</ul></div>
      <div class="src stag" style="--i:4">${ic(p.src === 'ai' ? 'sparkle' : 'info' in ICONS ? 'info' : 'check')}${p.src === 'ai' ? 'Von Gemini berechnet' : 'Einfache Berechnung' + (ob.err ? ' (KI nicht erreichbar: ' + esc(ob.err) + ')' : ' ohne KI')}. Schätzwerte, kein Ersatz für ärztlichen Rat.</div></div>`;
    foot.innerHTML = `<button class="btn big press" data-a="obfinish">Plan übernehmen ${ic('arrow')}</button>`;
    stage.querySelectorAll('[data-count]').forEach(el => countUp(el, +el.dataset.count, 1100));
    $('#obstage').scrollTop = 0; return;
  }
  const steps = obSteps(), id = steps[ob.i], b = obBody(id);
  const first = id === 'welcome';
  top.classList.toggle('hide', first);
  $('#obprog').style.setProperty('--p', ((ob.i + 1) / (steps.length + 1) * 100).toFixed(1) + '%');
  stage.innerHTML = `<div class="obstep ${dirCls}" data-step="${id}">${b.t ? `<h2 class="obt">${b.t}</h2><p class="obs">${b.s || ''}</p>` : ''}${b.html}</div>`;
  stage.scrollTop = 0;
  let valid = true;
  if (id === 'goal') valid = !!ob.d.goal;
  if (id === 'sex') valid = !!ob.d.sex;
  if (id === 'key') {
    const has = !!state.settings.apiKey;
    foot.innerHTML = `<button class="btn big press" data-a="obkey" ${has ? '' : 'disabled'}>${ic('sparkle')}${state.settings.keyOk ? 'Plan erstellen' : 'Prüfen &amp; Plan erstellen'}</button><button class="textbtn press" data-a="obnokey">Ohne KI fortfahren</button>`;
    updateStatus(); return;
  }
  foot.innerHTML = `<button class="btn big press" data-a="obnext" ${valid ? '' : 'disabled'}>${first ? 'Los geht’s' : 'Weiter'} ${ic('arrow')}</button>${first ? '<button class="textbtn press" data-a="obskip">Später einrichten</button>' : ''}`;
  kickMorph();
}
function obEnter() {
  const steps = obSteps(), id = steps[ob.i], d = ob.d;
  if (id === 'target' && !d.targetSet) d.target = d.goal === 'lose' ? Math.max(40, r0(num(d.weight) - 5)) : r0(num(d.weight) + 4);
  if (id === 'pace') { const ok = (PACES[d.goal] || []).some(p => p[0] === num(d.pace)); if (!ok) d.pace = (PACES[d.goal] || PACES.lose)[1][0]; }
}
function obNext() {
  const steps = obSteps();
  if (ob.i < steps.length - 1) { ob.i++; ob.dir = 1; obEnter(); renderOb(); }
}
function obBack() {
  if (ob.phase === 'result') { ob.phase = 'q'; ob.i = obSteps().length - 1; ob.dir = -1; renderOb(); return; }
  if (ob.phase === 'gen') return;
  if (ob.i > 0 && !(ob.redo && ob.i <= 2)) { ob.i--; ob.dir = -1; renderOb(); }
  else if (ob.redo) obClose();
}
function obClose() {
  $('#ob').classList.add('leave');
  setTimeout(() => { $('#ob').hidden = true; $('#ob').classList.remove('leave'); document.body.classList.remove('ob-on'); ob = null; clearInterval(msgTimer); render(); }, 560);
}
async function obGenerate(useAI) {
  ob.phase = 'gen'; ob.err = ''; renderOb();
  const t0 = Date.now(), loc = calcPlan(ob.d);
  let plan = loc;
  if (useAI && state.settings.apiKey) {
    try { plan = await aiPlan(ob.d, loc); } catch (e) { ob.err = e.message === 'NOKEY' ? '' : e.message; plan = loc; }
  }
  const wait = 3000 - (Date.now() - t0); if (wait > 0) await sleep(wait);
  if (!ob) return;
  ob.plan = plan; ob.phase = 'result'; ob.dir = 1; renderOb();
}
function obFinish() {
  const s = state.settings, d = ob.d;
  s.name = (d.name || '').trim(); s.profile = clone(d); s.plan = ob.plan; s.goal = ob.plan.kcal; s.onboarded = true;
  save(); toast('Dein Plan ist aktiv ✓'); obClose();
}
function obSkip() {
  state.settings.onboarded = true; save(); obClose();
}

/* ================= Ereignisse ================= */
const actions = {
  date(el) { ui.date = el.dataset.date; render(); },
  shiftweek(el) { ui.date = dkey(addDays(parseKey(ui.date), +el.dataset.n)); render(); },
  togglemeal(el) {
    const id = el.dataset.meal, sec = el.closest('.meal'); if (!sec) return;
    const open = !sec.classList.contains('open');
    ui.open[id] = open; sec.classList.toggle('open', open); el.setAttribute('aria-expanded', String(open));
  },
  fab() { if (fabOpen()) setFab(false); else { ui.meal = null; setFab(true); } },
  fabclose() { setFab(false); },
  add(el) { ui.meal = el.dataset.meal; setFab(true); },
  async cam() { await photoFlow('camera'); },
  async gal() { await photoFlow('photos'); },
  desc() { const m = ui.meal; draft = newDraft(m); draft.stage = 'text'; openOverlay(); },
  lib() { if (!draft) { const m = ui.meal; draft = newDraft(m); } draft.stage = 'library'; openOverlay(); },
  settings() { setFab(false); draft = newDraft(); draft.stage = 'settings'; openOverlay(); hcRefresh(); },
  libmanage() { draft.stage = 'libmanage'; draft.libq = ''; renderOverlay(); },
  replan() { closeOverlay(); obStart(!!state.settings.profile || state.settings.onboarded); },
  edit(el) {
    const e = state.diary.find(x => x.id === el.dataset.id); if (!e) return;
    draft = Object.assign(newDraft(e.meal), { stage: 'review', date: e.date, items: clone(e.items), thumb: e.thumb, photo: e.thumb, name: e.name, editId: e.id, ts: e.ts });
    openOverlay();
  },
  back() { goBack(); },
  setmeal(el) { draft.meal = el.dataset.meal; renderOverlay(); },
  toreview() {
    draft.append = false;
    if (!draft.items.length && !draft.editId) return closeOverlay();
    draft.stage = 'review'; renderOverlay();
  },
  addtext() { draft.stage = 'text'; draft.append = true; draft.text = ''; renderOverlay(); },
  analyze(el) { analyze(!!el.dataset.skip, !!el.dataset.textonly); },
  idel(el) { draft.items.splice(+el.dataset.idx, 1); renderOverlay(); },
  save() { saveDraft(); },
  delentry() {
    if (!confirm('Eintrag wirklich löschen?')) return;
    const id = draft.editId;
    state.diary = state.diary.filter(e => e.id !== id); save(); closeOverlay(); hcRemove([id]);
  },
  libdel(el) {
    if (!confirm('Aus der Bibliothek löschen?')) return;
    state.library = state.library.filter(l => l.id !== el.dataset.id); save(); renderOverlay();
  },
  eye() { ui.showKey = !ui.showKey; const i = $('#keyinput'); if (i) i.type = ui.showKey ? 'text' : 'password'; },
  verify() { verifyKey(); },
  async models() {
    if (!state.settings.apiKey) return toast('Erst den API-Key eintragen');
    try { ui.models = (await listModels()).sort(); toast(ui.models.length + ' Modelle gefunden'); renderOverlay(); }
    catch (e) { toast('Fehler: ' + e.message); }
  },
  async hcconnect() {
    const hb = HB(); if (!hb) return;
    try { const r = await hb.requestPermissions(); await hcRefresh(); if (r && r.granted) { state.settings.hcAuto = true; save(); const n = await hcPush(state.diary); toast(n ? n + ' Mahlzeiten an Health Connect gesendet ✓' : 'Health Connect verbunden ✓'); } else toast('Zugriff wurde nicht erteilt'); }
    catch (e) { toast('Health Connect: ' + e.message); }
  },
  async hcsync() { const n = await hcPush(state.diary); toast(n ? n + ' Mahlzeiten gesendet ✓' : 'Nichts zu senden'); },
  async hcopen() { try { await HB().openSettings(); } catch (e) { toast('Konnte Health Connect nicht öffnen'); } },
  async hcstore() { try { await HB().openStore(); } catch (e) { toast('Play Store nicht erreichbar'); } },
  hcrefresh() { ui.hc = { s: 'unknown' }; paintHc(); hcRefresh(); },
  async 'backup-copy'() {
    try { await navigator.clipboard.writeText(JSON.stringify(state)); toast('Backup kopiert. Füge es z. B. in eine Notiz ein.'); }
    catch (e) { toast('Kopieren nicht möglich'); }
  },
  'backup-paste'() {
    const t = prompt('Backup-Text hier einfügen (ersetzt alle aktuellen Daten):');
    if (!t) return;
    try {
      const s = JSON.parse(t);
      if (!Array.isArray(s.diary) || !Array.isArray(s.library)) throw new Error('x');
      state = { settings: Object.assign({}, DEFAULT_SETTINGS, s.settings || {}), library: s.library, diary: s.diary };
      save(); render(); renderOverlay(); toast('Backup wiederhergestellt');
    } catch (e) { toast('Das war kein gültiges Backup'); }
  },
  /* Willkommens-Assistent */
  obnext() { obNext(); },
  obback() { obBack(); },
  obskip() { obSkip(); },
  obpick(el) {
    const k = el.dataset.k; ob.d[k] = el.dataset.num ? +el.dataset.v : el.dataset.v;
    if (k === 'goal' || k === 'sex' || k === 'activity' || k === 'diet' || k === 'pace' || k === 'workouts' || k === 'meals') {
      const st = $('#obstage .obstep');
      st.querySelectorAll('[data-k="' + k + '"]').forEach(b => b.classList.toggle('on', String(b.dataset.v) === String(ob.d[k])));
      const nb = $('[data-a="obnext"]'); if (nb) nb.disabled = false;
    }
  },
  obmulti(el) {
    const k = el.dataset.k, v = el.dataset.v, arr = ob.d[k] || [];
    let next;
    if (v === 'none') next = arr.includes('none') ? [] : ['none'];
    else { next = arr.filter(x => x !== 'none'); next = next.includes(v) ? next.filter(x => x !== v) : next.concat(v); }
    ob.d[k] = next;
    document.querySelectorAll('#obstage [data-k="' + k + '"]').forEach(b => b.classList.toggle('on', next.includes(b.dataset.v)));
  },
  async obkey() {
    if (!state.settings.keyOk) { await verifyKey(); }
    if (ui.key.s === 'ok' || state.settings.keyOk) obGenerate(true);
    else renderObKeyButtons();
  },
  obnokey() { obGenerate(false); },
  obfinish() { obFinish(); }
};
function renderObKeyButtons() {
  const b = $('[data-a="obkey"]'); if (b) b.disabled = !state.settings.apiKey;
}

document.addEventListener('click', e => {
  const libadd = e.target.closest('[data-libadd]');
  if (libadd && draft) {
    const l = state.library.find(x => x.id === libadd.dataset.libadd);
    if (l) {
      l.items.forEach(it => draft.items.push(Object.assign(clone(it), { id: uid() })));
      l.used = (l.used || 0) + 1; save();
      toast('+ ' + l.name); renderOverlay();
    }
    return;
  }
  const el = e.target.closest('[data-a]');
  if (el && actions[el.dataset.a]) actions[el.dataset.a](el, e);
});
document.addEventListener('input', e => {
  const t = e.target, i = t.dataset && t.dataset.i;
  if (!i) return;
  if (i === 'ob' && ob) {
    const k = t.dataset.k;
    if (t.type === 'range') {
      const v = +t.value; ob.d[k] = v; if (k === 'target') ob.d.targetSet = true;
      t.style.setProperty('--fill', slFill(v, +t.min, +t.max));
      const out = $('#obv-' + k); if (out) out.textContent = (k === 'weight' || k === 'target' ? de(v) : r0(v)) + (out.classList.contains('bignum') ? '' : ' ' + (k === 'height' ? 'cm' : k === 'age' ? 'Jahre' : 'kg'));
      const live = $('#oblive'); if (live) live.innerHTML = obLive($('#obstage .obstep').dataset.step);
    } else ob.d[k] = t.value;
    return;
  }
  if (i === 'text' && draft) draft.text = t.value;
  else if (i === 'name' && draft) draft.name = t.value;
  else if (i === 'mealname' && draft) draft.mealName = t.value;
  else if (i === 'iname' && draft) draft.items[+t.dataset.idx].name = t.value;
  else if (i === 'igrams' && draft) { draft.items[+t.dataset.idx].grams = num(t.value); refreshTotals(); }
  else if (i === 'libq' && draft) {
    draft.libq = t.value;
    const l = $('#liblist'); if (l) l.innerHTML = libList(t.value, draft.stage === 'libmanage' ? 'manage' : 'pick');
  } else if (i === 'set') {
    const f = t.dataset.f;
    if (f === 'apiKey') { state.settings.apiKey = t.value.trim(); state.settings.keyOk = false; ui.key = { s: 'idle' }; updateStatus(); if (ob) renderObKeyButtons(); }
    else if (f === 'goal') state.settings.goal = num(t.value) || 2000;
    else state.settings[f] = t.value.trim();
    save();
  }
});
document.addEventListener('change', e => {
  const t = e.target, i = t.dataset && t.dataset.i;
  if (i === 'savemeal' && draft) { draft.saveMeal = t.checked; renderOverlay(); }
  else if (i === 'model-select') { state.settings.model = t.value; save(); toast('Modell: ' + t.value); }
  else if (i === 'obfast' && ob) ob.d.fasting = t.checked;
  else if (i === 'hcauto') { state.settings.hcAuto = t.checked; save(); }
  else if (i === 'set' && t.dataset.f === 'apiKey' && state.settings.apiKey.length > 20 && !ob) verifyKey();
});

/* Android-Zurück-Taste */
(function backButton() {
  const cap = window.Capacitor, app = cap && cap.Plugins && cap.Plugins.App;
  if (!app || !app.addListener) return;
  app.addListener('backButton', () => {
    if (!$('#ob').hidden) return obBack();
    if (!$('#overlay').hidden) return goBack();
    if (fabOpen()) return setFab(false);
    if (app.exitApp) app.exitApp();
  });
  app.addListener('appStateChange', s => { if (s && s.isActive) { refreshTheme(); if (!$('#overlay').hidden && draft && draft.stage === 'settings') hcRefresh(); } });
})();

window.applySystemTheme = t => { try { localStorage.setItem(THEME_KEY, JSON.stringify(t)); } catch (e) { /* egal */ } applyPalette(t); };
window.__nutrisnap = { get state() { return state; }, get draft() { return draft; }, get ob() { return ob; }, ui, render, callGemini, saveDraft, sum, actions, applyPalette, verifyKey, calcPlan, sanitizePlan, hcPush, hcRefresh };

buildFabMenu();
render();
refreshTheme();
hcRefresh();
if (!state.settings.onboarded) obStart(false);
})();
