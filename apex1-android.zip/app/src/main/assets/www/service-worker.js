const CACHE = 'apex1-shell-v40';
const SHELL_ASSETS = [
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  './icon-512-maskable.png',
  './icon-180.png',
  './favicon-32.png',
  './widgets/next-race-template.json'
];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(SHELL_ASSETS)));
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
  );
  self.clients.claim();
});

// Network-first for the app shell (HTML/JS) so fixes and updates always
// reach the installed PWA immediately. Falls back to cache only if offline.
// Static icons/manifest use cache-first since they rarely change.
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return; // let API calls go straight to network

  const isStaticAsset = SHELL_ASSETS.some((a) => url.pathname.endsWith(a.replace('./', '')));

  if (isStaticAsset) {
    event.respondWith(caches.match(event.request).then((cached) => cached || fetch(event.request)));
  } else {
    event.respondWith(
      fetch(event.request)
        .then((res) => {
          const clone = res.clone();
          caches.open(CACHE).then((cache) => cache.put(event.request, clone));
          return res;
        })
        .catch(() => caches.match(event.request))
    );
  }
});

// ---- Widgets (PWA-Widgets-API, derzeit nur Edge/Windows 11 unterstützt) ----
async function buildNextRaceData(){
  const res = await fetch('https://api.jolpi.ca/ergast/f1/current.json?limit=40');
  const races = (await res.json())?.MRData?.RaceTable?.Races || [];
  const now = Date.now();
  const toDate = (r) => new Date(r.time ? `${r.date}T${r.time}` : `${r.date}T12:00:00Z`);
  const next = races.find(r => toDate(r).getTime() > now);
  if(!next) return { label: 'APEX/1', title: 'Saison beendet', circuit: '', when: 'Bis zur nächsten Saison!' };
  const d = toDate(next);
  return {
    label: `Nächstes Rennen · Runde ${next.round}`,
    title: next.raceName,
    circuit: next.Circuit?.circuitName || '',
    when: d.toLocaleString('de-DE', { weekday:'long', day:'2-digit', month:'long', hour:'2-digit', minute:'2-digit' })
  };
}
async function updateNextRaceWidget(widget){
  try{
    const data = await buildNextRaceData();
    const templateText = await (await fetch(widget.definition.msAcTemplate || 'widgets/next-race-template.json')).text();
    await self.widgets.updateByInstanceId(widget.instanceId, { template: templateText, data: JSON.stringify(data) });
  }catch(e){ /* offline — Widget behält den letzten Stand */ }
}
self.addEventListener('widgetinstall', (e) => { e.waitUntil(updateNextRaceWidget(e.widget)); });
self.addEventListener('widgetresume', (e) => { e.waitUntil(updateNextRaceWidget(e.widget)); });
