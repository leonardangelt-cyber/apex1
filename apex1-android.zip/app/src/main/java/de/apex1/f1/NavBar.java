package de.apex1.f1;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Native Navigationsleiste im Material-3-Stil mit Pillen-Indikator. */
final class NavBar extends LinearLayout {
    interface Listener { void pick(String tab); }

    static final String[] TABS = { "calendar", "standings", "news", "more" };
    private static final String[] LABELS = { "Kalender", "Wertung", "News", "Karte" };
    private static final String[] ICONS = { IconView.CALENDAR, IconView.TROPHY, IconView.ARTICLE, IconView.MAP };

    private final View[] pills = new View[4];
    private final IconView[] icons = new IconView[4];
    private final TextView[] labels = new TextView[4];
    private final float density;
    private int selected = -1;

    NavBar(Context c, final Listener l) {
        super(c);
        density = c.getResources().getDisplayMetrics().density;
        setOrientation(HORIZONTAL);
        setBackgroundColor(Palette.card);
        setPadding(dp(8), dp(12), dp(8), dp(14));
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            LinearLayout item = new LinearLayout(c);
            item.setOrientation(VERTICAL);
            item.setGravity(Gravity.CENTER_HORIZONTAL);
            item.setClickable(true);
            FrameLayout box = new FrameLayout(c);
            View pill = new View(c);
            GradientDrawable g = new GradientDrawable();
            g.setColor(Palette.secondaryC);
            g.setCornerRadius(dp(16));
            pill.setBackground(g);
            pill.setAlpha(0f);
            box.addView(pill, new FrameLayout.LayoutParams(dp(64), dp(32), Gravity.CENTER));
            IconView ic = new IconView(c, ICONS[i], Palette.onVariant);
            box.addView(ic, new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER));
            item.addView(box, new LinearLayout.LayoutParams(dp(64), dp(32)));
            TextView t = new TextView(c);
            t.setText(LABELS[i]);
            t.setTextSize(12);
            t.setTextColor(Palette.onVariant);
            t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            t.setPadding(0, dp(4), 0, 0);
            item.addView(t);
            pills[i] = pill; icons[i] = ic; labels[i] = t;
            item.setOnClickListener(new OnClickListener() { @Override public void onClick(View v) {
                if (idx == selected) return;
                Palette.tick(v);
                l.pick(TABS[idx]);
            } });
            addView(item, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
    }

    private int dp(float v) { return (int) (v * density + 0.5f); }

    void select(String tab) {
        int idx = 0;
        for (int i = 0; i < TABS.length; i++) if (TABS[i].equals(tab)) idx = i;
        if (idx == selected) return;
        for (int i = 0; i < 4; i++) {
            boolean on = i == idx;
            icons[i].setColor(on ? Palette.onSecondaryC : Palette.onVariant);
            labels[i].setTextColor(on ? Palette.onSurface : Palette.onVariant);
            labels[i].setTypeface(Typeface.create("sans-serif-medium", on ? Typeface.BOLD : Typeface.NORMAL));
            if (on) {
                pills[i].setScaleX(selected < 0 ? 1f : 0.35f);
                pills[i].animate().alpha(1f).scaleX(1f).setDuration(selected < 0 ? 0 : 420).setInterpolator(new OvershootInterpolator(1.6f)).start();
            } else {
                pills[i].animate().alpha(0f).setDuration(160).start();
            }
        }
        selected = idx;
    }
}
