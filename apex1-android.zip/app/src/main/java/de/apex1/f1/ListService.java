package de.apex1.f1;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.view.View;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Liefert die scrollbaren Zeilen für Fahrer-WM und Team-WM (alle Plätze). */
public class ListService extends RemoteViewsService {
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new Factory(getApplicationContext(), "team".equals(intent.getStringExtra("kind")));
    }

    static class Item { String pos, name, sub, pts; int color; Bitmap logo; }

    static class Factory implements RemoteViewsFactory {
        private final Context c;
        private final boolean team;
        private List<Item> items = new ArrayList<>();

        Factory(Context c, boolean team) { this.c = c; this.team = team; }

        @Override public void onCreate() { }

        @Override
        public void onDataSetChanged() {
            List<Item> out = new ArrayList<>();
            try {
                JSONArray arr = team ? F1.teamStandings(c) : F1.driverStandings(c);
                for (int i = 0; arr != null && i < arr.length(); i++) {
                    JSONObject s = arr.getJSONObject(i);
                    Item it = new Item();
                    it.pos = s.optString("position", String.valueOf(i + 1));
                    it.pts = s.optString("points", "0");
                    if (team) {
                        JSONObject t = s.getJSONObject("Constructor");
                        it.name = t.optString("name");
                        it.sub = s.optString("wins", "0") + " Siege";
                        it.color = F1.teamColor(it.name);
                        it.logo = F1.legibleOnDark(F1.teamLogo(c, t, 120));
                    } else {
                        JSONObject d = s.getJSONObject("Driver");
                        String given = d.optString("givenName", "");
                        it.name = given.isEmpty() ? d.optString("familyName") : given.charAt(0) + ". " + d.optString("familyName");
                        it.sub = F1.lastTeamName(s);
                        it.color = F1.teamColor(it.sub);
                    }
                    out.add(it);
                }
            } catch (Exception ignored) { }
            if (!out.isEmpty()) items = out;
        }

        @Override public void onDestroy() { items.clear(); }
        @Override public int getCount() { return items.size(); }

        @Override
        public RemoteViews getViewAt(int i) {
            RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.item_standing);
            if (i >= items.size()) return v;
            Item it = items.get(i);
            v.setTextViewText(R.id.rw_pos, it.pos);
            v.setInt(R.id.rw_bar, "setColorFilter", it.color);
            v.setTextViewText(R.id.rw_name, it.name);
            v.setTextViewText(R.id.rw_sub, it.sub);
            v.setTextViewText(R.id.rw_pts, it.pts);
            if (it.logo != null) {
                v.setImageViewBitmap(R.id.rw_logo, it.logo);
                v.setViewVisibility(R.id.rw_logo, View.VISIBLE);
            } else v.setViewVisibility(R.id.rw_logo, View.GONE);
            v.setOnClickFillInIntent(R.id.it_root, new Intent());
            return v;
        }

        @Override public RemoteViews getLoadingView() { return null; }
        @Override public int getViewTypeCount() { return 1; }
        @Override public long getItemId(int i) { return i; }
        @Override public boolean hasStableIds() { return true; }
    }
}
