package de.apex1.f1;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Widget "Nächstes Rennen". */
public class NextRaceWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(final Context ctx, final AppWidgetManager mgr, final int[] ids) {
        final BroadcastReceiver.PendingResult pr = goAsync();
        new Thread(() -> {
            try {
                String label = "APEX/1", title = "Keine Daten", circuit = "", when = "Bitte Internet prüfen", countdown = "";
                String json = Api.get(ctx, "https://api.jolpi.ca/ergast/f1/current.json?limit=40", "races");
                if (json != null) {
                    try {
                        JSONArray races = new JSONObject(json).getJSONObject("MRData")
                                .getJSONObject("RaceTable").getJSONArray("Races");
                        SimpleDateFormat iso = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
                        iso.setTimeZone(TimeZone.getTimeZone("UTC"));
                        SimpleDateFormat out = new SimpleDateFormat("EEEE, dd. MMMM · HH:mm 'Uhr'", Locale.GERMANY);
                        long now = System.currentTimeMillis();
                        boolean found = false;
                        for (int i = 0; i < races.length(); i++) {
                            JSONObject r = races.getJSONObject(i);
                            String time = r.optString("time", "12:00:00Z");
                            if (!time.endsWith("Z")) time = time + "Z";
                            Date d = iso.parse(r.getString("date") + "T" + time);
                            if (d != null && d.getTime() > now) {
                                label = "Nächstes Rennen · Runde " + r.getString("round");
                                title = r.getString("raceName");
                                circuit = r.getJSONObject("Circuit").optString("circuitName", "");
                                when = out.format(d);
                                long days = (long) Math.ceil((d.getTime() - now) / 86400000.0);
                                countdown = days <= 0 ? "Heute" : (days == 1 ? "Morgen" : "in " + days + " Tagen");
                                found = true;
                                break;
                            }
                        }
                        if (!found) { title = "Saison beendet"; when = "Bis zur nächsten Saison!"; }
                    } catch (Exception e) {
                        title = "Daten nicht lesbar";
                    }
                }

                Intent open = new Intent(ctx, MainActivity.class);
                PendingIntent pi = PendingIntent.getActivity(ctx, 0, open,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                for (int id : ids) {
                    RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_next_race);
                    v.setTextViewText(R.id.w_label, label);
                    v.setTextViewText(R.id.w_title, title);
                    v.setTextViewText(R.id.w_circuit, circuit);
                    v.setTextViewText(R.id.w_when, when);
                    v.setTextViewText(R.id.w_countdown, countdown);
                    v.setOnClickPendingIntent(R.id.w_root, pi);
                    mgr.updateAppWidget(id, v);
                }
            } finally {
                pr.finish();
            }
        }).start();
    }
}
