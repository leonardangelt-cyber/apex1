package de.apex1.f1;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** F1-Nachrichten per RSS (Motorsport-Total, Ersatz: Motorsport.com) – direkt, ohne Proxy. */
final class News {
    private News() {}

    static final String[][] SOURCES = {
            {"https://www.motorsport-total.com/rss/rss_formel-1.xml", "Motorsport-Total"},
            {"https://www.motorsport.com/rss/f1/news/", "Motorsport.com"},
    };

    static class Item { String title, link, img, source; long time; }

    private static String clean(String s) {
        if (s == null) return "";
        s = s.trim();
        if (s.startsWith("<![CDATA[")) s = s.substring(9);
        if (s.endsWith("]]>")) s = s.substring(0, s.length() - 3);
        return s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
                .replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'").trim();
    }

    private static String tag(String block, String name) {
        Matcher m = Pattern.compile("<" + name + "[^>]*>([\\s\\S]*?)</" + name + ">", Pattern.CASE_INSENSITIVE).matcher(block);
        return m.find() ? m.group(1) : "";
    }

    private static String attr(String block, String regex) {
        Matcher m = Pattern.compile(regex, Pattern.CASE_INSENSITIVE).matcher(block);
        return m.find() ? m.group(1) : "";
    }

    private static long date(String s) {
        String[] fmts = {"EEE, dd MMM yyyy HH:mm:ss Z", "EEE, dd MMM yyyy HH:mm:ss z"};
        for (String f : fmts) {
            try {
                Date d = new SimpleDateFormat(f, Locale.US).parse(s.trim());
                if (d != null) return d.getTime();
            } catch (Exception ignored) { }
        }
        return 0L;
    }

    static List<Item> parse(String xml, String source) {
        List<Item> out = new ArrayList<>();
        String[] parts = xml.split("(?i)<item[\\s>]");
        for (int i = 1; i < parts.length; i++) {
            String block = parts[i];
            int end = block.toLowerCase(Locale.ROOT).indexOf("</item>");
            if (end >= 0) block = block.substring(0, end);
            Item it = new Item();
            it.title = clean(tag(block, "title"));
            it.link = clean(tag(block, "link"));
            it.time = date(clean(tag(block, "pubDate")));
            it.source = source;
            String img = attr(block, "<enclosure[^>]*url=\"([^\"]+)\"");
            if (img.isEmpty()) img = attr(block, "<media:content[^>]*url=\"([^\"]+)\"");
            if (img.isEmpty()) img = attr(block, "<media:thumbnail[^>]*url=\"([^\"]+)\"");
            it.img = img.replace("&amp;", "&");
            if (!it.title.isEmpty() && it.link.startsWith("http")) out.add(it);
        }
        return out;
    }

    /** Frische Artikel (max. 25); bei Netzfehler der zuletzt gespeicherte Stand. */
    static List<Item> load(Context c) {
        SharedPreferences p = c.getSharedPreferences("apex1_widgets", Context.MODE_PRIVATE);
        for (String[] s : SOURCES) {
            try {
                String xml = new String(F1.download(s[0], 9000), "UTF-8");
                List<Item> items = parse(xml, s[1]);
                if (items.isEmpty()) continue;
                if (items.size() > 25) items = new ArrayList<>(items.subList(0, 25));
                JSONArray a = new JSONArray();
                for (Item it : items) {
                    JSONObject o = new JSONObject();
                    o.put("t", it.title); o.put("l", it.link); o.put("i", it.img); o.put("s", it.source); o.put("d", it.time);
                    a.put(o);
                }
                p.edit().putString("news_cache", a.toString()).apply();
                return items;
            } catch (Exception ignored) { }
        }
        List<Item> cached = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(p.getString("news_cache", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Item it = new Item();
                it.title = o.optString("t"); it.link = o.optString("l"); it.img = o.optString("i");
                it.source = o.optString("s"); it.time = o.optLong("d");
                cached.add(it);
            }
        } catch (Exception ignored) { }
        return cached;
    }

    static String ago(long t) {
        if (t <= 0) return "";
        long m = Math.max(0, (System.currentTimeMillis() - t) / 60000L);
        if (m < 60) return "vor " + Math.max(1, m) + " Min.";
        long h = m / 60;
        if (h < 24) return "vor " + h + " Std.";
        long d = h / 24;
        return d == 1 ? "gestern" : "vor " + d + " Tagen";
    }

    /** Bild als abgerundetes Quadrat/Rechteck zuschneiden (Mitte). */
    static Bitmap thumb(Bitmap src, int w, int h) {
        if (src == null) return null;
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        Path clip = new Path();
        float r = h * 0.28f;
        clip.addRoundRect(new RectF(0, 0, w, h), r, r, Path.Direction.CW);
        cv.clipPath(clip);
        float scale = Math.max(w * 1f / src.getWidth(), h * 1f / src.getHeight());
        float sw = src.getWidth() * scale, sh = src.getHeight() * scale;
        cv.drawBitmap(src, null, new RectF((w - sw) / 2f, (h - sh) / 2f, (w + sw) / 2f, (h + sh) / 2f),
                new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG));
        return out;
    }
}
