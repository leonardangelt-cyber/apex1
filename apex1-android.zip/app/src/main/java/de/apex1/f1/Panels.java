package de.apex1.f1;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

/** Zeichnet die farbigen Bild-Kacheln der Profil-Widgets. */
final class Panels {
    private Panels() {}

    private static Bitmap base(int w, int h, int color, Canvas[] out) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        float r = h * 0.12f;
        Path clip = new Path();
        clip.addRoundRect(new RectF(0, 0, w, h), r, r, Path.Direction.CW);
        c.clipPath(clip);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, w, h, color, F1.darker(color, 0.55f), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        out[0] = c;
        return b;
    }

    private static void watermark(Canvas c, int w, int h, String text) {
        if (text == null || text.isEmpty()) return;
        Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
        t.setTypeface(Typeface.create("sans-serif-black", Typeface.ITALIC));
        t.setColor(0x33FFFFFF);
        float size = h * 0.95f;
        t.setTextSize(size);
        while (t.measureText(text) > w * 1.05f && size > 20) { size -= 6; t.setTextSize(size); }
        t.setTextAlign(Paint.Align.CENTER);
        c.drawText(text, w * 0.55f, h * 0.78f, t);
    }

    /** Fahrer: Teamfarbe, Startnummer als Wasserzeichen; Fotos mit Hintergrund füllen die ganze Kachel. */
    static Bitmap driver(int color, Bitmap photo, String number) {
        int w = 640, h = 640;
        Canvas[] cc = new Canvas[1];
        Bitmap b = base(w, h, color, cc);
        Canvas c = cc[0];
        Paint bmp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        if (photo != null && !photo.hasAlpha()) {
            // normales Foto (z. B. JPEG): vollflächig, Gesicht oben ausgerichtet – keine weißen Reste
            float scale = Math.max(w * 1f / photo.getWidth(), h * 1f / photo.getHeight());
            float pw = photo.getWidth() * scale, ph = photo.getHeight() * scale;
            c.drawBitmap(photo, null, new RectF((w - pw) / 2f, 0, (w + pw) / 2f, ph), bmp);
            Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
            g.setShader(new LinearGradient(0, h * 0.55f, 0, h, 0x00000000, (color & 0x00FFFFFF) | 0xB0000000, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, g);
            return b;
        }
        watermark(c, w, h, number);
        if (photo != null) {
            float scale = Math.min(w * 1.0f / photo.getWidth(), h * 0.98f / photo.getHeight());
            float pw = photo.getWidth() * scale, ph = photo.getHeight() * scale;
            c.drawBitmap(photo, null, new RectF((w - pw) / 2f, h - ph, (w + pw) / 2f, h), bmp);
        }
        return b;
    }

    /** Team: Auto-Foto als Hintergrund, Logo als weiße Silhouette ohne Kasten. */
    static Bitmap team(int color, Bitmap logo, String initials, Bitmap car) {
        int w = 640, h = 640;
        Canvas[] cc = new Canvas[1];
        Bitmap b = base(w, h, color, cc);
        Canvas c = cc[0];
        Paint bmp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        Bitmap white = logo == null ? null : F1.logoForPanel(logo, color);

        if (car != null) {
            float scale = Math.max(w * 1f / car.getWidth(), h * 1f / car.getHeight());
            float cw = car.getWidth() * scale, ch = car.getHeight() * scale;
            c.drawBitmap(car, null, new RectF((w - cw) / 2f, (h - ch) / 2f, (w + cw) / 2f, (h + ch) / 2f), bmp);
            Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
            g.setShader(new LinearGradient(0, h * 0.35f, 0, h, 0x00000000, (color & 0x00FFFFFF) | 0xCC000000, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, g);
            Paint top = new Paint(Paint.ANTI_ALIAS_FLAG);
            top.setShader(new LinearGradient(0, 0, 0, h * 0.4f, 0x88000000, 0x00000000, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h * 0.4f, top);
            drawLogo(c, new RectF(w * 0.07f, w * 0.07f, w * 0.07f + w * 0.34f, w * 0.07f + w * 0.34f), white, initials, w * 0.34f);
            return b;
        }
        watermark(c, w, h, initials);
        float tile = w * 0.6f;
        drawLogo(c, new RectF((w - tile) / 2f, (h - tile) / 2f, (w + tile) / 2f, (h + tile) / 2f), white, initials, tile);
        return b;
    }

    private static void drawLogo(Canvas c, RectF r, Bitmap logo, String initials, float size) {
        if (logo != null) {
            float scale = Math.min(r.width() / logo.getWidth(), r.height() / logo.getHeight());
            float lw = logo.getWidth() * scale, lh = logo.getHeight() * scale;
            c.drawBitmap(logo, null, new RectF(r.centerX() - lw / 2f, r.centerY() - lh / 2f, r.centerX() + lw / 2f, r.centerY() + lh / 2f),
                    new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG));
        } else {
            Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
            t.setColor(0xFFFFFFFF);
            t.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
            t.setTextSize(size * 0.5f);
            t.setTextAlign(Paint.Align.CENTER);
            c.drawText(initials == null ? "" : initials, r.centerX(), r.centerY() + size * 0.17f, t);
        }
    }
}
