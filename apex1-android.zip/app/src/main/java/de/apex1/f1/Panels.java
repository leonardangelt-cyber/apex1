package de.apex1.f1;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

/** Zeichnet die farbigen Bild-Kacheln der Profil-Widgets. */
final class Panels {
    private Panels() {}

    private static Bitmap base(int w, int h, int color, Canvas[] out) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        float r = h * 0.12f;
        Path clip = new Path();
        clip.addRoundRect(new RectF(0, 0, w, h), r, r, Path.Direction.CW);
        c.clipPath(clip);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, w, h, color, F1.darker(color, 0.55f), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        out[0] = c;
        return b;
    }

    private static void watermark(Canvas c, int w, int h, String text) {
        if (text == null || text.isEmpty()) return;
        Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
        t.setTypeface(Typeface.create("sans-serif-black", Typeface.ITALIC));
        t.setColor(0x33FFFFFF);
        float size = h * 0.95f;
        t.setTextSize(size);
        while (t.measureText(text) > w * 1.05f && size > 20) { size -= 6; t.setTextSize(size); }
        t.setTextAlign(Paint.Align.CENTER);
        c.drawText(text, w * 0.55f, h * 0.78f, t);
    }

    /** Fahrer: Teamfarbe, Startnummer als Wasserzeichen, Foto unten ausgerichtet. */
    static Bitmap driver(int color, Bitmap photo, String number) {
        int w = 380, h = 380;
        Canvas[] cc = new Canvas[1];
        Bitmap b = base(w, h, color, cc);
        Canvas c = cc[0];
        watermark(c, w, h, number);
        if (photo != null) {
            float scale = Math.min(w * 1.0f / photo.getWidth(), h * 0.98f / photo.getHeight());
            float pw = photo.getWidth() * scale, ph = photo.getHeight() * scale;
            RectF dst = new RectF((w - pw) / 2f, h - ph, (w + pw) / 2f, h);
            c.drawBitmap(photo, null, dst, new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG));
        }
        return b;
    }

    /** Team: Teamfarbe mit weißer Logo-Kachel (oder Kürzel, falls kein Logo). */
    static Bitmap team(int color, Bitmap logo, String initials) {
        int w = 380, h = 380;
        Canvas[] cc = new Canvas[1];
        Bitmap b = base(w, h, color, cc);
        Canvas c = cc[0];
        watermark(c, w, h, initials);
        float tile = w * 0.62f;
        RectF r = new RectF((w - tile) / 2f, (h - tile) / 2f, (w + tile) / 2f, (h + tile) / 2f);
        Paint white = new Paint(Paint.ANTI_ALIAS_FLAG);
        white.setColor(0xFFFFFFFF);
        c.drawRoundRect(r, tile * 0.2f, tile * 0.2f, white);
        if (logo != null) {
            float pad = tile * 0.14f;
            float avail = tile - 2 * pad;
            float scale = Math.min(avail / logo.getWidth(), avail / logo.getHeight());
            float lw = logo.getWidth() * scale, lh = logo.getHeight() * scale;
            RectF dst = new RectF(w / 2f - lw / 2f, h / 2f - lh / 2f, w / 2f + lw / 2f, h / 2f + lh / 2f);
            c.drawBitmap(logo, null, dst, new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG));
        } else {
            Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
            t.setColor(color);
            t.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
            t.setTextSize(tile * 0.4f);
            t.setTextAlign(Paint.Align.CENTER);
            c.drawText(initials == null ? "" : initials, w / 2f, h / 2f + tile * 0.14f, t);
        }
        return b;
    }
}
