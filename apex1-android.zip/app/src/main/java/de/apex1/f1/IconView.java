package de.apex1.f1;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

import androidx.core.graphics.PathParser;

/** Zeichnet ein Material-Symbol (24er Raster) aus Pfaddaten; "ring" ist ein Reifen-Symbol. */
final class IconView extends View {
    static final String CALENDAR = "M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM7 10h5v5H7z";
    static final String TROPHY = "M19 5h-2V3H7v2H5c-1.1 0-2 .9-2 2v1c0 2.55 1.92 4.63 4.39 4.94.63 1.5 1.98 2.63 3.61 2.96V19H7v2h10v-2h-4v-3.1c1.63-.33 2.98-1.46 3.61-2.96C19.08 12.63 21 10.55 21 8V7c0-1.1-.9-2-2-2zM5 8V7h2v3.82C5.84 10.4 5 9.3 5 8zm14 0c0 1.3-.84 2.4-2 2.82V7h2v1z";
    static final String ARTICLE = "M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z";
    static final String MAP = "M20.5 3l-.16.03L15 5.1 9 3 3.36 4.9c-.21.07-.36.25-.36.48V20.5c0 .28.22.5.5.5l.16-.03L9 18.9l6 2.1 5.64-1.9c.21-.07.36-.25.36-.48V3.5c0-.28-.22-.5-.5-.5zM15 19l-6-2.11V5l6 2.11V19z";
    static final String FLAG = "M14.4 6L14 4H5v17h2v-7h5.6l.4 2h7V6z";
    static final String SETTINGS = "M19.43 12.98c.04-.32.07-.64.07-.98s-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zM12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z";

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Path path;
    private final boolean ring;

    IconView(Context c, String data, int color) {
        super(c);
        paint.setColor(color);
        ring = data == null;
        if (!ring) {
            try { path = PathParser.createPathFromPathData(data); } catch (Exception e) { path = null; }
            if (path != null) path.setFillType(Path.FillType.EVEN_ODD);
        }
    }

    void setColor(int color) { paint.setColor(color); invalidate(); }

    @Override protected void onDraw(Canvas cv) {
        float s = Math.min(getWidth(), getHeight()) / 24f;
        if (ring) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2.2f * s);
            cv.drawCircle(getWidth() / 2f, getHeight() / 2f, 8.6f * s, paint);
            paint.setStrokeWidth(2f * s);
            cv.drawCircle(getWidth() / 2f, getHeight() / 2f, 3.4f * s, paint);
            return;
        }
        if (path == null) return;
        paint.setStyle(Paint.Style.FILL);
        cv.save();
        cv.translate((getWidth() - 24 * s) / 2f, (getHeight() - 24 * s) / 2f);
        cv.scale(s, s);
        cv.drawPath(path, paint);
        cv.restore();
    }
}
