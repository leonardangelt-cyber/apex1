package de.apex1.f1;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Nach Neustart gehen Alarme verloren – hier werden sie neu geplant. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        UpdateWorker.schedulePeriodic(c);
        UpdateWorker.enqueue(c);
    }
}
