package de.apex1.f1;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.RemoteViews;

/** News – scrollbare Liste der neuesten Formel-1-Meldungen. */
public class NewsWidget extends BaseWidget {
    @Override
    void render(Context c, AppWidgetManager m, int id) throws Exception {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_list);
        v.setOnClickPendingIntent(R.id.w_root, openApp(c, 15));
        Intent si = new Intent(c, NewsService.class).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
        si.setData(Uri.parse(si.toUri(Intent.URI_INTENT_SCHEME)));
        v.setRemoteAdapter(R.id.w_list, si);
        PendingIntent open = PendingIntent.getActivity(c, 35, new Intent(c, OpenActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
        v.setPendingIntentTemplate(R.id.w_list, open);
        v.setEmptyView(R.id.w_list, R.id.w_empty);
        v.setTextViewText(R.id.w_label, "F1-NEWS");
        m.updateAppWidget(id, v);
        m.notifyAppWidgetViewDataChanged(id, R.id.w_list);
    }
}
