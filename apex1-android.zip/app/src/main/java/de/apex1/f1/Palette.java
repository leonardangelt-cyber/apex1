package de.apex1.f1;

import android.content.Context;
import android.os.Build;

/** Material-You-Farbrollen (dunkel) aus dem Wallpaper; unter Android 12 ein ruhiges Standard-Dunkel. */
final class Palette {
    private Palette() {}

    static int surface = 0xFF0F1115, card = 0xFF1A1D23, cardHigh = 0xFF242830,
            onSurface = 0xFFE4E2E6, onVariant = 0xFFB4B6BE, outline = 0xFF3A3E47,
            primary = 0xFFA8C7FA, onPrimary = 0xFF0B2B57, primaryC = 0xFF1F3F72, onPrimaryC = 0xFFD6E3FF,
            secondaryC = 0xFF3A4458, onSecondaryC = 0xFFD8E2F9;

    static boolean haptic = true;
    static void tick(android.view.View v) { if (haptic) v.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK); }

    static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    static void init(Context c) {
        if (Build.VERSION.SDK_INT < 31) return;
        try {
            int n900 = c.getColor(android.R.color.system_neutral1_900), n1000 = c.getColor(android.R.color.system_neutral1_1000);
            int n800 = c.getColor(android.R.color.system_neutral1_800), n700 = c.getColor(android.R.color.system_neutral1_700);
            surface = mix(n900, n1000, 0.4f);
            card = mix(n900, n800, 0.9f);
            cardHigh = mix(n800, n700, 0.5f);
            onSurface = c.getColor(android.R.color.system_neutral1_100);
            onVariant = c.getColor(android.R.color.system_neutral2_200);
            outline = c.getColor(android.R.color.system_neutral2_700);
            primary = c.getColor(android.R.color.system_accent1_200);
            onPrimary = c.getColor(android.R.color.system_accent1_800);
            primaryC = c.getColor(android.R.color.system_accent1_700);
            onPrimaryC = c.getColor(android.R.color.system_accent1_100);
            secondaryC = c.getColor(android.R.color.system_accent2_700);
            onSecondaryC = c.getColor(android.R.color.system_accent2_100);
        } catch (Exception ignored) { }
    }
}
