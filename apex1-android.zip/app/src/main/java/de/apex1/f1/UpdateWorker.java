package de.apex1.f1;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.util.concurrent.TimeUnit;

/** Aktualisiert alle Widgets im Hintergrund (ohne die 10-Sekunden-Grenze von Broadcasts). */
public class UpdateWorker extends Worker {

    public UpdateWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context c = getApplicationContext();
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        BaseWidget[] all = {
                new DriverStandingsWidget(), new DriverProfileWidget(), new TeamProfileWidget()
        };
        for (BaseWidget w : all) {
            int[] ids = m.getAppWidgetIds(new ComponentName(c, w.getClass()));
            for (int id : ids) {
                try { w.render(c, m, id); } catch (Exception ignored) { }
            }
        }
        try { Notifier.sync(c); } catch (Exception ignored) { }
        return Result.success();
    }

    private static Constraints net() {
        return new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
    }

    static void enqueue(Context c) {
        WorkManager.getInstance(c).enqueueUniqueWork("apex1-refresh", ExistingWorkPolicy.REPLACE,
                new OneTimeWorkRequest.Builder(UpdateWorker.class).setConstraints(net()).build());
    }

    static void schedulePeriodic(Context c) {
        WorkManager.getInstance(c).enqueueUniquePeriodicWork("apex1-periodic", ExistingPeriodicWorkPolicy.KEEP,
                new PeriodicWorkRequest.Builder(UpdateWorker.class, 30, TimeUnit.MINUTES).setConstraints(net()).build());
    }
}
