package de.apex1.f1;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

/** Unsichtbarer Zwischenschritt: öffnet einen Artikel-Link aus dem News-Widget im Browser. */
public class OpenActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        String url = getIntent() == null ? null : getIntent().getStringExtra("open_url");
        if (url != null && (url.startsWith("https://") || url.startsWith("http://"))) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
            catch (Exception ignored) { }
        }
        finish();
    }
}
