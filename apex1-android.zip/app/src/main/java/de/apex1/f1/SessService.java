package de.apex1.f1;

import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import org.json.JSONArray;
import org.json.JSONObject;

/** Scrollbare Session-Zeiten des Zeitplan-Widgets (Daten legt ScheduleWidget in den Prefs ab). */
public class SessService extends RemoteViewsService {
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new Factory(getApplicationContext());
    }

    static final String KEY = "sched_data";

    static class Factory implements RemoteViewsFactory {
        private final Context c;
        private JSONArray rows = new JSONArray();

        Factory(Context c) { this.c = c; }

        @Override public void onCreate() { }

        @Override
        public void onDataSetChanged() {
            try {
                JSONObject d = new JSONObject(c.getSharedPreferences("apex1_widgets", Context.MODE_PRIVATE).getString(KEY, "{}"));
                rows = d.optJSONArray("rows");
                if (rows == null) rows = new JSONArray();
            } catch (Exception e) { rows = new JSONArray(); }
        }

        @Override public void onDestroy() { }
        @Override public int getCount() { return rows.length(); }

        @Override
        public RemoteViews getViewAt(int i) {
            RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.item_session);
            try {
                JSONArray r = rows.getJSONArray(i);
                v.setTextViewText(R.id.ss_name, r.getString(0));
                v.setTextViewText(R.id.ss_time, r.getString(1));
            } catch (Exception ignored) { }
            v.setOnClickFillInIntent(R.id.it_root, new Intent());
            return v;
        }

        @Override public RemoteViews getLoadingView() { return null; }
        @Override public int getViewTypeCount() { return 1; }
        @Override public long getItemId(int i) { return i; }
        @Override public boolean hasStableIds() { return true; }
    }
}
