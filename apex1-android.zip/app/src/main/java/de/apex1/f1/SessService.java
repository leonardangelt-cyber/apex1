package de.apex1.f1;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import org.json.JSONArray;
import org.json.JSONObject;

/** Scrollbarer Inhalt des Zeitplan-Widgets: Kopf, alle Sessions, Streckenkarte (Daten legt ScheduleWidget ab). */
public class SessService extends RemoteViewsService {
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new Factory(getApplicationContext());
    }

    static final String KEY = "sched_data";

    static class Factory implements RemoteViewsFactory {
        private final Context c;
        private JSONObject data = new JSONObject();
        private JSONArray rows = new JSONArray();
        private Bitmap track;

        Factory(Context c) { this.c = c; }

        @Override public void onCreate() { }

        @Override
        public void onDataSetChanged() {
            try {
                data = new JSONObject(c.getSharedPreferences("apex1_widgets", Context.MODE_PRIVATE).getString(KEY, "{}"));
                rows = data.optJSONArray("rows");
                if (rows == null) rows = new JSONArray();
                String circuit = data.optString("circuit", "");
                track = circuit.isEmpty() ? null : F1.trackMap(c, circuit, 600);
            } catch (Exception e) { data = new JSONObject(); rows = new JSONArray(); track = null; }
        }

        @Override public void onDestroy() { }

        @Override
        public int getCount() {
            if (data.length() == 0) return 0;
            return 1 + rows.length() + (track != null ? 1 : 0);
        }

        @Override
        public RemoteViews getViewAt(int i) {
            RemoteViews v;
            try {
                if (i == 0) {
                    v = new RemoteViews(c.getPackageName(), R.layout.item_race_header);
                    v.setTextViewText(R.id.h_label, data.optString("label"));
                    v.setTextViewText(R.id.h_title, data.optString("title"));
                    v.setTextViewText(R.id.h_sub, data.optString("sub"));
                    v.setTextViewText(R.id.h_chip, data.optString("chip"));
                    v.setViewVisibility(R.id.h_chip, data.optString("chip").isEmpty() ? android.view.View.GONE : android.view.View.VISIBLE);
                    v.setOnClickFillInIntent(R.id.it_root, new Intent());
                    return v;
                }
                if (i <= rows.length()) {
                    JSONArray r = rows.getJSONArray(i - 1);
                    v = new RemoteViews(c.getPackageName(), R.layout.item_session);
                    v.setTextViewText(R.id.ss_name, r.getString(0));
                    v.setTextViewText(R.id.ss_time, r.getString(1));
                    v.setOnClickFillInIntent(R.id.it_root, new Intent());
                    return v;
                }
                v = new RemoteViews(c.getPackageName(), R.layout.item_track);
                v.setImageViewBitmap(R.id.tr_img, track);
                v.setOnClickFillInIntent(R.id.it_root, new Intent());
                return v;
            } catch (Exception e) {
                return new RemoteViews(c.getPackageName(), R.layout.item_session);
            }
        }

        @Override public RemoteViews getLoadingView() { return null; }
        @Override public int getViewTypeCount() { return 3; }
        @Override public long getItemId(int i) { return i; }
        @Override public boolean hasStableIds() { return true; }
    }
}
