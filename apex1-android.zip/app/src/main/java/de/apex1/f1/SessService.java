package de.apex1.f1;

import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Liefert die Session-Zeilen des Zeitplan-Widgets (scrollbar). */
public class SessService extends RemoteViewsService {
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new Factory(getApplicationContext());
    }

    static class Factory implements RemoteViewsFactory {
        final Context c;
        List<String[]> rows = new ArrayList<>();

        Factory(Context c) { this.c = c; }

        @Override public void onCreate() { }

        @Override
        public void onDataSetChanged() {
            List<String[]> out = new ArrayList<>();
            try {
                String s = c.getSharedPreferences("apex1_widgets", Context.MODE_PRIVATE).getString("sched_data", "{}");
                JSONArray a = new JSONObject(s).optJSONArray("rows");
                if (a != null) for (int i = 0; i < a.length(); i++) {
                    JSONArray r = a.getJSONArray(i);
                    out.add(new String[]{r.getString(0), r.getString(1)});
                }
            } catch (Exception ignored) { }
            rows = out;
        }

        @Override public void onDestroy() { rows.clear(); }
        @Override public int getCount() { return rows.size(); }

        @Override
        public RemoteViews getViewAt(int i) {
            RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.item_session);
            if (i >= rows.size()) return v;
            v.setTextViewText(R.id.ss_name, rows.get(i)[0]);
            v.setTextViewText(R.id.ss_time, rows.get(i)[1]);
            v.setOnClickFillInIntent(R.id.it_root, new Intent());
            return v;
        }

        @Override public RemoteViews getLoadingView() { return null; }
        @Override public int getViewTypeCount() { return 1; }
        @Override public long getItemId(int i) { return i; }
        @Override public boolean hasStableIds() { return true; }
    }
}
