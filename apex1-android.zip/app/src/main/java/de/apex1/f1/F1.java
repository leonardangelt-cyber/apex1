package de.apex1.f1;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.util.Locale;

/** Daten- und Bildzugriff für die Widgets (Jolpica, OpenF1, Wikipedia). */
final class F1 {
    private F1() {}

    static final String JOLPICA = "https://api.jolpi.ca/ergast/f1";

    /* ---------- JSON ---------- */

    static JSONArray driverStandings(Context c) {
        try {
            String j = Api.get(c, JOLPICA + "/current/driverstandings.json", "driverstandings");
            if (j == null) return null;
            JSONArray lists = new JSONObject(j).getJSONObject("MRData").getJSONObject("StandingsTable").getJSONArray("StandingsLists");
            return lists.length() == 0 ? null : lists.getJSONObject(0).getJSONArray("DriverStandings");
        } catch (Exception e) { return null; }
    }

    static JSONArray teamStandings(Context c) {
        try {
            String j = Api.get(c, JOLPICA + "/current/constructorstandings.json", "teamstandings");
            if (j == null) return null;
            JSONArray lists = new JSONObject(j).getJSONObject("MRData").getJSONObject("StandingsTable").getJSONArray("StandingsLists");
            return lists.length() == 0 ? null : lists.getJSONObject(0).getJSONArray("ConstructorStandings");
        } catch (Exception e) { return null; }
    }

    static String season(Context c) {
        try {
            String j = Api.get(c, JOLPICA + "/current/driverstandings.json", "driverstandings");
            return new JSONObject(j).getJSONObject("MRData").getJSONObject("StandingsTable").optString("season", "");
        } catch (Exception e) { return ""; }
    }

    static String lastTeamName(JSONObject standing) {
        try {
            JSONArray cons = standing.getJSONArray("Constructors");
            return cons.getJSONObject(cons.length() - 1).getString("name");
        } catch (Exception e) { return ""; }
    }

    /* ---------- Teamfarben ---------- */

    static int teamColor(String name) {
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        String hex = "8A8F98";
        if (n.contains("red bull")) hex = "3671C6";
        else if (n.contains("mclaren")) hex = "FF8000";
        else if (n.contains("ferrari")) hex = "E8002D";
        else if (n.contains("mercedes")) hex = "27F4D2";
        else if (n.contains("aston")) hex = "229971";
        else if (n.contains("alpine")) hex = "FF87BC";
        else if (n.contains("williams")) hex = "64C4FF";
        else if (n.equals("rb") || n.startsWith("rb ") || n.contains("racing bulls") || n.contains("alphatauri")) hex = "6692FF";
        else if (n.contains("sauber") || n.contains("audi")) hex = "52E252";
        else if (n.contains("haas")) hex = "B6BABD";
        else if (n.contains("cadillac")) hex = "A9A9B3";
        return 0xFF000000 | Integer.parseInt(hex, 16);
    }

    static int darker(int color, float f) {
        int r = (int) (((color >> 16) & 0xFF) * f), g = (int) (((color >> 8) & 0xFF) * f), b = (int) ((color & 0xFF) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    /* ---------- Bilder ---------- */

    private static byte[] download(String url, int timeoutMs) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(timeoutMs);
        con.setReadTimeout(timeoutMs);
        con.setRequestProperty("User-Agent", "APEX1-Android/1.0 (F1 companion app)");
        con.setInstanceFollowRedirects(true);
        if (con.getResponseCode() != 200) throw new RuntimeException("HTTP " + con.getResponseCode());
        try (InputStream in = con.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toByteArray();
        }
    }

    private static String sha1(String s) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-1").digest(s.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { return String.valueOf(s.hashCode()); }
    }

    /** Lädt ein Bild (mit Festplatten-Cache) und skaliert es auf höchstens maxPx. */
    static Bitmap image(Context c, String url, int maxPx) {
        if (url == null || url.isEmpty()) return null;
        try {
            File dir = new File(c.getCacheDir(), "img");
            dir.mkdirs();
            File f = new File(dir, sha1(url));
            byte[] data;
            if (f.exists() && f.length() > 0) {
                data = new byte[(int) f.length()];
                try (FileInputStream in = new FileInputStream(f)) {
                    int off = 0;
                    while (off < data.length) { int r = in.read(data, off, data.length - off); if (r < 0) break; off += r; }
                }
            } else {
                data = download(url, 9000);
                try (FileOutputStream out = new FileOutputStream(f)) { out.write(data); }
            }
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, o);
            int sample = 1;
            while (o.outWidth / (sample * 2) >= maxPx && o.outHeight / (sample * 2) >= maxPx) sample *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = sample;
            return BitmapFactory.decodeByteArray(data, 0, data.length, o);
        } catch (Exception e) { return null; }
    }

    private static String wikiTitle(String url) {
        if (url == null) return null;
        int i = url.indexOf("/wiki/");
        if (i < 0) return null;
        String t = url.substring(i + 6);
        int h = t.indexOf('#');
        return h >= 0 ? t.substring(0, h) : t;
    }

    /** Liefert [thumbnail, original] aus der Wikipedia-Zusammenfassung (gecacht). */
    private static String[] wikiImages(Context c, String pageUrl) {
        String title = wikiTitle(pageUrl);
        if (title == null) return null;
        SharedPreferences p = c.getSharedPreferences("apex1_widgets", Context.MODE_PRIVATE);
        String key = "wiki:" + title;
        String cached = p.getString(key, null);
        try {
            if (cached == null) {
                String api = "https://en.wikipedia.org/api/rest_v1/page/summary/" + title;
                cached = new String(download(api, 7000), "UTF-8");
                p.edit().putString(key, cached).apply();
            }
            JSONObject j = new JSONObject(cached);
            String thumb = j.has("thumbnail") ? j.getJSONObject("thumbnail").optString("source", "") : "";
            String orig = j.has("originalimage") ? j.getJSONObject("originalimage").optString("source", "") : "";
            return new String[]{thumb, orig};
        } catch (Exception e) { return null; }
    }

    /** Fahrerfoto: zuerst offizielles OpenF1-Portrait, sonst Wikipedia. */
    static Bitmap driverPhoto(Context c, JSONObject driver) {
        SharedPreferences p = c.getSharedPreferences("apex1_widgets", Context.MODE_PRIVATE);
        String code = driver.optString("code", "");
        try {
            if (!code.isEmpty()) {
                String key = "hs:" + code;
                String url = p.getString(key, null);
                if (url == null) {
                    byte[] d = download("https://api.openf1.org/v1/drivers?session_key=latest&name_acronym=" + URLEncoder.encode(code, "UTF-8"), 5000);
                    JSONArray arr = new JSONArray(new String(d, "UTF-8"));
                    for (int i = arr.length() - 1; i >= 0 && url == null; i--) {
                        String u = arr.getJSONObject(i).optString("headshot_url", "");
                        if (!u.isEmpty() && !u.equals("null")) url = u;
                    }
                    if (url != null) p.edit().putString(key, url).apply();
                }
                Bitmap b = image(c, url, 360);
                if (b != null) return b;
            }
        } catch (Exception ignored) { }
        String[] w = wikiImages(c, driver.optString("url", ""));
        return w == null ? null : image(c, w[0], 360);
    }

    /** Team-Logo: zuerst Wikipedia-Infobox, sonst Wikimedia-Commons-Suche. */
    static Bitmap teamLogo(Context c, JSONObject constructor, int maxPx) {
        String[] w = wikiImages(c, constructor.optString("url", ""));
        if (w != null && !w[0].isEmpty()) {
            String check = (w[1].isEmpty() ? w[0] : w[1]).toLowerCase(Locale.ROOT);
            if (check.contains("logo") || check.contains("emblem") || check.contains("badge")
                    || check.contains("crest") || check.contains("wordmark") || check.contains(".svg")) {
                Bitmap b = image(c, w[0], maxPx);
                if (b != null) return cleanLogo(b);
            }
        }
        return cleanLogo(commonsLogo(c, constructor.optString("name", ""), maxPx));
    }

    private static String firstWord(String team) {
        String n = team == null ? "" : team.toLowerCase(Locale.ROOT).trim();
        if (n.startsWith("red bull")) return "red bull";
        if (n.startsWith("aston")) return "aston martin";
        int sp = n.indexOf(' ');
        String f = sp > 0 ? n.substring(0, sp) : n;
        if (f.contains("-")) f = f.substring(0, f.indexOf('-'));
        return f;
    }

    private static JSONObject apiGet(String url, int timeout) {
        try { return new JSONObject(new String(download(url, timeout), "UTF-8")); } catch (Exception e) { return null; }
    }

    private static Bitmap commonsLogo(Context c, String team, int maxPx) {
        if (team.isEmpty()) return null;
        SharedPreferences p = c.getSharedPreferences("apex1_widgets", Context.MODE_PRIVATE);
        String key = "logo:" + team;
        String url = p.getString(key, null);
        try {
            if (url == null) {
                JSONObject j = apiGet("https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrnamespace=6&gsrlimit=10"
                        + "&gsrsearch=" + URLEncoder.encode(team + " Formula 1 logo", "UTF-8")
                        + "&prop=imageinfo&iiprop=url&iiurlwidth=300&format=json", 7000);
                if (j == null || !j.has("query")) return null;
                JSONObject pages = j.getJSONObject("query").getJSONObject("pages");
                String word = firstWord(team);
                int bestIdx = 999;
                java.util.Iterator<String> it = pages.keys();
                while (it.hasNext()) {
                    JSONObject pg = pages.getJSONObject(it.next());
                    String title = pg.optString("title", "").toLowerCase(Locale.ROOT);
                    if (!title.contains("logo") || !title.contains(word)) continue;
                    if (title.matches(".*(19\\d\\d|200\\d|201\\d).*") || title.contains("old")) continue;
                    JSONArray ii = pg.optJSONArray("imageinfo");
                    if (ii == null || ii.length() == 0) continue;
                    int idx = pg.optInt("index", 500);
                    if (idx < bestIdx) { bestIdx = idx; url = ii.getJSONObject(0).optString("thumburl", ""); }
                }
                if (url != null && !url.isEmpty()) p.edit().putString(key, url).apply(); else return null;
            }
            return image(c, url, maxPx);
        } catch (Exception e) { return null; }
    }

    /** Aktuelles Fahrzeug: Wikipedia-Artikel zum Auto der Saison (Titel enthält Teamname und eine Zahl). */
    static Bitmap carImage(Context c, String team, String season) {
        if (team == null || team.isEmpty()) return null;
        SharedPreferences p = c.getSharedPreferences("apex1_widgets", Context.MODE_PRIVATE);
        String key = "car:" + team + ":" + season;
        String url = p.getString(key, null);
        try {
            if (url == null) {
                JSONObject j = apiGet("https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrlimit=8"
                        + "&gsrsearch=" + URLEncoder.encode(season + " " + team + " Formula One car", "UTF-8")
                        + "&prop=pageimages&piprop=thumbnail&pithumbsize=700&format=json", 7000);
                if (j == null || !j.has("query")) return null;
                JSONObject pages = j.getJSONObject("query").getJSONObject("pages");
                String word = firstWord(team);
                int bestIdx = 999;
                java.util.Iterator<String> it = pages.keys();
                while (it.hasNext()) {
                    JSONObject pg = pages.getJSONObject(it.next());
                    String title = pg.optString("title", "").toLowerCase(Locale.ROOT);
                    if (!title.contains(word) || !title.matches(".*\\d.*")) continue;
                    if (title.contains("championship") || title.contains("season") || title.contains("grand prix")) continue;
                    JSONObject th = pg.optJSONObject("thumbnail");
                    if (th == null) continue;
                    String src = th.optString("source", "");
                    String low = src.toLowerCase(Locale.ROOT);
                    if (src.isEmpty() || low.contains("logo") || low.endsWith(".svg.png")) continue;
                    int idx = pg.optInt("index", 500);
                    if (idx < bestIdx) { bestIdx = idx; url = src; }
                }
                if (url != null) p.edit().putString(key, url).apply(); else return null;
            }
            return image(c, url, 700);
        } catch (Exception e) { return null; }
    }

    private static boolean nearWhite(int px) {
        return ((px >> 16) & 0xFF) > 236 && ((px >> 8) & 0xFF) > 236 && (px & 0xFF) > 236;
    }

    /** Entfernt weiße Rechteck-Hintergründe, sodass nur das Logo mit transparentem Hintergrund bleibt. */
    static Bitmap cleanLogo(Bitmap src) {
        if (src == null) return null;
        Bitmap b = src.copy(Bitmap.Config.ARGB_8888, true);
        int w = b.getWidth(), h = b.getHeight();
        int[] px = new int[w * h];
        b.getPixels(px, 0, w, 0, 0, w, h);
        boolean opaqueWhiteCorner = (px[0] >>> 24) > 200 && nearWhite(px[0]);
        if (!src.hasAlpha() || opaqueWhiteCorner) {
            for (int i = 0; i < px.length; i++) if ((px[i] >>> 24) > 0 && nearWhite(px[i])) px[i] = 0;
            b.setPixels(px, 0, w, 0, 0, w, h);
        }
        return b;
    }

    /** Färbt ein Logo komplett in einer Farbe ein (Alpha bleibt erhalten). */
    static Bitmap tint(Bitmap src, int color) {
        if (src == null) return null;
        Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        android.graphics.Canvas cv = new android.graphics.Canvas(out);
        android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG | android.graphics.Paint.FILTER_BITMAP_FLAG);
        p.setColorFilter(new android.graphics.PorterDuffColorFilter(color, android.graphics.PorterDuff.Mode.SRC_IN));
        cv.drawBitmap(src, 0, 0, p);
        return out;
    }

    /** Dunkle Logos werden auf Schwarz unsichtbar – dann weiß einfärben. */
    static Bitmap legibleOnDark(Bitmap src) {
        if (src == null) return null;
        int w = src.getWidth(), h = src.getHeight();
        int[] px = new int[w * h];
        src.getPixels(px, 0, w, 0, 0, w, h);
        double sum = 0, wt = 0;
        for (int v : px) {
            int a = v >>> 24;
            if (a < 30) continue;
            double lum = (0.2126 * ((v >> 16) & 0xFF) + 0.7152 * ((v >> 8) & 0xFF) + 0.0722 * (v & 0xFF)) / 255.0;
            sum += lum * a; wt += a;
        }
        if (wt == 0) return src;
        return (sum / wt) < 0.42 ? tint(src, 0xFFFFFFFF) : src;
    }
}
