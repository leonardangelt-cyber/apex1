package de.apex1.f1;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.util.Locale;

/** Daten- und Bildzugriff für die Widgets (Jolpica, OpenF1, Wikipedia). */
final class F1 {
    private F1() {}

    static final String JOLPICA = "https://api.jolpi.ca/ergast/f1";

    /* ---------- JSON ---------- */

    static JSONArray driverStandings(Context c) {
        try {
            String j = Api.get(c, JOLPICA + "/current/driverstandings.json", "driverstandings");
            if (j == null) return null;
            JSONArray lists = new JSONObject(j).getJSONObject("MRData").getJSONObject("StandingsTable").getJSONArray("StandingsLists");
            return lists.length() == 0 ? null : lists.getJSONObject(0).getJSONArray("DriverStandings");
        } catch (Exception e) { return null; }
    }

    static JSONArray teamStandings(Context c) {
        try {
            String j = Api.get(c, JOLPICA + "/current/constructorstandings.json", "teamstandings");
            if (j == null) return null;
            JSONArray lists = new JSONObject(j).getJSONObject("MRData").getJSONObject("StandingsTable").getJSONArray("StandingsLists");
            return lists.length() == 0 ? null : lists.getJSONObject(0).getJSONArray("ConstructorStandings");
        } catch (Exception e) { return null; }
    }

    static String season(Context c) {
        try {
            String j = Api.get(c, JOLPICA + "/current/driverstandings.json", "driverstandings");
            return new JSONObject(j).getJSONObject("MRData").getJSONObject("StandingsTable").optString("season", "");
        } catch (Exception e) { return ""; }
    }

    static String lastTeamName(JSONObject standing) {
        try {
            JSONArray cons = standing.getJSONArray("Constructors");
            return cons.getJSONObject(cons.length() - 1).getString("name");
        } catch (Exception e) { return ""; }
    }

    /* ---------- Teamfarben ---------- */

    /** Drei-Buchstaben-Kürzel eines Teams. */
    static String teamShort(String name) {
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        if (n.contains("red bull")) return "RBR";
        if (n.contains("mercedes")) return "MER";
        if (n.contains("ferrari")) return "FER";
        if (n.contains("mclaren")) return "MCL";
        if (n.contains("aston")) return "AMR";
        if (n.contains("alpine")) return "ALP";
        if (n.contains("williams")) return "WIL";
        if (n.contains("haas")) return "HAA";
        if (n.contains("rb f1") || n.contains("racing bulls") || n.contains("alphatauri") || n.contains("toro")) return "RB";
        if (n.contains("audi")) return "AUD";
        if (n.contains("cadillac")) return "CAD";
        if (n.contains("sauber") || n.contains("alfa")) return "SAU";
        String t = n.replaceAll("[^a-z]", "");
        return t.substring(0, Math.min(3, t.length())).toUpperCase(Locale.ROOT);
    }

    /** Lesbare Textfarbe (dunkel/weiß) auf einer Teamfarbe. */
    static int onColor(int color) {
        double l = 0.299 * ((color >> 16) & 255) + 0.587 * ((color >> 8) & 255) + 0.114 * (color & 255);
        return l > 150 ? 0xFF0B0D12 : 0xFFFFFFFF;
    }

    static int teamColor(String name) {
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        String hex = "8A8F98";
        if (n.contains("red bull")) hex = "3671C6";
        else if (n.contains("mclaren")) hex = "FF8000";
        else if (n.contains("ferrari")) hex = "E8002D";
        else if (n.contains("mercedes")) hex = "27F4D2";
        else if (n.contains("aston")) hex = "229971";
        else if (n.contains("alpine")) hex = "FF87BC";
        else if (n.contains("williams")) hex = "64C4FF";
        else if (n.equals("rb") || n.startsWith("rb ") || n.contains("racing bulls") || n.contains("alphatauri")) hex = "6692FF";
        else if (n.contains("audi")) hex = "F50537";
        else if (n.contains("sauber")) hex = "52E252";
        else if (n.contains("haas")) hex = "B6BABD";
        else if (n.contains("cadillac")) hex = "A9A9B3";
        return 0xFF000000 | Integer.parseInt(hex, 16);
    }

    static int darker(int color, float f) {
        int r = (int) (((color >> 16) & 0xFF) * f), g = (int) (((color >> 8) & 0xFF) * f), b = (int) ((color & 0xFF) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    /* ---------- Bilder ---------- */

    private static byte[] download(String url, int timeoutMs) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(timeoutMs);
        con.setReadTimeout(timeoutMs);
        con.setRequestProperty("User-Agent", "APEX1-Android/1.0 (F1 companion app)");
        con.setInstanceFollowRedirects(true);
        if (con.getResponseCode() != 200) throw new RuntimeException("HTTP " + con.getResponseCode());
        try (InputStream in = con.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toByteArray();
        }
    }

    private static String sha1(String s) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-1").digest(s.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { return String.valueOf(s.hashCode()); }
    }

    /** Lädt ein Bild (mit Festplatten-Cache) und skaliert es auf höchstens maxPx. */
    static Bitmap image(Context c, String url, int maxPx) {
        if (url == null || url.isEmpty()) return null;
        try {
            File dir = new File(c.getCacheDir(), "img");
            dir.mkdirs();
            File f = new File(dir, sha1(url));
            byte[] data;
            if (f.exists() && f.length() > 0) {
                data = new byte[(int) f.length()];
                try (FileInputStream in = new FileInputStream(f)) {
                    int off = 0;
                    while (off < data.length) { int r = in.read(data, off, data.length - off); if (r < 0) break; off += r; }
                }
            } else {
                data = download(url, 9000);
                try (FileOutputStream out = new FileOutputStream(f)) { out.write(data); }
            }
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, o);
            int sample = 1;
            while (o.outWidth / (sample * 2) >= maxPx && o.outHeight / (sample * 2) >= maxPx) sample *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = sample;
            return BitmapFactory.decodeByteArray(data, 0, data.length, o);
        } catch (Exception e) { return null; }
    }

    private static String wikiTitle(String url) {
        if (url == null) return null;
        int i = url.indexOf("/wiki/");
        if (i < 0) return null;
        String t = url.substring(i + 6);
        int h = t.indexOf('#');
        return h >= 0 ? t.substring(0, h) : t;
    }

    /** Liefert [thumbnail, original] aus der Wikipedia-Zusammenfassung (gecacht). */
    private static String[] wikiImages(Context c, String pageUrl) {
        String title = wikiTitle(pageUrl);
        if (title == null) return null;
        SharedPreferences p = c.getSharedPreferences("apex1_widgets", Context.MODE_PRIVATE);
        String key = "wiki:" + title;
        String cached = p.getString(key, null);
        try {
            if (cached == null) {
                String api = "https://en.wikipedia.org/api/rest_v1/page/summary/" + title;
                cached = new String(download(api, 7000), "UTF-8");
                p.edit().putString(key, cached).apply();
            }
            JSONObject j = new JSONObject(cached);
            String thumb = j.has("thumbnail") ? j.getJSONObject("thumbnail").optString("source", "") : "";
            String orig = j.has("originalimage") ? j.getJSONObject("originalimage").optString("source", "") : "";
            return new String[]{thumb, orig};
        } catch (Exception e) { return null; }
    }

    /** Versucht zuerst eine größere Variante der Bild-URL, dann das Original. */
    private static Bitmap sharpImage(Context c, String url, int maxPx) {
        if (url == null || url.isEmpty()) return null;
        String big = url;
        if (url.contains("/320px-")) big = url.replace("/320px-", "/900px-");
        else if (url.contains("/1col/")) big = url.replace("/1col/", "/4col/");
        else if (url.contains("1col")) big = url.replace("1col", "4col");
        if (!big.equals(url)) {
            Bitmap b = image(c, big, maxPx);
            if (b != null) return b;
        }
        return image(c, url, maxPx);
    }

    /** Fahrerfoto: zuerst offizielles OpenF1-Portrait, sonst Wikipedia – jeweils in hoher Auflösung. */
    static Bitmap driverPhoto(Context c, JSONObject driver) {
        SharedPreferences p = c.getSharedPreferences("apex1_widgets", Context.MODE_PRIVATE);
        String code = driver.optString("code", "");
        try {
            if (!code.isEmpty()) {
                String key = "hs:" + code;
                String url = p.getString(key, null);
                if (url == null) {
                    byte[] d = download("https://api.openf1.org/v1/drivers?session_key=latest&name_acronym=" + URLEncoder.encode(code, "UTF-8"), 5000);
                    JSONArray arr = new JSONArray(new String(d, "UTF-8"));
                    for (int i = arr.length() - 1; i >= 0 && url == null; i--) {
                        String u = arr.getJSONObject(i).optString("headshot_url", "");
                        if (!u.isEmpty() && !u.equals("null")) url = u;
                    }
                    if (url != null) p.edit().putString(key, url).apply();
                }
                Bitmap b = sharpImage(c, url, 900);
                if (b != null) return b;
            }
        } catch (Exception ignored) { }
        String[] w = wikiImages(c, driver.optString("url", ""));
        if (w == null) return null;
        Bitmap b = sharpImage(c, w[0], 900);
        if (b == null && !w[1].isEmpty()) b = image(c, w[1], 900);
        return b;
    }

    /** Team-Logo: zuerst Wikipedia-Infobox, sonst Wikimedia-Commons-Suche. */
    static Bitmap teamLogo(Context c, JSONObject constructor, int maxPx) {
        String id = constructor.optString("constructorId", "");
        String pageUrl = constructor.optString("url", "");
        // Für diese Teams zeigt der Standard-Wikipedia-Link nicht auf den Team-Artikel
        if (id.equals("mclaren")) pageUrl = "https://en.wikipedia.org/wiki/McLaren_Racing";
        else if (id.equals("alpine")) pageUrl = "https://en.wikipedia.org/wiki/Alpine_F1_Team";
        String[] w = wikiImages(c, pageUrl);
        if (w != null && !w[0].isEmpty()) {
            String check = (w[1].isEmpty() ? w[0] : w[1]).toLowerCase(Locale.ROOT);
            if (check.contains("logo") || check.contains("emblem") || check.contains("badge")
                    || check.contains("crest") || check.contains("wordmark") || check.contains(".svg")) {
                Bitmap b = image(c, w[0], maxPx);
                if (b != null) return cleanLogo(b);
            }
        }
        return cleanLogo(commonsLogo(c, constructor.optString("name", ""), maxPx));
    }

    private static String firstWord(String team) {
        String n = team == null ? "" : team.toLowerCase(Locale.ROOT).trim();
        if (n.startsWith("red bull")) return "red bull";
        if (n.startsWith("aston")) return "aston martin";
        int sp = n.indexOf(' ');
        String f = sp > 0 ? n.substring(0, sp) : n;
        if (f.contains("-")) f = f.substring(0, f.indexOf('-'));
        return f;
    }

    private static JSONObject apiGet(String url, int timeout) {
        try { return new JSONObject(new String(download(url, timeout), "UTF-8")); } catch (Exception e) { return null; }
    }

    private static Bitmap commonsLogo(Context c, String team, int maxPx) {
        if (team.isEmpty()) return null;
        SharedPreferences p = c.getSharedPreferences("apex1_widgets", Context.MODE_PRIVATE);
        String key = "logo2:" + team;
        String url = p.getString(key, null);
        try {
            if (url == null) {
                String word = firstWord(team);
                String[] queries = { team + " Racing logo", team + " F1 Team logo", team + " Formula 1 logo", word + " logo" };
                int bestScore = Integer.MAX_VALUE;
                for (String q : queries) {
                    JSONObject j = apiGet("https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrnamespace=6&gsrlimit=12"
                            + "&gsrsearch=" + URLEncoder.encode(q, "UTF-8")
                            + "&prop=imageinfo&iiprop=url&iiurlwidth=400&format=json", 7000);
                    if (j == null || !j.has("query")) continue;
                    JSONObject pages = j.getJSONObject("query").getJSONObject("pages");
                    java.util.Iterator<String> it = pages.keys();
                    while (it.hasNext()) {
                        JSONObject pg = pages.getJSONObject(it.next());
                        String title = pg.optString("title", "").toLowerCase(Locale.ROOT);
                        if (!title.contains("logo") || !title.contains(word)) continue;
                        if (title.contains("automotive") || title.contains("cars") || title.contains("applied")
                                || title.contains("trophy") || title.contains("wordmark old")) continue;
                        JSONArray ii = pg.optJSONArray("imageinfo");
                        if (ii == null || ii.length() == 0) continue;
                        String thumb = ii.getJSONObject(0).optString("thumburl", "");
                        if (thumb.isEmpty()) continue;
                        int score = pg.optInt("index", 50);
                        if (title.matches(".*(19\\d\\d|200\\d|201\\d).*")) score += 40; // ältere Jahreslogos nachrangig
                        if (title.endsWith(".svg")) score -= 3;
                        if (score < bestScore) { bestScore = score; url = thumb; }
                    }
                    if (url != null) break;
                }
                if (url != null && !url.isEmpty()) p.edit().putString(key, url).apply(); else return null;
            }
            return image(c, url, maxPx);
        } catch (Exception e) { return null; }
    }

    /** Aktuelles Fahrzeug: Wikipedia-Artikel zum Auto der Saison (Titel enthält Teamname und eine Zahl). */
    static Bitmap carImage(Context c, String team, String season) {
        if (team == null || team.isEmpty()) return null;
        SharedPreferences p = c.getSharedPreferences("apex1_widgets", Context.MODE_PRIVATE);
        String key = "car:" + team + ":" + season;
        String url = p.getString(key, null);
        try {
            if (url == null) {
                JSONObject j = apiGet("https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrlimit=8"
                        + "&gsrsearch=" + URLEncoder.encode(season + " " + team + " Formula One car", "UTF-8")
                        + "&prop=pageimages&piprop=thumbnail&pithumbsize=700&format=json", 7000);
                if (j == null || !j.has("query")) return null;
                JSONObject pages = j.getJSONObject("query").getJSONObject("pages");
                String word = firstWord(team);
                int bestIdx = 999;
                java.util.Iterator<String> it = pages.keys();
                while (it.hasNext()) {
                    JSONObject pg = pages.getJSONObject(it.next());
                    String title = pg.optString("title", "").toLowerCase(Locale.ROOT);
                    if (!title.contains(word) || !title.matches(".*\\d.*")) continue;
                    if (title.contains("championship") || title.contains("season") || title.contains("grand prix")) continue;
                    JSONObject th = pg.optJSONObject("thumbnail");
                    if (th == null) continue;
                    String src = th.optString("source", "");
                    String low = src.toLowerCase(Locale.ROOT);
                    if (src.isEmpty() || low.contains("logo") || low.endsWith(".svg.png")) continue;
                    int idx = pg.optInt("index", 500);
                    if (idx < bestIdx) { bestIdx = idx; url = src; }
                }
                if (url != null) p.edit().putString(key, url).apply(); else return null;
            }
            return image(c, url, 700);
        } catch (Exception e) { return null; }
    }

    private static boolean nearWhite(int px) {
        return ((px >> 16) & 0xFF) > 236 && ((px >> 8) & 0xFF) > 236 && (px & 0xFF) > 236;
    }

    /** Entfernt weiße Rechteck-Hintergründe, sodass nur das Logo mit transparentem Hintergrund bleibt. */
    static Bitmap cleanLogo(Bitmap src) {
        if (src == null) return null;
        Bitmap b = src.copy(Bitmap.Config.ARGB_8888, true);
        int w = b.getWidth(), h = b.getHeight();
        int[] px = new int[w * h];
        b.getPixels(px, 0, w, 0, 0, w, h);
        boolean opaqueWhiteCorner = (px[0] >>> 24) > 200 && nearWhite(px[0]);
        if (!src.hasAlpha() || opaqueWhiteCorner) {
            for (int i = 0; i < px.length; i++) if ((px[i] >>> 24) > 0 && nearWhite(px[i])) px[i] = 0;
            b.setPixels(px, 0, w, 0, 0, w, h);
        }
        return b;
    }

    /** Färbt ein Logo komplett in einer Farbe ein (Alpha bleibt erhalten). */
    static Bitmap tint(Bitmap src, int color) {
        if (src == null) return null;
        Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        android.graphics.Canvas cv = new android.graphics.Canvas(out);
        android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG | android.graphics.Paint.FILTER_BITMAP_FLAG);
        p.setColorFilter(new android.graphics.PorterDuffColorFilter(color, android.graphics.PorterDuff.Mode.SRC_IN));
        cv.drawBitmap(src, 0, 0, p);
        return out;
    }

    /** [Helligkeit, Sättigung, R, G, B] gewichtet über die sichtbaren Pixel. */
    private static double[] stats(Bitmap src) {
        int w = src.getWidth(), h = src.getHeight();
        int[] px = new int[w * h];
        src.getPixels(px, 0, w, 0, 0, w, h);
        double lum = 0, sat = 0, r = 0, g = 0, b = 0, wt = 0;
        for (int v : px) {
            int a = v >>> 24;
            if (a < 30) continue;
            int rr = (v >> 16) & 0xFF, gg = (v >> 8) & 0xFF, bb = v & 0xFF;
            int mx = Math.max(rr, Math.max(gg, bb)), mn = Math.min(rr, Math.min(gg, bb));
            lum += (0.2126 * rr + 0.7152 * gg + 0.0722 * bb) / 255.0 * a;
            sat += (mx == 0 ? 0 : (mx - mn) / (double) mx) * a;
            r += rr * a; g += gg * a; b += bb * a; wt += a;
        }
        if (wt == 0) return new double[]{1, 0, 255, 255, 255};
        return new double[]{lum / wt, sat / wt, r / wt, g / wt, b / wt};
    }

    /** Farbige Logos (z. B. Red Bull) bleiben farbig; nur dunkle, farblose werden weiß eingefärbt. */
    static Bitmap legibleOnDark(Bitmap src) {
        if (src == null) return null;
        double[] s = stats(src);
        if (s[1] > 0.28) return src;               // farbig → unverändert
        return s[0] < 0.5 ? tint(src, 0xFFFFFFFF) : src;
    }

    /** Logo für die Teamfarben-Kachel: farbig lassen, wenn es sich vom Hintergrund abhebt – sonst weiß. */
    static Bitmap logoForPanel(Bitmap src, int bg) {
        double[] s = stats(src);
        if (s[1] > 0.28) {
            double dr = s[2] - ((bg >> 16) & 0xFF), dg = s[3] - ((bg >> 8) & 0xFF), db = s[4] - (bg & 0xFF);
            if (Math.sqrt(dr * dr + dg * dg + db * db) > 110) return src;
        }
        return tint(src, 0xFFFFFFFF);
    }

    /* ---------- Streckenkarte (echte Commons-Grafik, einfarbig für dunkle Flächen) ---------- */

    static Bitmap trackMap(Context c, String circuitId, int maxPx) {
        for (String f : Tracks.files(circuitId)) {
            Bitmap b = image(c, "https://commons.wikimedia.org/wiki/Special:FilePath/" + f + "?width=" + maxPx, maxPx);
            if (b != null) return ink(b, 0xFFFFFFFF);
        }
        return null;
    }

    /** Dunkle Linien der Streckenkarte werden zu 'Tinte' in der Zielfarbe; heller Grund wird transparent. */
    static Bitmap ink(Bitmap src, int color) {
        int w = src.getWidth(), h = src.getHeight();
        int[] px = new int[w * h];
        src.getPixels(px, 0, w, 0, 0, w, h);
        for (int i = 0; i < px.length; i++) {
            int p = px[i];
            int a = p >>> 24, r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
            int lum = (299 * r + 587 * g + 114 * b) / 1000;
            int s = Math.min(255, a * (255 - lum) / 255 * 3 / 2);
            px[i] = (s << 24) | (color & 0xFFFFFF);
        }
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        out.setPixels(px, 0, w, 0, 0, w, h);
        return out;
    }
}
