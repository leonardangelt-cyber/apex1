package de.apex1.f1;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/** OpenF1-Zugriff mit optionalem Konto (Live-Daten während Sessions erfordern ein Sponsor-Konto). */
final class OpenF1 {
    private OpenF1() {}

    private static final String TOKEN_URL = "https://api.openf1.org/token";
    private static String token;
    private static long tokenUntil;

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("apex1_live", Context.MODE_PRIVATE);
    }

    static boolean hasAccount(Context c) {
        SharedPreferences p = prefs(c);
        return !p.getString("user", "").isEmpty() && !p.getString("pass", "").isEmpty();
    }

    static void save(Context c, String user, String pass) {
        prefs(c).edit().putString("user", user == null ? "" : user.trim()).putString("pass", pass == null ? "" : pass).apply();
        token = null;
        tokenUntil = 0;
    }

    static void clear(Context c) { save(c, "", ""); }

    private static byte[] read(HttpURLConnection con) throws Exception {
        InputStream in = con.getResponseCode() >= 400 ? con.getErrorStream() : con.getInputStream();
        if (in == null) return new byte[0];
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toByteArray();
        } finally { in.close(); }
    }

    /** Holt (und cached) ein Zugriffstoken; null wenn kein Konto hinterlegt ist. Wirft bei falschen Zugangsdaten. */
    static synchronized String token(Context c) throws Exception {
        if (!hasAccount(c)) return null;
        if (token != null && System.currentTimeMillis() < tokenUntil) return token;
        SharedPreferences p = prefs(c);
        String body = "username=" + URLEncoder.encode(p.getString("user", ""), "UTF-8")
                + "&password=" + URLEncoder.encode(p.getString("pass", ""), "UTF-8");
        HttpURLConnection con = (HttpURLConnection) new URL(TOKEN_URL).openConnection();
        con.setConnectTimeout(10000);
        con.setReadTimeout(10000);
        con.setRequestMethod("POST");
        con.setDoOutput(true);
        con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        try (OutputStream os = con.getOutputStream()) { os.write(body.getBytes("UTF-8")); }
        int code = con.getResponseCode();
        String res = new String(read(con), "UTF-8");
        if (code != 200) throw new RuntimeException("LOGIN " + code);
        JSONObject j = new JSONObject(res);
        token = j.getString("access_token");
        long secs = 3600;
        try { secs = Long.parseLong(j.optString("expires_in", "3600")); } catch (Exception ignored) { }
        tokenUntil = System.currentTimeMillis() + Math.max(60, secs - 120) * 1000L;
        return token;
    }

    /** GET auf die OpenF1-REST-API; mit Token, falls ein Konto hinterlegt ist. Wirft "HTTP <code>" bei Fehlern. */
    static String get(Context c, String url) throws Exception {
        String t = token(c);
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(10000);
        con.setReadTimeout(15000);
        con.setRequestProperty("Accept", "application/json");
        con.setRequestProperty("User-Agent", "APEX1-Android/1.0 (F1 companion app)");
        if (t != null) con.setRequestProperty("Authorization", "Bearer " + t);
        int code = con.getResponseCode();
        String res = new String(read(con), "UTF-8");
        if (code == 401) { token = null; }
        if (code != 200) throw new RuntimeException("HTTP " + code);
        return res;
    }
}
