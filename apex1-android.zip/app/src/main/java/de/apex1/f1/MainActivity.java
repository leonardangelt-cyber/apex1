package de.apex1.f1;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.Manifest;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import androidx.webkit.WebViewAssetLoader;

/** Zeigt die APEX/1-Web-App (liegt in assets/www) in einer WebView. */
public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String START = "https://" + HOST + "/assets/www/index.html";
    private WebView web;
    private CalendarView calendar;
    private NavBar nav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        Palette.init(this);
        web = new WebView(this);
        FrameLayout stack = new FrameLayout(this);
        stack.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        calendar = new CalendarView(this, new CalendarView.Listener() {
            @Override public void go(String hash) { goHash(hash); }
        });
        stack.addView(calendar, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        nav = new NavBar(this, new NavBar.Listener() {
            @Override public void pick(String tab) { goHash("#" + tab); }
        });
        nav.select("calendar");
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.addView(stack, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(nav, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        int surface = surfaceColor();
        web.setBackgroundColor(surface);
        getWindow().setStatusBarColor(surface);
        getWindow().setNavigationBarColor(Palette.card);
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void route(final String hash) {
                runOnUiThread(new Runnable() { @Override public void run() { applyRoute(hash); } });
            }
            @JavascriptInterface public void haptic(boolean on) { Palette.haptic = on; }
        }, "AndroidNav");
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void perform(final String kind) {
                runOnUiThread(new Runnable() { public void run() {
                    int c = "click".equals(kind) ? android.view.HapticFeedbackConstants.KEYBOARD_TAP : android.view.HapticFeedbackConstants.CLOCK_TICK;
                    web.performHapticFeedback(c);
                } });
            }
        }, "AndroidHaptic");
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public String colors() { return monet(); }
        }, "AndroidTheme");
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public String get() { return Notifier.state(MainActivity.this); }
            @JavascriptInterface public void set(String key, String value) {
                SharedPreferences.Editor e = Notifier.prefs(MainActivity.this).edit();
                if ("lead".equals(key)) e.putInt(key, Integer.parseInt(value));
                else e.putBoolean(key, "true".equals(value));
                e.apply();
                UpdateWorker.schedulePeriodic(MainActivity.this);
                UpdateWorker.enqueue(MainActivity.this);
            }
            @JavascriptInterface public void requestPermission() {
                runOnUiThread(new Runnable() { @Override public void run() {
                    if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
                    else notifyPermissionResult();
                } });
            }
            @JavascriptInterface public void test() { Notifier.test(MainActivity.this); }
        }, "AndroidNotify");
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void get(final String id, final String url) {
                new Thread(new Runnable() { @Override public void run() {
                    String res;
                    boolean ok = false;
                    try {
                        String host = Uri.parse(url).getHost();
                        if (host == null) throw new RuntimeException("host");
                        if (host.equals("api.openf1.org")) {
                            res = OpenF1.get(MainActivity.this, url);
                        } else if (host.endsWith("motorsport-total.com") || host.endsWith("motorsport.com")) {
                            res = new String(F1.download(url, 10000), "UTF-8");
                        } else throw new RuntimeException("host");
                        ok = true;
                    } catch (Exception e) { res = String.valueOf(e.getMessage()); }
                    send(id, ok, res);
                } }).start();
            }
            @JavascriptInterface public boolean hasAccount() { return OpenF1.hasAccount(MainActivity.this); }
            @JavascriptInterface public void saveAccount(String user, String pass) { OpenF1.save(MainActivity.this, user, pass); }
            @JavascriptInterface public void clearAccount() { OpenF1.clear(MainActivity.this); }
            @JavascriptInterface public void checkAccount(final String id) {
                new Thread(new Runnable() { @Override public void run() {
                    boolean ok = false;
                    String msg;
                    try {
                        ok = OpenF1.token(MainActivity.this) != null;
                        msg = ok ? "ok" : "Kein Konto hinterlegt";
                    } catch (Exception e) { msg = String.valueOf(e.getMessage()); }
                    send(id, ok, msg);
                } }).start();
            }
        }, "AndroidHttp");
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void png(final String b64, final String text) {
                try {
                    byte[] data = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
                    java.io.File dir = new java.io.File(getCacheDir(), "share");
                    dir.mkdirs();
                    java.io.File f = new java.io.File(dir, "apex1-ergebnis.png");
                    java.io.FileOutputStream out = new java.io.FileOutputStream(f);
                    out.write(data);
                    out.close();
                    final Uri uri = androidx.core.content.FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".files", f);
                    runOnUiThread(new Runnable() { @Override public void run() {
                        Intent i = new Intent(Intent.ACTION_SEND).setType("image/png")
                                .putExtra(Intent.EXTRA_STREAM, uri).putExtra(Intent.EXTRA_TEXT, text)
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(i, "Ergebnis teilen"));
                    } });
                } catch (Exception ignored) { }
            }
        }, "AndroidShare");
        Notifier.channels(this);
        UpdateWorker.schedulePeriodic(this);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                // Externe Links (z. B. News-Artikel) im Browser öffnen
                startActivity(new Intent(Intent.ACTION_VIEW, u));
                return true;
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl(START);
        }
    }

    private void goHash(String hash) {
        web.evaluateJavascript("location.hash=" + org.json.JSONObject.quote(hash), null);
    }

    /** Die Web-App meldet jede Route; hier entscheidet sich, ob Kalender/Leiste nativ gezeigt werden. */
    private void applyRoute(String hash) {
        String h = hash == null ? "" : hash;
        if (h.startsWith("#")) h = h.substring(1);
        if (h.startsWith("/")) h = h.substring(1);
        String[] segs = h.isEmpty() ? new String[0] : h.split("/");
        String first = segs.length > 0 ? segs[0] : "calendar";
        boolean standalone = first.equals("settings") || first.equals("tyres") || first.equals("flags");
        boolean detail = segs.length >= 2 || standalone;
        String base = (first.equals("drivers") || first.equals("teams")) ? "standings" : first;
        boolean known = false;
        for (String t : NavBar.TABS) if (t.equals(base)) known = true;
        if (!known) base = "calendar";
        boolean showCal = base.equals("calendar") && !detail;
        if (showCal && calendar.getVisibility() != android.view.View.VISIBLE) {
            calendar.setAlpha(0f);
            calendar.setVisibility(android.view.View.VISIBLE);
            calendar.animate().alpha(1f).setDuration(220).start();
        } else if (!showCal) {
            calendar.animate().cancel();
            calendar.setVisibility(android.view.View.GONE);
        }
        nav.setVisibility(detail ? android.view.View.GONE : android.view.View.VISIBLE);
        nav.select(base);
    }

    private void send(String id, boolean ok, String text) {
        final String js = "window.__httpCb&&window.__httpCb(" + org.json.JSONObject.quote(id) + "," + ok + "," + org.json.JSONObject.quote(text) + ")";
        runOnUiThread(new Runnable() { @Override public void run() { web.evaluateJavascript(js, null); } });
    }

    private void notifyPermissionResult() {
        web.evaluateJavascript("window.onNotifPermission&&window.onNotifPermission()", null);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        notifyPermissionResult();
    }

    private String hex(int res) {
        return String.format("#%06X", 0xFFFFFF & getColor(res));
    }

    private int col(int res) { return getColor(res); }

    /** Hintergrundfarbe passend zur Web-Oberfläche (Wallpaper-Palette ab Android 12). */
    private int surfaceColor() {
        if (Build.VERSION.SDK_INT < 31) return 0xFF0B0D12;
        try { return mix(col(android.R.color.system_neutral1_900), col(android.R.color.system_neutral1_1000), 0.4f); }
        catch (Exception e) { return 0xFF0B0D12; }
    }

    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static String h(int c) { return String.format("#%06X", 0xFFFFFF & c); }

    /** Material-You-Rollen (Android 12+, dunkel) als JSON für die Web-App; sonst leer = Standard-Dunkel. */
    private String monet() {
        if (Build.VERSION.SDK_INT < 31) return "{}";
        try {
            int n900 = col(android.R.color.system_neutral1_900), n1000 = col(android.R.color.system_neutral1_1000);
            int n800 = col(android.R.color.system_neutral1_800), n700 = col(android.R.color.system_neutral1_700);
            int v700 = col(android.R.color.system_neutral2_700);
            String[][] r = {
                {"surface", h(mix(n900, n1000, 0.4f))},
                {"surfaceLowest", h(n1000)},
                {"surfaceLow", h(mix(n900, n800, 0.5f))},
                {"surfaceContainer", h(mix(n900, n800, 0.9f))},
                {"surfaceHigh", h(mix(n800, n700, 0.5f))},
                {"surfaceHighest", h(n700)},
                {"onSurface", h(col(android.R.color.system_neutral1_100))},
                {"onSurfaceVariant", h(col(android.R.color.system_neutral2_200))},
                {"outline", h(col(android.R.color.system_neutral2_400))},
                {"outlineVariant", h(v700)},
                {"primary", h(col(android.R.color.system_accent1_200))},
                {"onPrimary", h(col(android.R.color.system_accent1_800))},
                {"primaryContainer", h(col(android.R.color.system_accent1_700))},
                {"onPrimaryContainer", h(col(android.R.color.system_accent1_100))},
                {"secondary", h(col(android.R.color.system_accent2_200))},
                {"secondaryContainer", h(col(android.R.color.system_accent2_700))},
                {"onSecondaryContainer", h(col(android.R.color.system_accent2_100))},
                {"tertiary", h(col(android.R.color.system_accent3_200))},
                {"tertiaryContainer", h(col(android.R.color.system_accent3_700))},
                {"onTertiaryContainer", h(col(android.R.color.system_accent3_100))}
            };
            StringBuilder sb = new StringBuilder("{");
            for (int i = 0; i < r.length; i++) {
                if (i > 0) sb.append(',');
                sb.append('"').append(r[i][0]).append("\":\"").append(r[i][1]).append('"');
            }
            return sb.append('}').toString();
        } catch (Exception e) { return "{}"; }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (calendar.getVisibility() != android.view.View.VISIBLE && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
