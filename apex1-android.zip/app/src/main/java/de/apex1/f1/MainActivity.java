package de.apex1.f1;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

/** Zeigt die APEX/1-Web-App (liegt in assets/www) in einer WebView. */
public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String START = "https://" + HOST + "/assets/www/index.html";
    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        web.setBackgroundColor(0xFF0B0D12);
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public String colors() { return monet(); }
        }, "AndroidTheme");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                // Externe Links (z. B. News-Artikel) im Browser öffnen
                startActivity(new Intent(Intent.ACTION_VIEW, u));
                return true;
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl(START);
        }
    }

    private String hex(int res) {
        return String.format("#%06X", 0xFFFFFF & getColor(res));
    }

    /** Material-You-Farben (Android 12+) als JSON für die Web-App; sonst leer = Standard-Dunkel. */
    private String monet() {
        if (Build.VERSION.SDK_INT < 31) return "{}";
        try {
            return "{\"bg\":\"" + hex(android.R.color.system_neutral1_900)
                + "\",\"card\":\"" + hex(android.R.color.system_neutral1_800)
                + "\",\"card2\":\"" + hex(android.R.color.system_neutral1_700)
                + "\",\"cardHi\":\"" + hex(android.R.color.system_neutral2_700)
                + "\",\"outline\":\"" + hex(android.R.color.system_neutral2_700)
                + "\",\"text\":\"" + hex(android.R.color.system_neutral1_50)
                + "\",\"dim\":\"" + hex(android.R.color.system_neutral2_300)
                + "\",\"faint\":\"" + hex(android.R.color.system_neutral2_400)
                + "\",\"primary\":\"" + hex(android.R.color.system_accent1_200)
                + "\",\"primaryDim\":\"" + hex(android.R.color.system_accent1_800)
                + "\",\"tertiary\":\"" + hex(android.R.color.system_accent3_200) + "\"}";
        } catch (Exception e) { return "{}"; }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
