package de.apex1.f1;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.Manifest;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

/** Zeigt die APEX/1-Web-App (liegt in assets/www) in einer WebView. */
public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String START = "https://" + HOST + "/assets/www/index.html";
    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        web.setBackgroundColor(0xFF0B0D12);
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public String colors() { return monet(); }
        }, "AndroidTheme");
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public String get() { return Notifier.state(MainActivity.this); }
            @JavascriptInterface public void set(String key, String value) {
                SharedPreferences.Editor e = Notifier.prefs(MainActivity.this).edit();
                if ("lead".equals(key)) e.putInt(key, Integer.parseInt(value));
                else e.putBoolean(key, "true".equals(value));
                e.apply();
                UpdateWorker.schedulePeriodic(MainActivity.this);
                UpdateWorker.enqueue(MainActivity.this);
            }
            @JavascriptInterface public void requestPermission() {
                runOnUiThread(new Runnable() { @Override public void run() {
                    if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
                    else notifyPermissionResult();
                } });
            }
            @JavascriptInterface public void test() { Notifier.test(MainActivity.this); }
        }, "AndroidNotify");
        Notifier.channels(this);
        UpdateWorker.schedulePeriodic(this);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                // Externe Links (z. B. News-Artikel) im Browser öffnen
                startActivity(new Intent(Intent.ACTION_VIEW, u));
                return true;
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl(START);
        }
    }

    private void notifyPermissionResult() {
        web.evaluateJavascript("window.onNotifPermission&&window.onNotifPermission()", null);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        notifyPermissionResult();
    }

    private String hex(int res) {
        return String.format("#%06X", 0xFFFFFF & getColor(res));
    }

    private int col(int res) { return getColor(res); }

    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static String h(int c) { return String.format("#%06X", 0xFFFFFF & c); }

    /** Material-You-Rollen (Android 12+, dunkel) als JSON für die Web-App; sonst leer = Standard-Dunkel. */
    private String monet() {
        if (Build.VERSION.SDK_INT < 31) return "{}";
        try {
            int n900 = col(android.R.color.system_neutral1_900), n1000 = col(android.R.color.system_neutral1_1000);
            int n800 = col(android.R.color.system_neutral1_800), n700 = col(android.R.color.system_neutral1_700);
            int v700 = col(android.R.color.system_neutral2_700);
            String[][] r = {
                {"surface", h(mix(n900, n1000, 0.4f))},
                {"surfaceLowest", h(n1000)},
                {"surfaceLow", h(mix(n900, n800, 0.5f))},
                {"surfaceContainer", h(mix(n900, n800, 0.9f))},
                {"surfaceHigh", h(mix(n800, n700, 0.5f))},
                {"surfaceHighest", h(n700)},
                {"onSurface", h(col(android.R.color.system_neutral1_100))},
                {"onSurfaceVariant", h(col(android.R.color.system_neutral2_200))},
                {"outline", h(col(android.R.color.system_neutral2_400))},
                {"outlineVariant", h(v700)},
                {"primary", h(col(android.R.color.system_accent1_200))},
                {"onPrimary", h(col(android.R.color.system_accent1_800))},
                {"primaryContainer", h(col(android.R.color.system_accent1_700))},
                {"onPrimaryContainer", h(col(android.R.color.system_accent1_100))},
                {"secondary", h(col(android.R.color.system_accent2_200))},
                {"secondaryContainer", h(col(android.R.color.system_accent2_700))},
                {"onSecondaryContainer", h(col(android.R.color.system_accent2_100))},
                {"tertiary", h(col(android.R.color.system_accent3_200))},
                {"tertiaryContainer", h(col(android.R.color.system_accent3_700))},
                {"onTertiaryContainer", h(col(android.R.color.system_accent3_100))}
            };
            StringBuilder sb = new StringBuilder("{");
            for (int i = 0; i < r.length; i++) {
                if (i > 0) sb.append(',');
                sb.append('"').append(r[i][0]).append("\":\"").append(r[i][1]).append('"');
            }
            return sb.append('}').toString();
        } catch (Exception e) { return "{}"; }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
