package de.apex1.f1;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Kleines Wettersymbol (Sonne, Wolke, Regen …) im Material-Stil, passend zum WMO-Wettercode. */
final class WeatherIcon extends View {
    static final int SUN = 0, PART = 1, CLOUD = 2, FOG = 3, RAIN = 4, SNOW = 5, STORM = 6;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int kind;

    static int kindOf(int c) {
        if (c == 0 || c == 1) return SUN;
        if (c == 2) return PART;
        if (c == 3) return CLOUD;
        if (c == 45 || c == 48) return FOG;
        if ((c >= 51 && c <= 67) || (c >= 80 && c <= 82)) return RAIN;
        if ((c >= 71 && c <= 77) || c == 85 || c == 86) return SNOW;
        if (c >= 95) return STORM;
        return CLOUD;
    }

    static String label(int kind) {
        switch (kind) {
            case SUN: return "Klar";
            case PART: return "Teils bewölkt";
            case FOG: return "Nebel";
            case RAIN: return "Regen";
            case SNOW: return "Schnee";
            case STORM: return "Gewitter";
            default: return "Bewölkt";
        }
    }

    static int tint(int kind) {
        switch (kind) {
            case SUN: case PART: return 0xFFF5C542;
            case RAIN: case STORM: return 0xFF6FB3FF;
            case SNOW: return 0xFFBFE3FF;
            default: return Palette.onVariant;
        }
    }

    WeatherIcon(Context c, int kind) { super(c); this.kind = kind; }

    private void cloud(Canvas cv, float s, float ox, float oy, int color) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        cv.drawCircle(ox + 8 * s, oy + 13 * s, 4 * s, p);
        cv.drawCircle(ox + 13 * s, oy + 10.5f * s, 5 * s, p);
        cv.drawCircle(ox + 17 * s, oy + 14 * s, 3.5f * s, p);
        cv.drawRoundRect(new RectF(ox + 7 * s, oy + 13 * s, ox + 17.5f * s, oy + 17.5f * s), 2 * s, 2 * s, p);
    }

    private void sun(Canvas cv, float s, float cx, float cy, float r) {
        int col = 0xFFF5C542;
        p.setColor(col);
        p.setStyle(Paint.Style.FILL);
        cv.drawCircle(cx, cy, r, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(1.8f * s);
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4;
            float c0 = (float) Math.cos(a), s0 = (float) Math.sin(a);
            cv.drawLine(cx + c0 * (r + 2 * s), cy + s0 * (r + 2 * s), cx + c0 * (r + 4 * s), cy + s0 * (r + 4 * s), p);
        }
    }

    @Override protected void onDraw(Canvas cv) {
        float s = Math.min(getWidth(), getHeight()) / 24f;
        int col = tint(kind);
        p.setStrokeCap(Paint.Cap.ROUND);
        switch (kind) {
            case SUN:
                sun(cv, s, 12 * s, 12 * s, 4.2f * s);
                break;
            case PART:
                sun(cv, s, 8.5f * s, 8.5f * s, 3f * s);
                cloud(cv, s, 2 * s, 3 * s, Palette.onVariant);
                break;
            case FOG:
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2f * s);
                p.setColor(col);
                cv.drawLine(4 * s, 9 * s, 20 * s, 9 * s, p);
                cv.drawLine(6 * s, 13 * s, 19 * s, 13 * s, p);
                cv.drawLine(4 * s, 17 * s, 20 * s, 17 * s, p);
                break;
            case RAIN:
                cloud(cv, s, 1 * s, -2 * s, Palette.onVariant);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(1.9f * s);
                p.setColor(col);
                cv.drawLine(8 * s, 17.5f * s, 7 * s, 20.5f * s, p);
                cv.drawLine(12.5f * s, 17.5f * s, 11.5f * s, 20.5f * s, p);
                cv.drawLine(17 * s, 17.5f * s, 16 * s, 20.5f * s, p);
                break;
            case SNOW:
                cloud(cv, s, 1 * s, -2 * s, Palette.onVariant);
                p.setStyle(Paint.Style.FILL);
                p.setColor(col);
                cv.drawCircle(8 * s, 19 * s, 1.3f * s, p);
                cv.drawCircle(12.5f * s, 20.5f * s, 1.3f * s, p);
                cv.drawCircle(17 * s, 19 * s, 1.3f * s, p);
                break;
            case STORM:
                cloud(cv, s, 1 * s, -3 * s, Palette.onVariant);
                p.setStyle(Paint.Style.FILL);
                p.setColor(col);
                android.graphics.Path b = new android.graphics.Path();
                b.moveTo(13.5f * s, 14 * s); b.lineTo(10 * s, 19 * s); b.lineTo(12.6f * s, 19 * s);
                b.lineTo(11.2f * s, 23 * s); b.lineTo(16 * s, 17.4f * s); b.lineTo(13.2f * s, 17.4f * s); b.close();
                cv.drawPath(b, p);
                break;
            default:
                cloud(cv, s, 1 * s, 0, Palette.onVariant);
        }
    }
}
