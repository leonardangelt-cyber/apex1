package de.apex1.f1;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

/** Widget "WM-Stand" (Top 5 der Fahrerwertung). */
public class StandingsWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(final Context ctx, final AppWidgetManager mgr, final int[] ids) {
        final BroadcastReceiver.PendingResult pr = goAsync();
        new Thread(() -> {
            try {
                String label = "WM-Stand", names = "Keine Daten", points = "";
                String json = Api.get(ctx, "https://api.jolpi.ca/ergast/f1/current/driverstandings.json", "standings");
                if (json != null) {
                    try {
                        JSONObject list = new JSONObject(json).getJSONObject("MRData")
                                .getJSONObject("StandingsTable").getJSONArray("StandingsLists").getJSONObject(0);
                        label = "Fahrer-WM " + list.optString("season", "");
                        JSONArray arr = list.getJSONArray("DriverStandings");
                        StringBuilder n = new StringBuilder(), p = new StringBuilder();
                        for (int i = 0; i < Math.min(5, arr.length()); i++) {
                            JSONObject d = arr.getJSONObject(i);
                            JSONObject drv = d.getJSONObject("Driver");
                            if (i > 0) { n.append('\n'); p.append('\n'); }
                            n.append(d.optString("position", String.valueOf(i + 1))).append("  ")
                                    .append(drv.optString("givenName", "").isEmpty() ? "" : drv.getString("givenName").charAt(0) + ". ")
                                    .append(drv.optString("familyName", ""));
                            p.append(d.optString("points", "0")).append(" P");
                        }
                        names = n.toString();
                        points = p.toString();
                    } catch (Exception e) {
                        names = "Daten nicht lesbar";
                    }
                }

                Intent open = new Intent(ctx, MainActivity.class);
                PendingIntent pi = PendingIntent.getActivity(ctx, 1, open,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                for (int id : ids) {
                    RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_standings);
                    v.setTextViewText(R.id.s_label, label);
                    v.setTextViewText(R.id.s_names, names);
                    v.setTextViewText(R.id.s_points, points);
                    v.setOnClickPendingIntent(R.id.s_root, pi);
                    mgr.updateAppWidget(id, v);
                }
            } finally {
                pr.finish();
            }
        }).start();
    }
}
