package de.apex1.f1;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

/** Top 5 der Fahrerwertung. */
public class DriverStandingsWidget extends BaseWidget {
    @Override
    void render(Context c, AppWidgetManager m, int id) throws Exception {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_list);
        v.setOnClickPendingIntent(R.id.w_root, openApp(c, 11));
        v.removeAllViews(R.id.w_rows);
        JSONArray arr = F1.driverStandings(c);
        v.setTextViewText(R.id.w_label, "FAHRER-WM " + F1.season(c));
        if (arr == null) {
            v.setTextViewText(R.id.w_empty, "Keine Daten – bitte Internet prüfen");
            v.setViewVisibility(R.id.w_empty, View.VISIBLE);
            m.updateAppWidget(id, v);
            return;
        }
        v.setViewVisibility(R.id.w_empty, View.GONE);
        for (int i = 0; i < Math.min(5, arr.length()); i++) {
            JSONObject s = arr.getJSONObject(i);
            JSONObject d = s.getJSONObject("Driver");
            RemoteViews row = new RemoteViews(c.getPackageName(), R.layout.row_standing);
            row.setTextViewText(R.id.rw_pos, s.optString("position", String.valueOf(i + 1)));
            row.setInt(R.id.rw_bar, "setBackgroundColor", F1.teamColor(F1.lastTeamName(s)));
            row.setTextViewText(R.id.rw_name, d.optString("givenName", "").isEmpty() ? d.optString("familyName")
                    : d.getString("givenName").charAt(0) + ". " + d.optString("familyName"));
            row.setTextViewText(R.id.rw_sub, F1.lastTeamName(s));
            row.setTextViewText(R.id.rw_pts, s.optString("points", "0"));
            row.setViewVisibility(R.id.rw_logo, View.GONE);
            v.addView(R.id.w_rows, row);
        }
        m.updateAppWidget(id, v);
    }
}
