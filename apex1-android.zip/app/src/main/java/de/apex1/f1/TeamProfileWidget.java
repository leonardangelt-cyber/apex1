package de.apex1.f1;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

/** Lieblingsteam: Logo, Position, Punkte, Siege. Team wird beim Hinzufügen gewählt. */
public class TeamProfileWidget extends BaseWidget {
    @Override
    void render(Context c, AppWidgetManager m, int id) throws Exception {
        int[] dm = dims(m, id, 250, 110);
        boolean small = dm[0] < 200 || dm[1] < 130 || dm[1] >= 200;
        RemoteViews v = new RemoteViews(c.getPackageName(), small ? R.layout.widget_profile_compact : R.layout.widget_profile);
        v.setOnClickPendingIntent(R.id.w_root, openApp(c, 14));
        float f = small ? Math.max(1f, Math.min(1.5f, Math.min(dm[0] / 130f, dm[1] / 160f))) : scale(m, id, 250, 110);
        if (small) {
            ts(v, R.id.p_name, 14, f); ts(v, R.id.p_pos, 12, f); ts(v, R.id.p_pts, 12, f); ts(v, R.id.p_l2, 9, f);
        } else {
            ts(v, R.id.p_first, 11, f); ts(v, R.id.p_name, 20, f); ts(v, R.id.p_sub, 12, f);
            ts(v, R.id.p_pos, 24, f); ts(v, R.id.p_pts, 24, f); ts(v, R.id.p_wins, 24, f);
            ts(v, R.id.p_l1, 9, f); ts(v, R.id.p_l2, 9, f); ts(v, R.id.p_l3, 9, f);
        }
        JSONArray arr = F1.teamStandings(c);
        if (arr == null || arr.length() == 0) {
            v.setTextViewText(R.id.p_name, "Keine Daten");
            v.setTextViewText(R.id.p_sub, "Bitte Internet prüfen");
            m.updateAppWidget(id, v);
            return;
        }
        String sel = selection(c, id);
        JSONObject pick = arr.getJSONObject(0);
        if (sel != null) {
            for (int i = 0; i < arr.length(); i++) {
                if (sel.equals(arr.getJSONObject(i).getJSONObject("Constructor").optString("constructorId"))) { pick = arr.getJSONObject(i); break; }
            }
        }
        JSONObject t = pick.getJSONObject("Constructor");
        String name = t.optString("name");
        int color = F1.teamColor(name);
        Bitmap logo = F1.teamLogo(c, t, 300);
        String initials = name.length() >= 2 ? name.substring(0, 2).toUpperCase() : name.toUpperCase();
        Bitmap car = F1.carImage(c, name, F1.season(c));
        v.setImageViewBitmap(R.id.p_panel, Panels.team(color, logo, initials, car));

        StringBuilder drivers = new StringBuilder();
        JSONArray ds = F1.driverStandings(c);
        if (ds != null) {
            for (int i = 0; i < ds.length(); i++) {
                JSONObject s = ds.getJSONObject(i);
                if (name.equals(F1.lastTeamName(s))) {
                    if (drivers.length() > 0) drivers.append(" · ");
                    drivers.append(s.getJSONObject("Driver").optString("familyName"));
                }
            }
        }
        v.setTextViewText(R.id.p_first, drivers.toString());
        v.setTextViewText(R.id.p_name, name.toUpperCase());
        v.setTextViewText(R.id.p_sub, "Konstrukteurs-WM " + F1.season(c));
        v.setTextColor(R.id.p_sub, color);
        v.setTextViewText(R.id.p_pos, String.format("%02d", pick.optInt("position", 0)));
        v.setTextViewText(R.id.p_pts, pick.optString("points", "0"));
        v.setTextViewText(R.id.p_wins, pick.optString("wins", "0"));
        v.setTextViewText(R.id.p_l1, "POS");
        v.setTextViewText(R.id.p_l2, small ? "PKT" : "PUNKTE");
        v.setTextViewText(R.id.p_l3, "SIEGE");
        m.updateAppWidget(id, v);
    }
}
