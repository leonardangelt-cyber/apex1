package de.apex1.f1;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Auswahl "Fahrer" bzw. "Team", wenn ein Profil-Widget hinzugefügt oder neu konfiguriert wird. */
public class ConfigActivity extends Activity {
    private int widgetId = AppWidgetManager.INVALID_APPWIDGET_ID;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setResult(RESULT_CANCELED);
        Intent i = getIntent();
        if (i.getExtras() != null) {
            widgetId = i.getExtras().getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        }
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return; }

        AppWidgetProviderInfo info = AppWidgetManager.getInstance(this).getAppWidgetInfo(widgetId);
        final boolean forTeam = info != null && info.provider.getClassName().endsWith("TeamProfileWidget");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(0, 48, 0, 0);
        TextView title = new TextView(this);
        title.setText(forTeam ? "Team auswählen" : "Fahrer auswählen");
        title.setTextSize(22);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setTextColor(Color.parseColor("#181B20"));
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 24, 0, 24);
        root.addView(title);
        final ListView list = new ListView(this);
        root.addView(list);
        setContentView(root);

        final TextView loading = new TextView(this);
        loading.setText("Lade …");
        loading.setGravity(Gravity.CENTER);
        loading.setPadding(0, 48, 0, 0);
        root.addView(loading, 1);

        new Thread(() -> {
            final List<String> labels = new ArrayList<>();
            final List<String> ids = new ArrayList<>();
            try {
                JSONArray arr = forTeam ? F1.teamStandings(this) : F1.driverStandings(this);
                if (arr != null) {
                    for (int k = 0; k < arr.length(); k++) {
                        JSONObject s = arr.getJSONObject(k);
                        if (forTeam) {
                            JSONObject t = s.getJSONObject("Constructor");
                            ids.add(t.optString("constructorId"));
                            labels.add(s.optString("position") + ".  " + t.optString("name"));
                        } else {
                            JSONObject d = s.getJSONObject("Driver");
                            ids.add(d.optString("driverId"));
                            labels.add(s.optString("position") + ".  " + d.optString("givenName") + " " + d.optString("familyName")
                                    + "  ·  " + F1.lastTeamName(s));
                        }
                    }
                }
            } catch (Exception ignored) { }
            runOnUiThread(() -> {
                loading.setVisibility(android.view.View.GONE);
                if (labels.isEmpty()) {
                    Toast.makeText(this, "Keine Daten – bitte Internet prüfen", Toast.LENGTH_LONG).show();
                    finish();
                    return;
                }
                list.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, labels));
                list.setOnItemClickListener((parent, view, pos, idLong) -> {
                    SharedPreferences.Editor e = getSharedPreferences("apex1_widgets", MODE_PRIVATE).edit();
                    e.putString("sel_" + widgetId, ids.get(pos)).apply();
                    Intent result = new Intent();
                    result.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
                    setResult(RESULT_OK, result);
                    UpdateWorker.enqueue(this);
                    finish();
                });
            });
        }).start();
    }
}
