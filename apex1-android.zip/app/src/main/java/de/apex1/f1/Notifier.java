package de.apex1.f1;

import android.Manifest;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;

/** Echte Benachrichtigungen: Session-Erinnerungen (Alarme) und Ergebnisse nach dem Rennen. Kein Server nötig. */
final class Notifier {
    private Notifier() {}

    static final String CH_SESS = "sessions", CH_RES = "results";
    private static final String PREFS = "apex1_notif";

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    static void channels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CH_SESS, "Session-Erinnerungen", NotificationManager.IMPORTANCE_HIGH));
        nm.createNotificationChannel(new NotificationChannel(CH_RES, "Rennergebnisse", NotificationManager.IMPORTANCE_DEFAULT));
    }

    static boolean granted(Context c) {
        return Build.VERSION.SDK_INT < 33
                || c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    static boolean on(Context c, String key, boolean def) { return prefs(c).getBoolean(key, def); }

    static String state(Context c) {
        SharedPreferences p = prefs(c);
        return "{\"enabled\":" + p.getBoolean("enabled", false)
                + ",\"sessions\":" + p.getBoolean("sessions", true)
                + ",\"results\":" + p.getBoolean("results", true)
                + ",\"lead\":" + p.getInt("lead", 30)
                + ",\"granted\":" + granted(c) + "}";
    }

    static void show(Context c, String channel, int id, String title, String text) {
        if (!granted(c)) return;
        channels(c);
        Intent open = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, id, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b = new NotificationCompat.Builder(c, channel)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setPriority(CH_SESS.equals(channel) ? NotificationCompat.PRIORITY_HIGH : NotificationCompat.PRIORITY_DEFAULT);
        c.getSystemService(NotificationManager.class).notify(id, b.build());
    }

    static void test(Context c) {
        show(c, CH_SESS, 1, "APEX/1", "So sehen deine Benachrichtigungen aus 🏁");
    }

    /** Vom Worker aufgerufen (alle 30 Min.): Alarme neu setzen und neue Ergebnisse prüfen. */
    static void sync(Context c) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        SharedPreferences p = prefs(c);
        // alte Alarme entfernen
        for (String code : p.getStringSet("alarms", new HashSet<String>())) {
            PendingIntent old = PendingIntent.getBroadcast(c, Integer.parseInt(code), new Intent(c, NotifyReceiver.class),
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (old != null) am.cancel(old);
        }
        Set<String> codes = new HashSet<>();
        if (!p.getBoolean("enabled", false) || !granted(c)) { p.edit().putStringSet("alarms", codes).apply(); return; }
        try {
            if (p.getBoolean("sessions", true)) scheduleSessions(c, am, p, codes);
            if (p.getBoolean("results", true)) checkResults(c, p);
        } catch (Exception ignored) { }
        p.edit().putStringSet("alarms", codes).apply();
    }

    private static Date parse(String d, String t) {
        try {
            SimpleDateFormat iso = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
            iso.setTimeZone(TimeZone.getTimeZone("UTC"));
            if (t == null || t.isEmpty()) t = "12:00:00Z";
            if (!t.endsWith("Z")) t = t + "Z";
            return iso.parse(d + "T" + t);
        } catch (Exception e) { return null; }
    }

    private static void scheduleSessions(Context c, AlarmManager am, SharedPreferences p, Set<String> codes) throws Exception {
        String json = Api.get(c, F1.JOLPICA + "/current.json?limit=40", "races");
        if (json == null) return;
        JSONArray races = new JSONObject(json).getJSONObject("MRData").getJSONObject("RaceTable").getJSONArray("Races");
        int lead = p.getInt("lead", 30);
        long now = System.currentTimeMillis();
        String[][] keys = {{"FirstPractice", "Training 1"}, {"SecondPractice", "Training 2"}, {"ThirdPractice", "Training 3"},
                {"SprintQualifying", "Sprint-Quali"}, {"SprintShootout", "Sprint-Quali"}, {"Sprint", "Sprint"},
                {"Qualifying", "Qualifying"}, {"", "Rennen"}};
        for (int i = 0; i < races.length(); i++) {
            JSONObject r = races.getJSONObject(i);
            String name = r.optString("raceName");
            for (String[] k : keys) {
                Date start;
                if (k[0].isEmpty()) start = parse(r.getString("date"), r.optString("time"));
                else {
                    JSONObject o = r.optJSONObject(k[0]);
                    start = o == null ? null : parse(o.optString("date"), o.optString("time"));
                }
                if (start == null) continue;
                long at = start.getTime() - lead * 60_000L;
                if (at <= now || at > now + 8 * 86400_000L) continue;
                int code = (r.optString("season") + r.optString("round") + k[1]).hashCode() & 0x7FFFFFFF;
                Intent in = new Intent(c, NotifyReceiver.class)
                        .putExtra("id", code).putExtra("title", name)
                        .putExtra("text", k[1] + " startet in " + lead + " Min.");
                PendingIntent pi = PendingIntent.getBroadcast(c, code, in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                codes.add(String.valueOf(code));
            }
        }
    }

    private static void checkResults(Context c, SharedPreferences p) throws Exception {
        String json = Api.get(c, F1.JOLPICA + "/current/last/results.json", "lastres");
        if (json == null) return;
        JSONArray races = new JSONObject(json).getJSONObject("MRData").getJSONObject("RaceTable").getJSONArray("Races");
        if (races.length() == 0) return;
        JSONObject r = races.getJSONObject(0);
        String key = r.optString("season") + "-" + r.optString("round");
        String last = p.getString("last_result", null);
        if (key.equals(last)) return;
        p.edit().putString("last_result", key).apply();
        if (last == null) return; // erste Prüfung: nur merken, nichts melden
        JSONArray res = r.getJSONArray("Results");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(3, res.length()); i++) {
            JSONObject d = res.getJSONObject(i).getJSONObject("Driver");
            if (i > 0) sb.append("\n");
            sb.append(i + 1).append(". ").append(d.optString("givenName")).append(' ').append(d.optString("familyName"));
        }
        show(c, CH_RES, 2, r.optString("raceName") + " – Ergebnis", sb.toString());
    }
}
