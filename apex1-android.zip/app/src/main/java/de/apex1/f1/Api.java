package de.apex1.f1;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/** Kleine Hilfsklasse: lädt Jolpica-JSON und merkt sich den letzten Stand für offline. */
final class Api {
    private Api() {}

    static String get(Context c, String url, String cacheKey) {
        SharedPreferences p = c.getSharedPreferences("apex1_widgets", Context.MODE_PRIVATE);
        try {
            HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
            con.setConnectTimeout(8000);
            con.setReadTimeout(10000);
            con.setRequestProperty("Accept", "application/json");
            if (con.getResponseCode() != 200) throw new RuntimeException("HTTP " + con.getResponseCode());
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line);
            }
            p.edit().putString(cacheKey, sb.toString()).apply();
            return sb.toString();
        } catch (Exception e) {
            return p.getString(cacheKey, null);
        }
    }
}
