package de.apex1.f1;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.PathInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Nativer Rennkalender im Material-3-Expressive-Stil. */
final class CalendarView extends FrameLayout {
    interface Listener { void go(String hash); }

    private static class Sess { String name; long start; LinearLayout wx; }
    private static class Race {
        String round, name, circuitId, circuitName, locality; double lat, lon; long raceStart;
        List<Sess> sessions = new ArrayList<>();
        long first() { return sessions.isEmpty() ? raceStart : sessions.get(0).start; }
    }

    private final Listener listener;
    private final ScrollView sv;
    private final LinearLayout list;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newFixedThreadPool(3);
    private final PathInterpolator emph = new PathInterpolator(0.2f, 0f, 0f, 1f);
    private final float density;
    private boolean built;

    CalendarView(Context c, Listener l) {
        super(c);
        listener = l;
        density = c.getResources().getDisplayMetrics().density;
        setBackgroundColor(Palette.surface);
        sv = new ScrollView(c);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        list = new LinearLayout(c);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(16), dp(8), dp(16), dp(20));
        sv.addView(list, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        addView(sv, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        buildHeader(null);
        load();
    }

    private int dp(float v) { return (int) (v * density + 0.5f); }

    private GradientDrawable shape(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(getContext());
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setIncludeFontPadding(false);
        return t;
    }

    private View roundButton(String path, final String hash) {
        FrameLayout f = new FrameLayout(getContext());
        f.setBackground(shape(Palette.card, 22));
        IconView ic = new IconView(getContext(), path, Palette.onSurface);
        f.addView(ic, new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER));
        f.setClickable(true);
        f.setContentDescription(hash);
        f.setOnClickListener(new OnClickListener() { @Override public void onClick(View v) {
            Palette.tick(v);
            listener.go(hash);
        } });
        press(f);
        return f;
    }

    private void buildHeader(String season) {
        LinearLayout head = new LinearLayout(getContext());
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(4), dp(12), 0, dp(16));
        LinearLayout titles = new LinearLayout(getContext());
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(text("Rennkalender", 30, Palette.onSurface, true));
        TextView sub = text(season == null ? "Saison wird geladen …" : "Saison " + season, 14, Palette.onVariant, false);
        sub.setPadding(0, dp(4), 0, 0);
        titles.addView(sub);
        head.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        String[] icons = { null, IconView.FLAG, IconView.SETTINGS };
        String[] hashes = { "#tyres", "#flags", "#settings" };
        for (int i = 0; i < 3; i++) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(44), dp(44));
            lp.leftMargin = dp(8);
            head.addView(roundButton(icons[i], hashes[i]), lp);
        }
        head.setTag("head");
        View old = list.findViewWithTag("head");
        if (old != null) list.removeView(old);
        list.addView(head, 0);
    }

    private void press(final View v) {
        v.setOnTouchListener(new OnTouchListener() { @Override public boolean onTouch(View view, MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) view.animate().scaleX(0.97f).scaleY(0.97f).setDuration(120).setInterpolator(emph).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) view.animate().scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(new android.view.animation.OvershootInterpolator(2.2f)).start();
            return false;
        } });
    }

    /* ---------- Daten ---------- */

    private void load() {
        io.execute(new Runnable() { @Override public void run() {
            try {
                String json = Api.get(getContext(), F1.JOLPICA + "/current.json?limit=40", "races");
                if (json == null) throw new RuntimeException("offline");
                JSONObject table = new JSONObject(json).getJSONObject("MRData").getJSONObject("RaceTable");
                final String season = table.optString("season", "");
                JSONArray rs = table.getJSONArray("Races");
                final List<Race> races = new ArrayList<>();
                for (int i = 0; i < rs.length(); i++) races.add(parse(rs.getJSONObject(i)));
                ui.post(new Runnable() { @Override public void run() { build(season, races); } });
            } catch (Exception e) {
                ui.post(new Runnable() { @Override public void run() { showError(); } });
            }
        } });
    }

    private static final String[][] KEYS = {
        {"FirstPractice", "Training 1"}, {"SecondPractice", "Training 2"}, {"ThirdPractice", "Training 3"},
        {"SprintQualifying", "Sprint-Quali"}, {"SprintShootout", "Sprint-Quali"}, {"Sprint", "Sprint"}, {"Qualifying", "Qualifying"}
    };

    private Race parse(JSONObject o) throws Exception {
        Race r = new Race();
        r.round = o.getString("round");
        r.name = o.optString("raceName", "Grand Prix");
        JSONObject ci = o.getJSONObject("Circuit");
        r.circuitId = ci.optString("circuitId");
        r.circuitName = ci.optString("circuitName");
        JSONObject loc = ci.optJSONObject("Location");
        if (loc != null) { r.lat = loc.optDouble("lat", Double.NaN); r.lon = loc.optDouble("long", Double.NaN); r.locality = loc.optString("locality"); }
        for (String[] k : KEYS) {
            JSONObject s = o.optJSONObject(k[0]);
            if (s == null) continue;
            Sess x = new Sess();
            x.name = k[1];
            x.start = ScheduleWidget.parse(s.optString("date"), s.optString("time", null));
            r.sessions.add(x);
        }
        Collections.sort(r.sessions, new Comparator<Sess>() { @Override public int compare(Sess a, Sess b) { return Long.compare(a.start, b.start); } });
        r.raceStart = ScheduleWidget.parse(o.getString("date"), o.optString("time", null));
        Sess race = new Sess();
        race.name = "Rennen";
        race.start = r.raceStart;
        r.sessions.add(race);
        return r;
    }

    private void showError() {
        if (built) return;
        TextView t = text("Der Kalender konnte nicht geladen werden. Bitte Verbindung prüfen und die App neu öffnen.", 15, Palette.onVariant, false);
        t.setPadding(dp(8), dp(24), dp(8), 0);
        list.addView(t);
    }

    /* ---------- Aufbau ---------- */

    private void build(String season, List<Race> races) {
        built = true;
        list.removeAllViews();
        buildHeader(season);
        long now = System.currentTimeMillis();
        int next = -1;
        for (int i = 0; i < races.size(); i++) if (races.get(i).raceStart + 2 * 3600000L > now) { next = i; break; }
        View nextCard = null;
        final List<Race> order = new ArrayList<>();
        for (int i = 0; i < races.size(); i++) {
            Race r = races.get(i);
            View card = card(r, i + 1, i == next, now);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = dp(12);
            list.addView(card, lp);
            if (i == next) nextCard = card;
            if (i < 7) {
                card.setAlpha(0f);
                card.setTranslationY(dp(36));
                card.animate().alpha(r.raceStart + 2 * 3600000L < now ? 0.72f : 1f).translationY(0).setStartDelay(i * 45L).setDuration(520).setInterpolator(emph).start();
            } else if (r.raceStart + 2 * 3600000L < now) card.setAlpha(0.72f);
        }
        // Wetter: erst das nächste Rennen, dann nach außen
        final int n = next < 0 ? races.size() - 1 : next;
        order.addAll(races);
        Collections.sort(order, new Comparator<Race>() { @Override public int compare(Race a, Race b) {
            return Integer.compare(Math.abs(Integer.parseInt(a.round) - 1 - n), Math.abs(Integer.parseInt(b.round) - 1 - n));
        } });
        for (final Race r : order) io.execute(new Runnable() { @Override public void run() { weather(r); } });
        final View target = nextCard;
        if (target != null) sv.postDelayed(new Runnable() { @Override public void run() {
            ValueAnimator a = ValueAnimator.ofInt(sv.getScrollY(), Math.max(0, target.getTop() - dp(88)));
            a.setDuration(650);
            a.setInterpolator(emph);
            a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { @Override public void onAnimationUpdate(ValueAnimator v) { sv.scrollTo(0, (Integer) v.getAnimatedValue()); } });
            a.start();
        } }, 350);
    }

    private View card(final Race r, int number, boolean isNext, long now) {
        boolean done = r.raceStart + 2 * 3600000L < now;
        boolean live = !done && r.first() <= now;
        int bg = isNext ? Palette.primaryC : Palette.card;
        int fg = isNext ? Palette.onPrimaryC : Palette.onSurface;
        int dim = isNext ? Palette.mix(Palette.primaryC, Palette.onPrimaryC, 0.72f) : Palette.onVariant;

        LinearLayout card = new LinearLayout(getContext());
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(shape(bg, 32));
        card.setPadding(dp(20), dp(18), dp(18), dp(14));
        card.setClickable(true);
        card.setOnClickListener(new OnClickListener() { @Override public void onClick(View v) {
            Palette.tick(v);
            listener.go("#calendar/" + r.round);
        } });
        press(card);

        if (isNext) {
            TextView lab = text("NÄCHSTES RENNEN", 11, Palette.primary, true);
            lab.setLetterSpacing(0.08f);
            lab.setPadding(0, 0, 0, dp(10));
            card.addView(lab);
        }

        LinearLayout head = new LinearLayout(getContext());
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView badge = text(String.valueOf(number), 15, isNext ? Palette.onPrimary : Palette.onSecondaryC, true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(shape(isNext ? Palette.primary : Palette.secondaryC, 14));
        head.addView(badge, new LinearLayout.LayoutParams(dp(40), dp(40)));
        TextView title = text(r.name, 18, fg, true);
        title.setMaxLines(2);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tl.leftMargin = dp(12);
        tl.rightMargin = dp(8);
        head.addView(title, tl);
        String chipText; int chipBg, chipFg;
        if (live) { chipText = "LIVE"; chipBg = Palette.primary; chipFg = Palette.onPrimary; }
        else if (done) { chipText = "Beendet"; chipBg = isNext ? Palette.primaryC : Palette.cardHigh; chipFg = dim; }
        else {
            long days = (long) Math.ceil((r.raceStart - now) / 86400000.0);
            chipText = days <= 0 ? "Heute" : days == 1 ? "Morgen" : "Noch " + days + " Tage";
            chipBg = isNext ? Palette.primary : Palette.secondaryC; chipFg = isNext ? Palette.onPrimary : Palette.onSecondaryC;
        }
        TextView chip = text(chipText, 12, chipFg, true);
        chip.setBackground(shape(chipBg, 14));
        chip.setPadding(dp(12), dp(7), dp(12), dp(7));
        head.addView(chip);
        card.addView(head);

        SimpleDateFormat df = new SimpleDateFormat("d. MMMM", Locale.GERMANY);
        String range = df.format(new Date(r.first())) + " – " + df.format(new Date(r.raceStart));
        TextView date = text(range + " · " + r.circuitName, 12.5f, dim, false);
        date.setPadding(0, dp(10), 0, dp(10));
        card.addView(date);

        LinearLayout body = new LinearLayout(getContext());
        body.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout rows = new LinearLayout(getContext());
        rows.setOrientation(LinearLayout.VERTICAL);
        SimpleDateFormat tf = new SimpleDateFormat("EEE HH:mm", Locale.GERMANY);
        for (int i = 0; i < r.sessions.size(); i++) {
            Sess s = r.sessions.get(i);
            if (i > 0) {
                View line = new View(getContext());
                line.setBackgroundColor(Palette.mix(bg, fg, 0.12f));
                rows.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
            }
            LinearLayout row = new LinearLayout(getContext());
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(7), 0, dp(7));
            row.addView(text(s.name, 13, fg, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            s.wx = new LinearLayout(getContext());
            s.wx.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams wl = new LinearLayout.LayoutParams(dp(58), dp(20));
            wl.rightMargin = dp(6);
            row.addView(s.wx, wl);
            TextView time = text(tf.format(new Date(s.start)), 12, Palette.primary, true);
            time.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            row.addView(time);
            rows.addView(row);
        }
        body.addView(rows, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final ImageView img = new ImageView(getContext());
        img.setScaleType(ImageView.ScaleType.FIT_CENTER);
        img.setAlpha(0f);
        LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(dp(104), dp(96));
        il.leftMargin = dp(12);
        body.addView(img, il);
        card.addView(body);

        io.execute(new Runnable() { @Override public void run() {
            final Bitmap b = F1.trackMap(getContext(), r.circuitId, 420);
            if (b != null) ui.post(new Runnable() { @Override public void run() {
                img.setImageBitmap(b);
                img.animate().alpha(0.95f).setDuration(400).start();
            } });
        } });
        return card;
    }

    /* ---------- Wetter (Open-Meteo, je Session) ---------- */

    private void weather(final Race r) {
        try {
            if (Double.isNaN(r.lat) || Double.isNaN(r.lon)) return;
            long now = System.currentTimeMillis();
            long first = r.first(), last = r.raceStart;
            double age = (now - last) / 86400000.0;
            SimpleDateFormat d = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            d.setTimeZone(TimeZone.getTimeZone("UTC"));
            String q = "latitude=" + r.lat + "&longitude=" + r.lon + "&hourly=weather_code,temperature_2m&timezone=UTC";
            String url = age > 60
                ? "https://archive-api.open-meteo.com/v1/archive?" + q + "&start_date=" + d.format(new Date(first)) + "&end_date=" + d.format(new Date(last))
                : "https://api.open-meteo.com/v1/forecast?" + q + "&past_days=" + (age > 0 ? 60 : 0) + "&forecast_days=16";
            JSONObject h = new JSONObject(new String(F1.download(url, 10000), "UTF-8")).getJSONObject("hourly");
            JSONArray time = h.getJSONArray("time"), code = h.getJSONArray("weather_code"), temp = h.getJSONArray("temperature_2m");
            SimpleDateFormat hf = new SimpleDateFormat("yyyy-MM-dd'T'HH':00'", Locale.US);
            hf.setTimeZone(TimeZone.getTimeZone("UTC"));
            for (final Sess s : r.sessions) {
                String key = hf.format(new Date(s.start));
                for (int i = 0; i < time.length(); i++) {
                    if (!key.equals(time.getString(i))) continue;
                    if (code.isNull(i) || temp.isNull(i)) break;
                    final int kind = WeatherIcon.kindOf(code.getInt(i));
                    final int deg = (int) Math.round(temp.getDouble(i));
                    ui.post(new Runnable() { @Override public void run() { showWx(s, kind, deg); } });
                    break;
                }
            }
        } catch (Exception ignored) { }
    }

    private void showWx(Sess s, int kind, int deg) {
        if (s.wx == null) return;
        s.wx.removeAllViews();
        s.wx.setContentDescription(WeatherIcon.label(kind));
        s.wx.addView(new WeatherIcon(getContext(), kind), new LinearLayout.LayoutParams(dp(18), dp(18)));
        TextView t = text(deg + "°", 12, Palette.onVariant, true);
        t.setPadding(dp(4), 0, 0, 0);
        s.wx.addView(t);
        s.wx.setAlpha(0f);
        s.wx.setScaleX(0.6f);
        s.wx.setScaleY(0.6f);
        s.wx.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(420).setInterpolator(new android.view.animation.OvershootInterpolator(2f)).start();
    }
}
