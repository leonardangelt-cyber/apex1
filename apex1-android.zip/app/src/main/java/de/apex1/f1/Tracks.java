package de.apex1.f1;

/** Echte Streckenkarten (Wikimedia Commons) – gleiche Zuordnung wie in der Web-App. */
final class Tracks {
    private Tracks() {}

    static String[] files(String circuitId) {
        if (circuitId == null) return new String[0];
        switch (circuitId) {
            case "albert_park":
                return new String[]{"2022_F1_CourseLayout_Australia.svg"};
            case "shanghai":
                return new String[]{"Shanghai_International_Racing_Circuit_track_map.svg"};
            case "suzuka":
                return new String[]{"2022_F1_CourseLayout_Japan.svg"};
            case "bahrain":
                return new String[]{"2022_F1_CourseLayout_Bahrain.svg"};
            case "jeddah":
                return new String[]{"2023_F1_CourseLayout_Saudi-Arabia.svg"};
            case "miami":
                return new String[]{"2022_F1_CourseLayout_Miami.svg"};
            case "imola":
                return new String[]{"2022_F1_CourseLayout_Imola.svg"};
            case "monaco":
                return new String[]{"2022_F1_CourseLayout_Monaco.svg"};
            case "catalunya":
                return new String[]{"2022_F1_CourseLayout_Spain.svg"};
            case "madring":
                return new String[]{"Madring_%282026%29.svg"};
            case "villeneuve":
                return new String[]{"2022_F1_CourseLayout_Canada.svg"};
            case "red_bull_ring":
                return new String[]{"2022_F1_CourseLayout_Austria.svg"};
            case "silverstone":
                return new String[]{"2022_F1_CourseLayout_Britain.svg"};
            case "spa":
                return new String[]{"2022_F1_CourseLayout_Belgium.svg"};
            case "hungaroring":
                return new String[]{"2022_F1_CourseLayout_Hungary.svg"};
            case "zandvoort":
                return new String[]{"2022_F1_CourseLayout_Netherlands.svg"};
            case "monza":
                return new String[]{"2022_F1_CourseLayout_Italia.svg"};
            case "baku":
                return new String[]{"2022_F1_CourseLayout_Azerbaijan.svg"};
            case "marina_bay":
                return new String[]{"2022_F1_CourseLayout_Singapore.svg"};
            case "americas":
                return new String[]{"2022_F1_CourseLayout_COTA.svg"};
            case "rodriguez":
                return new String[]{"2022_F1_CourseLayout_Mexico.svg"};
            case "interlagos":
                return new String[]{"2022_F1_CourseLayout_S%C3%A3o_Paulo.svg"};
            case "vegas":
            case "las_vegas":
                return new String[]{"Las_Vegas_Strip_Circuit_2023.png", "Las_Vegas_Strip_Circuit.png"};
            case "losail":
                return new String[]{"2023_F1_CourseLayout_Qatar.svg"};
            case "yas_marina":
                return new String[]{"2022_F1_CourseLayout_Abu_Dhabi.svg"};
            default:
                return new String[0];
        }
    }
}
