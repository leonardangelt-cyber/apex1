package de.apex1.f1;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.RemoteViews;

/** Konstrukteurswertung mit Logos – scrollbar, alle Teams. */
public class TeamStandingsWidget extends BaseWidget {
    @Override
    void render(Context c, AppWidgetManager m, int id) throws Exception {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_list);
        v.setOnClickPendingIntent(R.id.w_root, openApp(c, 12));
        Intent si = new Intent(c, ListService.class).putExtra("kind", "team").putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
        si.setData(Uri.parse(si.toUri(Intent.URI_INTENT_SCHEME)));
        v.setRemoteAdapter(R.id.w_list, si);
        v.setPendingIntentTemplate(R.id.w_list, openApp(c, 12 + 20));
        v.setEmptyView(R.id.w_list, R.id.w_empty);
        v.setTextViewText(R.id.w_label, "KONSTRUKTEURS-WM " + F1.season(c));
        m.updateAppWidget(id, v);
        m.notifyAppWidgetViewDataChanged(id, R.id.w_list);
    }
}
