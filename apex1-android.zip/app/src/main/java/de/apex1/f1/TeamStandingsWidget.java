package de.apex1.f1;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

/** Top 5 der Konstrukteurswertung mit Team-Logos. */
public class TeamStandingsWidget extends BaseWidget {
    @Override
    void render(Context c, AppWidgetManager m, int id) throws Exception {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_list);
        v.setOnClickPendingIntent(R.id.w_root, openApp(c, 12));
        float f = scale(m, id, 250, 150);
        ts(v, R.id.w_label, 10, f);
        v.removeAllViews(R.id.w_rows);
        JSONArray arr = F1.teamStandings(c);
        v.setTextViewText(R.id.w_label, "KONSTRUKTEURS-WM " + F1.season(c));
        if (arr == null) {
            v.setTextViewText(R.id.w_empty, "Keine Daten – bitte Internet prüfen");
            v.setViewVisibility(R.id.w_empty, View.VISIBLE);
            m.updateAppWidget(id, v);
            return;
        }
        v.setViewVisibility(R.id.w_empty, View.GONE);
        for (int i = 0; i < Math.min(5, arr.length()); i++) {
            JSONObject s = arr.getJSONObject(i);
            JSONObject t = s.getJSONObject("Constructor");
            String name = t.optString("name");
            RemoteViews row = new RemoteViews(c.getPackageName(), R.layout.row_standing);
            row.setTextViewText(R.id.rw_pos, s.optString("position", String.valueOf(i + 1)));
            row.setInt(R.id.rw_bar, "setBackgroundColor", F1.teamColor(name));
            row.setTextViewText(R.id.rw_name, name);
            row.setTextViewText(R.id.rw_sub, s.optString("wins", "0") + " Siege");
            row.setTextViewText(R.id.rw_pts, s.optString("points", "0"));
            Bitmap logo = F1.legibleOnDark(F1.teamLogo(c, t, 120));
            if (logo != null) {
                row.setImageViewBitmap(R.id.rw_logo, logo);
                row.setViewVisibility(R.id.rw_logo, View.VISIBLE);
            } else {
                row.setViewVisibility(R.id.rw_logo, View.GONE);
            }
            ts(row, R.id.rw_pos, 12, f); ts(row, R.id.rw_name, 13, f); ts(row, R.id.rw_sub, 9, f); ts(row, R.id.rw_pts, 14, f);
            v.addView(R.id.w_rows, row);
        }
        m.updateAppWidget(id, v);
    }
}
