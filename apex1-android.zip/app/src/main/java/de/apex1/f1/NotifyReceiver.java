package de.apex1.f1;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Wird vom AlarmManager ausgelöst und zeigt die Session-Erinnerung. */
public class NotifyReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (!Notifier.on(c, "enabled", false)) return;
        Notifier.show(c, Notifier.CH_SESS, i.getIntExtra("id", 3), i.getStringExtra("title"), i.getStringExtra("text"));
    }
}
