package de.apex1.f1;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Nächstes Rennwochenende: Sessions (scrollbar) + Streckengrafik. */
public class ScheduleWidget extends BaseWidget {

    static class Sess { String name; long start; }

    static long parse(String d, String t) {
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
            return f.parse(d + "T" + (t == null ? "12:00:00Z" : t).replace("Z", "") + "Z").getTime();
        } catch (Exception e) { return 0; }
    }

    static void add(ArrayList<Sess> l, JSONObject race, String key, String label) {
        JSONObject o = race.optJSONObject(key);
        if (o == null) return;
        Sess s = new Sess();
        s.name = label;
        s.start = parse(o.optString("date"), o.optString("time", null));
        l.add(s);
    }

    @Override
    void render(Context c, AppWidgetManager m, int id) throws Exception {
        boolean small = dims(m, id, 250, 150)[0] < 200;
        int h = dims(m, id, 250, 150)[1];
        RemoteViews v = new RemoteViews(c.getPackageName(), small ? R.layout.widget_schedule_small : R.layout.widget_schedule);
        v.setOnClickPendingIntent(R.id.w_root, openApp(c, 10));

        long now = System.currentTimeMillis();
        JSONObject race = null;
        String json = Api.get(c, F1.JOLPICA + "/current.json?limit=40", "races");
        if (json != null) {
            JSONArray rs = new JSONObject(json).getJSONObject("MRData").getJSONObject("RaceTable").getJSONArray("Races");
            for (int i = 0; i < rs.length(); i++) {
                JSONObject r = rs.getJSONObject(i);
                if (parse(r.getString("date"), r.optString("time", null)) + 3 * 3600000L > now) { race = r; break; }
            }
        }
        if (race == null) {
            v.setTextViewText(R.id.w_label, "APEX/1");
            v.setTextViewText(R.id.w_title, json == null ? "Keine Daten" : "Saison beendet");
            v.setViewVisibility(R.id.w_trackbox, View.GONE);
            v.setViewVisibility(R.id.w_chip, View.GONE);
            if (!small) {
                v.setTextViewText(R.id.w_sub, "");
                c.getSharedPreferences("apex1_widgets", Context.MODE_PRIVATE).edit().putString("sched_data", "{}").apply();
                bindList(c, v, id);
            }
            m.updateAppWidget(id, v);
            if (!small) m.notifyAppWidgetViewDataChanged(id, R.id.w_sess);
            return;
        }

        ArrayList<Sess> ss = new ArrayList<>();
        add(ss, race, "FirstPractice", "Training 1");
        add(ss, race, "SecondPractice", "Training 2");
        add(ss, race, "ThirdPractice", "Training 3");
        add(ss, race, "SprintQualifying", "Sprint-Quali");
        add(ss, race, "SprintShootout", "Sprint-Quali");
        add(ss, race, "Sprint", "Sprint");
        add(ss, race, "Qualifying", "Qualifying");
        Sess rc = new Sess();
        rc.name = "Rennen";
        rc.start = parse(race.getString("date"), race.optString("time", null));
        ss.add(rc);
        Collections.sort(ss, (a, b) -> Long.compare(a.start, b.start));

        SimpleDateFormat tf = new SimpleDateFormat("EEE  HH:mm", Locale.GERMANY);
        JSONArray rows = new JSONArray();
        for (Sess s : ss) {
            boolean done = s.start + 2 * 3600000L < now;
            rows.put(new JSONArray().put((done ? "✓ " : "") + s.name).put(tf.format(new Date(s.start))));
        }

        long days = (rc.start - now) / 86400000L;
        String chip;
        long first = ss.get(0).start;
        if (now >= first && now < rc.start + 2 * 3600000L) chip = "LÄUFT";
        else {
            SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd", Locale.GERMANY);
            String t = df.format(new Date(rc.start)), n = df.format(new Date(now));
            String tm = df.format(new Date(now + 86400000L));
            chip = t.equals(n) ? "HEUTE" : t.equals(tm) ? "MORGEN" : "in " + Math.max(1, days) + " Tagen";
        }
        v.setTextViewText(R.id.w_chip, chip);
        v.setViewVisibility(R.id.w_chip, View.VISIBLE);
        v.setTextViewText(R.id.w_title, race.getString("raceName").replace("Grand Prix", "GP"));
        String rd = race.optString("round");
        v.setTextViewText(R.id.w_label, small ? "RUNDE " + rd : "RUNDE " + rd + " · NÄCHSTES RENNEN");

        if (!small) {
            JSONObject circ = race.getJSONObject("Circuit");
            SimpleDateFormat dm = new SimpleDateFormat("dd. MMM", Locale.GERMANY);
            String sub = circ.getString("circuitName") + " · " + circ.getJSONObject("Location").getString("country")
                    + "\n" + dm.format(new Date(ss.get(0).start)) + " – " + dm.format(new Date(rc.start));
            v.setTextViewText(R.id.w_sub, sub);
            v.setViewVisibility(R.id.w_sub, h < 140 ? View.GONE : View.VISIBLE);
        }

        Bitmap tm = null;
        try { tm = F1.trackMap(c, race.getJSONObject("Circuit").getString("circuitId"), 600); } catch (Exception ignored) { }
        if (tm != null) {
            v.setImageViewBitmap(R.id.w_track, tm);
            v.setViewVisibility(R.id.w_trackbox, View.VISIBLE);
        } else v.setViewVisibility(R.id.w_trackbox, View.GONE);

        if (!small) {
            c.getSharedPreferences("apex1_widgets", Context.MODE_PRIVATE).edit()
                    .putString("sched_data", new JSONObject().put("rows", rows).toString()).apply();
            bindList(c, v, id);
        }
        m.updateAppWidget(id, v);
        if (!small) m.notifyAppWidgetViewDataChanged(id, R.id.w_sess);
    }

    static void bindList(Context c, RemoteViews v, int id) {
        Intent si = new Intent(c, SessService.class).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
        si.setData(Uri.parse(si.toUri(Intent.URI_INTENT_SCHEME)));
        v.setRemoteAdapter(R.id.w_sess, si);
        v.setPendingIntentTemplate(R.id.w_sess, openApp(c, 30));
        v.setEmptyView(R.id.w_sess, R.id.w_empty);
    }
}
