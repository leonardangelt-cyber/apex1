package de.apex1.f1;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.graphics.Bitmap;
import android.graphics.Bitmap;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** F1-Zeitplan: nächstes Rennwochenende mit allen Sessions. */
public class ScheduleWidget extends BaseWidget {

    static class Sess { String name; Date date; }

    static Date parse(String d, String t) {
        try {
            SimpleDateFormat iso = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
            iso.setTimeZone(TimeZone.getTimeZone("UTC"));
            if (t == null || t.isEmpty()) t = "12:00:00Z";
            if (!t.endsWith("Z")) t = t + "Z";
            return iso.parse(d + "T" + t);
        } catch (Exception e) { return null; }
    }

    static void add(List<Sess> l, JSONObject r, String key, String label) {
        JSONObject o = r.optJSONObject(key);
        if (o == null) return;
        Date d = parse(o.optString("date"), o.optString("time"));
        if (d == null) return;
        Sess s = new Sess(); s.name = label; s.date = d; l.add(s);
    }

    /** Alle Sessions eines Rennwochenendes, zeitlich sortiert. */
    static List<Sess> sessions(JSONObject race) throws Exception {
        List<Sess> sess = sessions(race);
        Sess rs = sess.get(sess.size() - 1);
        return sess;
    }

    @Override
    void render(Context c, AppWidgetManager m, int id) throws Exception {
        boolean small = dims(m, id, 250, 150)[0] < 200; // 2 Spalten: kompakte, feste Ansicht
        RemoteViews v = new RemoteViews(c.getPackageName(), small ? R.layout.widget_schedule_small : R.layout.widget_schedule);
        v.setOnClickPendingIntent(R.id.w_root, openApp(c, 10));

        String json = Api.get(c, F1.JOLPICA + "/current.json?limit=40", "races");
        JSONObject race = null;
        if (json != null) {
            JSONArray races = new JSONObject(json).getJSONObject("MRData").getJSONObject("RaceTable").getJSONArray("Races");
            long now = System.currentTimeMillis();
            for (int i = 0; i < races.length(); i++) {
                JSONObject r = races.getJSONObject(i);
                Date d = parse(r.getString("date"), r.optString("time"));
                if (d != null && d.getTime() + 3 * 3600_000L > now) { race = r; break; }
            }
        }
        SharedPreferences prefs = c.getSharedPreferences("apex1_widgets", Context.MODE_PRIVATE);
        int h = dims(m, id, 250, 150)[1];
        if (race == null) {
            String t = json == null ? "Keine Daten" : "Saison beendet";
            v.setTextViewText(R.id.w_label, "APEX/1");
            v.setTextViewText(R.id.w_title, t);
            if (!small) v.setTextViewText(R.id.w_sub, json == null ? "Bitte Internet prüfen" : "Bis zur nächsten Saison!");
            v.setTextViewText(R.id.w_chip, "");
            v.setViewVisibility(R.id.w_trackbox, View.GONE);
            if (!small) prefs.edit().putString(SessService.KEY, "{}").apply();
            if (!small) bindList(c, v, id);
            m.updateAppWidget(id, v);
            if (!small) m.notifyAppWidgetViewDataChanged(id, R.id.w_sess);
            return;
        }

        List<Sess> sess = new ArrayList<>();
        add(sess, race, "FirstPractice", "Training 1");
        add(sess, race, "SecondPractice", "Training 2");
        add(sess, race, "ThirdPractice", "Training 3");
        add(sess, race, "SprintQualifying", "Sprint-Quali");
        add(sess, race, "SprintShootout", "Sprint-Quali");
        add(sess, race, "Sprint", "Sprint");
        add(sess, race, "Qualifying", "Qualifying");
        Sess rs = new Sess(); rs.name = "Rennen";
        rs.date = parse(race.getString("date"), race.optString("time"));
        sess.add(rs);
        Collections.sort(sess, new Comparator<Sess>() {
            @Override public int compare(Sess a, Sess b) { return a.date.compareTo(b.date); }
        });

        SimpleDateFormat dayTime = new SimpleDateFormat("EEE  HH:mm", Locale.GERMANY);
        SimpleDateFormat dayMonth = new SimpleDateFormat("dd. MMM", Locale.GERMANY);
        JSONArray rows = new JSONArray();
        long now = System.currentTimeMillis();
        for (Sess s : sess) {
            rows.put(new JSONArray().put((s.date.getTime() + 2 * 3600_000L < now ? "✓ " : "") + s.name).put(dayTime.format(s.date)));
        }
        Date first = sess.get(0).date, last = sess.get(sess.size() - 1).date;
        long days = (long) Math.ceil((rs.date.getTime() - now) / 86400000.0);
        String chip = rs.date.getTime() < now ? "LÄUFT" : (days <= 0 ? "HEUTE" : (days == 1 ? "MORGEN" : "in " + days + " Tagen"));
        JSONObject circuit = race.optJSONObject("Circuit");
        String country = circuit != null && circuit.optJSONObject("Location") != null
                ? circuit.getJSONObject("Location").optString("country", "") : "";
        String round = race.optString("round");
        String range = dayMonth.format(first) + " – " + dayMonth.format(last);
        String title = race.optString("raceName").replace("Grand Prix", "GP");
        String circuitId = circuit == null ? "" : circuit.optString("circuitId");

        v.setTextViewText(R.id.w_label, small ? "RUNDE " + round : "RUNDE " + round + " · NÄCHSTES RENNEN");
        v.setTextViewText(R.id.w_title, title);
        v.setTextViewText(R.id.w_chip, chip);
        Bitmap track = F1.trackMap(c, circuitId, 600);
        if (track != null) {
            v.setImageViewBitmap(R.id.w_track, track);
            v.setViewVisibility(R.id.w_trackbox, View.VISIBLE);
        } else v.setViewVisibility(R.id.w_trackbox, View.GONE);
        if (!small) {
            v.setTextViewText(R.id.w_sub, (circuit != null ? circuit.optString("circuitName") : "") + " · " + country + "\n" + range);
            v.setViewVisibility(R.id.w_sub, h < 140 ? View.GONE : View.VISIBLE);
            prefs.edit().putString(SessService.KEY, new JSONObject().put("rows", rows).toString()).apply();
            bindList(c, v, id);
        }
        m.updateAppWidget(id, v);
        if (!small) m.notifyAppWidgetViewDataChanged(id, R.id.w_sess);
    }

    private void bindList(Context c, RemoteViews v, int id) {
        Intent si = new Intent(c, SessService.class).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
        si.setData(Uri.parse(si.toUri(Intent.URI_INTENT_SCHEME)));
        v.setRemoteAdapter(R.id.w_sess, si);
        v.setPendingIntentTemplate(R.id.w_sess, openApp(c, 30));
        v.setEmptyView(R.id.w_sess, R.id.w_empty);
    }
}
