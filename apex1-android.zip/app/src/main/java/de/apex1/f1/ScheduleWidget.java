package de.apex1.f1;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** F1-Zeitplan: nächstes Rennwochenende mit allen Sessions. */
public class ScheduleWidget extends BaseWidget {

    private static class Sess { String name; Date date; }

    private static Date parse(String d, String t) {
        try {
            SimpleDateFormat iso = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
            iso.setTimeZone(TimeZone.getTimeZone("UTC"));
            if (t == null || t.isEmpty()) t = "12:00:00Z";
            if (!t.endsWith("Z")) t = t + "Z";
            return iso.parse(d + "T" + t);
        } catch (Exception e) { return null; }
    }

    private static void add(List<Sess> l, JSONObject r, String key, String label) {
        JSONObject o = r.optJSONObject(key);
        if (o == null) return;
        Date d = parse(o.optString("date"), o.optString("time"));
        if (d == null) return;
        Sess s = new Sess(); s.name = label; s.date = d; l.add(s);
    }

    @Override
    void render(Context c, AppWidgetManager m, int id) throws Exception {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_schedule);
        v.setOnClickPendingIntent(R.id.w_root, openApp(c, 10));
        boolean small = compact(m, id, 250, 150);
        boolean hideSess = dims(m, id, 250, 150)[1] < 170;
        float f = small ? 1f : scale(m, id, 250, 150);
        ts(v, R.id.w_label, 10, f); ts(v, R.id.w_chip, 10, f); ts(v, R.id.w_title, 19, f);
        ts(v, R.id.w_sub, 11, f); ts(v, R.id.w_names, 12, f); ts(v, R.id.w_times, 12, f);

        String json = Api.get(c, F1.JOLPICA + "/current.json?limit=40", "races");
        JSONObject race = null;
        if (json != null) {
            JSONArray races = new JSONObject(json).getJSONObject("MRData").getJSONObject("RaceTable").getJSONArray("Races");
            long now = System.currentTimeMillis();
            for (int i = 0; i < races.length(); i++) {
                JSONObject r = races.getJSONObject(i);
                Date d = parse(r.getString("date"), r.optString("time"));
                if (d != null && d.getTime() + 3 * 3600_000L > now) { race = r; break; }
            }
        }
        if (race == null) {
            v.setTextViewText(R.id.w_label, "APEX/1");
            v.setTextViewText(R.id.w_title, json == null ? "Keine Daten" : "Saison beendet");
            v.setTextViewText(R.id.w_sub, json == null ? "Bitte Internet prüfen" : "Bis zur nächsten Saison!");
            v.setTextViewText(R.id.w_names, "");
            v.setTextViewText(R.id.w_times, "");
            v.setTextViewText(R.id.w_chip, "");
            m.updateAppWidget(id, v);
            return;
        }

        List<Sess> sess = new ArrayList<>();
        add(sess, race, "FirstPractice", "Training 1");
        add(sess, race, "SecondPractice", "Training 2");
        add(sess, race, "ThirdPractice", "Training 3");
        add(sess, race, "SprintQualifying", "Sprint-Quali");
        add(sess, race, "SprintShootout", "Sprint-Quali");
        add(sess, race, "Sprint", "Sprint");
        add(sess, race, "Qualifying", "Qualifying");
        Sess rs = new Sess(); rs.name = "Rennen";
        rs.date = parse(race.getString("date"), race.optString("time"));
        sess.add(rs);
        Collections.sort(sess, new Comparator<Sess>() {
            @Override public int compare(Sess a, Sess b) { return a.date.compareTo(b.date); }
        });

        SimpleDateFormat dayTime = new SimpleDateFormat("EEE  HH:mm", Locale.GERMANY);
        SimpleDateFormat dayMonth = new SimpleDateFormat("dd. MMM", Locale.GERMANY);
        StringBuilder names = new StringBuilder(), times = new StringBuilder();
        long now = System.currentTimeMillis();
        for (int i = 0; i < sess.size(); i++) {
            if (i > 0) { names.append('\n'); times.append('\n'); }
            Sess s = sess.get(i);
            names.append(s.date.getTime() + 2 * 3600_000L < now ? "✓ " : "").append(s.name);
            times.append(dayTime.format(s.date));
        }

        Date first = sess.get(0).date, last = sess.get(sess.size() - 1).date;
        long days = (long) Math.ceil((rs.date.getTime() - now) / 86400000.0);
        String chip = rs.date.getTime() < now ? "LÄUFT" : (days <= 0 ? "HEUTE" : (days == 1 ? "MORGEN" : "in " + days + " Tagen"));
        JSONObject circuit = race.optJSONObject("Circuit");
        String country = circuit != null && circuit.optJSONObject("Location") != null
                ? circuit.getJSONObject("Location").optString("country", "") : "";

        v.setTextViewText(R.id.w_label, small ? "RUNDE " + race.optString("round") : "NÄCHSTES RENNEN · RUNDE " + race.optString("round"));
        v.setViewVisibility(R.id.w_sessions, hideSess ? View.GONE : View.VISIBLE);
        v.setTextViewText(R.id.w_title, race.optString("raceName"));
        String range = dayMonth.format(first) + " – " + dayMonth.format(last);
        v.setTextViewText(R.id.w_sub, small ? range : (circuit != null ? circuit.optString("circuitName") : "") + " · " + country + "\n" + range);
        v.setTextViewText(R.id.w_names, names.toString());
        v.setTextViewText(R.id.w_times, times.toString());
        v.setTextViewText(R.id.w_chip, chip);
        m.updateAppWidget(id, v);
    }
}
