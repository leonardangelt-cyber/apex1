package de.apex1.f1;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

abstract class BaseWidget extends AppWidgetProvider {

    /** Läuft im Hintergrund-Worker: baut die Ansicht und schreibt sie ins Widget. */
    abstract void render(Context c, AppWidgetManager m, int id) throws Exception;

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        UpdateWorker.enqueue(c);
    }

    @Override
    public void onEnabled(Context c) {
        UpdateWorker.schedulePeriodic(c);
        UpdateWorker.enqueue(c);
    }

    @Override
    public void onDeleted(Context c, int[] ids) {
        SharedPreferences.Editor e = c.getSharedPreferences("apex1_widgets", Context.MODE_PRIVATE).edit();
        for (int id : ids) e.remove("sel_" + id);
        e.apply();
    }

    static PendingIntent openApp(Context c, int code) {
        return PendingIntent.getActivity(c, code, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static String selection(Context c, int id) {
        return c.getSharedPreferences("apex1_widgets", Context.MODE_PRIVATE).getString("sel_" + id, null);
    }
}
