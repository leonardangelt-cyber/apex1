package de.apex1.f1;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.TypedValue;
import android.widget.RemoteViews;

abstract class BaseWidget extends AppWidgetProvider {

    /** Läuft im Hintergrund-Worker: baut die Ansicht und schreibt sie ins Widget. */
    abstract void render(Context c, AppWidgetManager m, int id) throws Exception;

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        UpdateWorker.enqueue(c);
    }

    @Override
    public void onEnabled(Context c) {
        UpdateWorker.schedulePeriodic(c);
        UpdateWorker.enqueue(c);
    }

    @Override
    public void onDeleted(Context c, int[] ids) {
        SharedPreferences.Editor e = c.getSharedPreferences("apex1_widgets", Context.MODE_PRIVATE).edit();
        for (int id : ids) e.remove("sel_" + id);
        e.apply();
    }

    static PendingIntent openApp(Context c, int code) {
        return PendingIntent.getActivity(c, code, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static String selection(Context c, int id) {
        return c.getSharedPreferences("apex1_widgets", Context.MODE_PRIVATE).getString("sel_" + id, null);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle newOptions) {
        UpdateWorker.enqueue(c); // Widget wurde in der Größe verändert → neu skalieren
    }

    /** Skalierungsfaktor aus der aktuellen Widget-Größe (Basis = Standardgröße in dp). */
    static float scale(AppWidgetManager m, int id, float baseW, float baseH) {
        Bundle o = m.getAppWidgetOptions(id);
        float w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, (int) baseW);
        float h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, (int) baseH);
        if (w <= 0) w = baseW;
        if (h <= 0) h = baseH;
        return Math.max(0.85f, Math.min(1.7f, Math.min(w / baseW, h / baseH)));
    }

    /** Aktuelle Widget-Größe in dp: {Breite, Höhe}. */
    static int[] dims(AppWidgetManager m, int id, int defW, int defH) {
        Bundle o = m.getAppWidgetOptions(id);
        int w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, defW);
        int h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, defH);
        return new int[]{w <= 0 ? defW : w, h <= 0 ? defH : h};
    }

    /** Kompakt = ca. 2x2 / 2x4 / 4x1: wenig Platz → weniger Inhalt. */
    static boolean compact(AppWidgetManager m, int id, int defW, int defH) {
        int[] d = dims(m, id, defW, defH);
        return d[0] < 200 || d[1] < 130;
    }

    static void ts(RemoteViews v, int viewId, float sp, float f) {
        v.setTextViewTextSize(viewId, TypedValue.COMPLEX_UNIT_SP, sp * f);
    }
}
