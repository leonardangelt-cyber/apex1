package de.apex1.f1;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import java.util.ArrayList;
import java.util.List;

/** Zeilen des News-Widgets: Vorschaubild, Überschrift, Quelle und Alter. */
public class NewsService extends RemoteViewsService {
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new Factory(getApplicationContext());
    }

    static class Row { News.Item item; android.graphics.Bitmap img; }

    static class Factory implements RemoteViewsFactory {
        private final Context c;
        private List<Row> rows = new ArrayList<>();

        Factory(Context c) { this.c = c; }

        @Override public void onCreate() { }

        @Override
        public void onDataSetChanged() {
            List<Row> out = new ArrayList<>();
            try {
                List<News.Item> items = News.load(c);
                for (int i = 0; i < items.size(); i++) {
                    Row r = new Row();
                    r.item = items.get(i);
                    if (i < 12 && r.item.img != null && !r.item.img.isEmpty()) {
                        r.img = News.thumb(F1.image(c, r.item.img, 300), 168, 126);
                    }
                    out.add(r);
                }
            } catch (Exception ignored) { }
            if (!out.isEmpty()) rows = out;
        }

        @Override public void onDestroy() { rows.clear(); }
        @Override public int getCount() { return rows.size(); }

        @Override
        public RemoteViews getViewAt(int i) {
            RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.item_news);
            if (i >= rows.size()) return v;
            Row r = rows.get(i);
            v.setTextViewText(R.id.nw_title, r.item.title);
            String ago = News.ago(r.item.time);
            v.setTextViewText(R.id.nw_meta, ago.isEmpty() ? r.item.source : r.item.source + " · " + ago);
            if (r.img != null) {
                v.setImageViewBitmap(R.id.nw_img, r.img);
                v.setViewVisibility(R.id.nw_img, View.VISIBLE);
            } else {
                v.setViewVisibility(R.id.nw_img, View.GONE);
            }
            v.setOnClickFillInIntent(R.id.it_root, new Intent().putExtra("open_url", r.item.link));
            return v;
        }

        @Override public RemoteViews getLoadingView() { return null; }
        @Override public int getViewTypeCount() { return 1; }
        @Override public long getItemId(int i) { return i; }
        @Override public boolean hasStableIds() { return true; }
    }
}
